(async()=>{'use strict';
// Item equipment can link to the pack's shared skill / weapon data (equip.skillIds / equip.weaponIds).
const assert=require('assert'),vm=require('vm'),{game,read}=require('./game_harness.cjs'),{setup}=require('./dom_lite.cjs');
const {document}=setup(),c={window:{},document,console,localStorage:{getItem:()=>null,setItem(){}},setTimeout:f=>f()};vm.createContext(c);
for(const f of ['pro_core','pro_battle','pro_templates','pro_editor'])vm.runInContext(read('shared/'+f+'.js'),c);
const C=c.window.PROCore,E=c.window.PROEditor;
const sk=C.skill({id:'guard',name:'守り',trigger:'when_targeted',effect:'damage_reduce_pct',value:20,chance:100,maxUses:0});
const wp={id:'gun',...C.weapon({name:'増設砲',attackType:'ranged',damageType:'beam',powerPct:120})};
const unit={id:'u',name:'兵士',role:'歩兵',tags:['歩兵'],hp:3000,atk:250,def:0,mob:500,acc:500,weaponIds:['gun'],deploy:{player:true,enemy:false}};
const ring={id:'ring',name:'守りの指輪',equip:{slot:'accessory',stats:{def:30},skillIds:['guard'],weaponIds:['gun']},price:100};
const pack={format:C.BUNDLE_FORMAT,schemaVersion:8,packId:'linked',skills:[sk],weapons:[wp],units:[unit],missions:[],items:[ring]};

// ---- contract ----
const parsed=C.bundlePack(pack);assert.equal(parsed.schemaVersion,8);assert.deepEqual(C.clone(parsed.items[0].equip.skillIds),['guard']);assert.equal(parsed.items[0].equip.skills,undefined,'links stay links');
assert(C.itemHasRefs(parsed.items[0])&&C.itemIsV8(ring));
const resolved=C.resolveItemData(parsed.items[0],parsed.weapons,parsed.skills);assert.equal(resolved.equip.skills[0].value,20);assert.equal(resolved.equip.weapons[0].name,'増設砲');assert.equal(resolved.equip.weapons[0].id,undefined);
resolved.equip.skills[0].value=99;assert.equal(sk.value,20,'resolved items own separate copies');
const flat=C.materializeItem(ring,[wp],[sk]);assert.equal(flat.equip.skillIds,undefined);assert.equal(flat.equip.weaponIds,undefined);assert.equal(flat.equip.skills[0].id,'guard');assert.doesNotThrow(()=>C.item(flat));
assert.match(C.itemSummary(C.item(flat)),/「守り」.*武装「増設砲」/);
// Missing / duplicate / oversized references are rejected.
for(const bad of [{...pack,skills:[]},{...pack,weapons:[]},{...pack,items:[{...ring,equip:{...ring.equip,skillIds:['guard','guard']}}]},{...pack,items:[{...ring,equip:{...ring.equip,skillIds:Array.from({length:9},(_,i)=>'s'+i)}}]},{...pack,items:[{...ring,equip:{...ring.equip,weaponIds:'gun'}}]}])assert.throws(()=>C.bundlePack(bad));
// Schema numbers: references need 8; plain embedded equipment keeps the old numbers; empty equipment too.
const inline={id:'ring2',name:'指輪',equip:{slot:'accessory',stats:{def:5},skills:[sk],weapons:[]}};
assert(C.bundlePack({...pack,skills:[],weapons:[],items:[inline],units:[{...unit,weaponIds:undefined,weapons:[C.weapon({name:'銃'})]}]}).schemaVersion<8);
assert.equal(C.item({id:'plain',name:'x',equip:{stats:{atk:5}}}).equip.skills.length,0);
// Standalone item packs cannot keep dangling links.
assert.throws(()=>C.itemPack({format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:6,packId:'i',items:[ring]}),/共有スキル・武装データを参照/);
assert.doesNotThrow(()=>C.itemPack({format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:6,packId:'i',items:[flat]}));
// ID repair follows links.
const fixed={skills:[{...sk,id:'bad id'}],weapons:[{...wp,id:'bad id'}],units:[],items:[{...ring,equip:{...ring.equip,skillIds:['bad id'],weaponIds:['bad id']}}]};E.fixIds(fixed);assert.equal(fixed.items[0].equip.skillIds[0],fixed.skills[0].id);assert.equal(fixed.items[0].equip.weaponIds[0],fixed.weapons[0].id);assert(C.safeId(fixed.skills[0].id));
// Picker source for weapons.
assert.deepEqual(E.refsFrom({weapons:()=>[wp]})('weapons',{}),[['gun','増設砲（gun）']]);

// ---- game: the linked equipment works and follows edits of the shared data ----
const g=game(),r=g.run;g.c.files=[{name:'linked.js',text:async()=>C.serialize('VAIS_BUNDLE_PACK',pack)}];await r('importBundleFiles(files)');assert(g.alerts.length===0,g.alerts.join('\n'));
assert.equal(r("ITEM_MASTER['ring'].equip.skills[0].value"),20);assert.equal(r("ITEM_MASTER['ring'].equip.weapons[0].name"),'増設砲');assert.equal(r("ITEM_MASTER['ring'].equip.skillIds"),undefined,'the game works with plain skills and weapons');
r("state.items['ring']=1;");assert(r("equipItem('u',0,'ring')"));
assert(r("UNIT_MASTER.find(u=>u.id==='u').skills.some(s=>s.id==='guard')"),'equipped skill is applied');assert(r("UNIT_MASTER.find(u=>u.id==='u').weapons.some(w=>w.name==='増設砲')"),'equipped weapon is applied');
assert.equal(r("UNIT_MASTER.find(u=>u.id==='u').def"),30);
// The shared data changes → the equipped item changes with it.
const changed={...pack,skills:[{...sk,value:45}],weapons:[{...wp,powerPct:200}]};g.c.files=[{name:'linked.js',text:async()=>C.serialize('VAIS_BUNDLE_PACK',changed)}];await r('importBundleFiles(files)');
assert.equal(r("UNIT_MASTER.find(u=>u.id==='u').skills.find(s=>s.id==='guard').value"),45);assert.equal(r("UNIT_MASTER.find(u=>u.id==='u').weapons.find(w=>w.name==='増設砲').powerPct"),200);
// Save / reload keeps working; a bundle whose item link is broken is rejected without changing anything.
r('importedBundlePacks=loadImportedBundlePacks();refreshBundleMasters();');assert.equal(r("ITEM_MASTER['ring'].equip.skills[0].value"),45);
const before=r('JSON.stringify(importedBundlePacks)');g.c.files=[{name:'bad.js',text:async()=>C.serialize('VAIS_BUNDLE_PACK',{...pack,skills:[]})}];await r('importBundleFiles(files)');assert.equal(r('JSON.stringify(importedBundlePacks)'),before);
// Save data exported with the linked pack re-imports.
const exported=r('JSON.stringify(exportSaveData())');const g2=game();g2.run(`importSaveData(${exported})`);assert.equal(g2.run("ITEM_MASTER['ring'].equip.skills[0].value"),45);

// ---- standalone makers expand links ----
const im=read('item_maker.html'),mm=read('mission_maker.html'),cm=read('combined_maker.html');
assert(im.includes('C.materializeItem(i,bundle.weapons,bundle.skills)')&&mm.includes('window.PROCore.materializeItem(i,bundle.weapons,bundle.skills)'));
// ---- combined maker wiring ----
assert(cm.includes('function linkedItemFields()')&&cm.includes("key:'skillIds'")&&cm.includes("ref:'weapons'")&&cm.includes('E.form(root,obj,linkedItemFields()'));
assert(cm.includes('pack.items.some(i=>i.equip?.skillIds?.includes(current()?.id))')&&cm.includes('pack.items.some(i=>i.equip?.weaponIds?.includes(current()?.id))'));
assert(cm.includes('for(const i of pack.items)if(i.equip?.skillIds)')&&cm.includes('for(const i of pack.items)if(i.equip?.weaponIds)'));
console.log('PASS: item equipment links — skillIds/weaponIds contract, resolve/materialize copies, rejection of missing/duplicate/oversized links, Schema 8 only when linked, standalone item pack guard, ID repair, picker source, game applies linked skills and weapons and follows shared edits, reload/save/atomic rejection, maker wiring');
})().catch(e=>{console.error(e);process.exitCode=1;});
