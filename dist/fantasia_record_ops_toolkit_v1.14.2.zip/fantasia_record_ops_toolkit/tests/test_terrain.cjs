(async()=>{'use strict';
// 1.12.0: pack terrains — validation, registration and lookup order, schema numbers, maker terrain editor, game loading and card text.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');const {setup,byText,byLabel}=require('./dom_lite.cjs');const {game}=require('./game_harness.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const {document}=setup();const c={window:{},console,document,confirm:()=>true,localStorage:{getItem:()=>null,setItem(){},removeItem(){}}};vm.createContext(c);
for(const f of ['pro_core','pro_battle','pro_templates','pro_editor'])vm.runInContext(read('shared/'+f+'.js'),c);
const C=c.window.PROCore,E=c.window.PROEditor,B=c.window.PROBattle;
// ---- contract ----
assert.deepEqual(C.clone(C.terrain({name:' 溶岩 ',desc:'熱い',meleeHitPt:-20,rangedHitPt:0,mobPct:-30,banTags:['生身']})),{name:'溶岩',desc:'熱い',meleeHitPt:-20,mobPct:-30,banTags:['生身']},'zero values dropped, negatives kept');
for(const bad of [{name:''},{name:'x'.repeat(21)},{name:'a',meleeHitPt:101},{name:'a',mobPct:-91},{name:'a',rangedHitPt:'abc'}])assert.throws(()=>C.terrain(bad),JSON.stringify(bad));
assert.throws(()=>C.terrainList([{name:'a'},{name:'a'}]),/重複/);assert.throws(()=>C.terrainList(Array.from({length:51},(_,i)=>({name:'t'+i}))),/50/);
assert.equal(C.terrainEffectText({meleeHitPt:-20,mobPct:15,banTags:['生身']}),'近接命中-20 / MOB+15% / 「生身」出撃不可');assert.equal(C.terrainEffectText({}),'効果なし');
// ---- lookup order: mission override > pack terrain > built-in ----
C.registerTerrains([{name:'溶岩',meleeHitPt:-20},{name:'市街地',meleeHitPt:5}]);
assert.deepEqual(C.clone(C.terrainMods({terrain:'溶岩'})),{meleeHitPt:-20});assert.deepEqual(C.clone(C.terrainMods({terrain:'市街地'})),{meleeHitPt:5},'pack terrain beats the built-in one');
assert.deepEqual(C.clone(C.terrainMods({terrain:'溶岩',terrainMods:{meleeHitPt:-5,mobPct:-10}})),{meleeHitPt:-5,mobPct:-10});assert.deepEqual(C.clone(C.terrainMods({terrain:'森林'})),{rangedHitPt:-5,mobPct:5});
assert.equal(C.terrainDef('どこか'),null);
// battle uses it
{const u={id:'u',name:'u',hp:1000,atk:300,def:0,mob:500,acc:500,tags:[],skills:[],weapons:[]};const w=C.weapon({name:'剣',attackType:'melee',powerPct:100,accuracyPt:0});assert.equal(B.damagePreview(u,w,u,{terrain:'溶岩'}).terrainHit,-20);}
C.registerTerrains([]);assert.deepEqual(C.clone(C.terrainMods({terrain:'市街地'})),{meleeHitPt:10},'clearing restores built-ins');
// ---- schema numbers ----
const m={id:'m',enemies:['a'],rules:[],terrain:'溶岩'};assert.equal(C.missionSchemaFor([m]),1);assert.equal(C.missionSchemaFor([m],[{name:'溶岩'}]),3);
const b=C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:4,packId:'p',units:[],missions:[m],items:[],terrains:[{name:'溶岩',meleeHitPt:-20}]});assert.equal(b.schemaVersion,4);assert.deepEqual(C.clone(b.terrains),[{name:'溶岩',meleeHitPt:-20}]);
assert.equal(C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:3,packId:'p',units:[],missions:[m],items:[]}).schemaVersion<4,true,'no terrains, no v3 missions → below 4');
// ---- maker helpers ----
const opts=E.terrainOptions([{name:'溶岩',meleeHitPt:-20},{name:'森林',mobPct:20}],'謎の地');
assert.deepEqual(opts[0],['溶岩','★ 溶岩（近接命中-20）']);assert(opts.some(([v,t])=>v==='森林'&&t.startsWith('★')));assert.equal(opts.filter(([v])=>v==='森林').length,1,'pack terrain hides the same built-in');assert.deepEqual(opts.at(-1),['謎の地','謎の地（未登録・効果なし）']);
assert.equal(E.terrainEffectOf('溶岩',[{name:'溶岩',desc:'熱い',meleeHitPt:-20}]),'近接命中-20。熱い');assert.match(E.terrainEffectOf('謎',[]),/未登録/);assert.equal(E.terrainEffectOf('宇宙',[]),'「生身」出撃不可');
// terrain editor: add, edit, duplicate, copy built-in, delete
{const list=[];let n=0;const box=document.createElement('div');E.terrainEditor(box,{get:()=>list,onChange:()=>n++});
 byText(box,'button','＋ 新しい地形').click();assert.deepEqual(list,[{name:'新しい地形',desc:''}]);
 const card=box.querySelector('.pro-list-item');const inputs=card.querySelectorAll('input');inputs[0].value='溶岩';inputs[0].oninput();
 const melee=inputs.find(i=>i.getAttribute('inputmode')==='decimal');melee.value='20';melee.oninput();card.querySelectorAll('button').find(x=>x.textContent==='±').click();assert.equal(list[0].melee??list[0].meleeHitPt,-20);
 assert(card.textContent.includes('効果: 近接命中-20'));
 byText(box,'button','複製').click();assert.equal(list[1].name,'溶岩2');assert.equal(list[1].meleeHitPt,-20);
 const copy=byLabel(box,'組み込みの地形をコピー');copy.value='宇宙';copy.onchange();assert.deepEqual(C.clone(list[2]),{name:'宇宙',desc:'',banTags:['生身']});
 assert.doesNotThrow(()=>C.terrainList(list));const dupName=box.querySelectorAll('.pro-list-item')[1].querySelectorAll('input')[0];dupName.value='溶岩';dupName.oninput();assert(box.textContent.includes('重複'),'duplicate names are flagged');
 box.querySelectorAll('button').filter(x=>x.textContent==='削除')[1].click();assert.deepEqual(list.map(t=>t.name),['溶岩','宇宙']);assert(n>=6);}
// terrain field in the mission form
{const obj={terrain:'溶岩'};const box=document.createElement('div');E.form(box,obj,[{key:'terrain',label:'地形',type:'terrain'}],()=>{},{terrains:()=>[{name:'溶岩',meleeHitPt:-20}]});const s=byLabel(box,'地形');assert.equal(s.value,'溶岩');assert(box.textContent.includes('効果: 近接命中-20'));s.value='月面';s.onchange();assert.equal(obj.terrain,'月面');assert(box.textContent.includes('効果: MOB-10%'));}
// ---- game: a mission pack with terrains ----
{const g=game();const pack={format:'VAIS_OUTER_OPS_MISSION_PACK',schemaVersion:3,packId:'lava',packName:'溶岩パック',terrains:[{name:'溶岩',desc:'熱い',meleeHitPt:-20,banTags:['生身']}],missions:[{id:'lava-1',name:'溶岩地帯',enemies:['core-e-trooper'],terrain:'溶岩',rules:[]}]};
 g.run(`importedMissionPacks=[validateMissionPack(${JSON.stringify(pack)})];rebuildMissionMaster();`);
 assert.equal(g.run("terrainText(MISSIONS.find(m=>m.id==='lava-1'))"),'溶岩（近接命中-20 / 「生身」出撃不可）');assert.deepEqual(C.clone(g.run("window.PROCore.terrainDef('溶岩')")),{meleeHitPt:-20,banTags:['生身']});
 assert.match(g.run("deployRules(MISSIONS.find(m=>m.id==='lava-1')).ban.join()"),/生身/);
 assert.throws(()=>g.run(`validateMissionPack(${JSON.stringify({...pack,schemaVersion:99})})`),/未対応/);
 g.run('importedMissionPacks=[];rebuildMissionMaster();');assert.match(g.run("terrainText({terrain:'溶岩'})"),/未登録/);}
console.log('PASS: terrains (validation incl. negatives, pack > built-in lookup, mission override, schema 3/4, editor add/edit/±/duplicate/copy/delete, terrain field, game loading, ban tags, card text)');
})().catch(e=>{console.error(e);process.exitCode=1});
