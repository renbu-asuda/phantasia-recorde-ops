(async()=>{'use strict';
const assert=require('assert'),vm=require('vm'),{game,read}=require('./game_harness.cjs'),{setup,byLabel}=require('./dom_lite.cjs');
const dom=setup(),c={window:{},console,document:dom.document,localStorage:{getItem:()=>null,setItem(){}},setTimeout:f=>f()};vm.createContext(c);
for(const f of ['shared/pro_core.js','shared/pro_battle.js','shared/pro_templates.js','shared/pro_editor.js'])vm.runInContext(read(f),c);
const C=c.window.PROCore,B=c.window.PROBattle,E=c.window.PROEditor,clone=C.clone;
const w={id:'rifle',...C.weapon({...C.weaponDefaults,name:'共有ライフル',powerPct:100,baseAtk:200,useUnitAtk:true,hitsMin:1,hitsMax:1,hitPowerPct:100,accuracyPt:25,minDamage:0})};
const unit={id:'unit',name:'試験兵',hp:10000,atk:100,def:0,mob:500,acc:500,skills:[],weaponIds:['rifle'],deploy:{player:true,enemy:true}};
const pack={format:C.BUNDLE_FORMAT,schemaVersion:7,packId:'shared',packName:'共有試験',weapons:[w],units:[unit,{...unit,id:'unit2'}],missions:[],items:[]};
const parsed=C.bundlePack(pack);assert.equal(parsed.schemaVersion,7);assert.equal(parsed.units[0].weapons,undefined);assert.equal(parsed.weapons.length,1);
assert.equal(C.resolveUnitWeapons(unit,parsed.weapons).weapons[0].baseAtk,200);
assert.throws(()=>C.bundlePack({...pack,weapons:[]}),/武装データ/);assert.throws(()=>C.bundlePack({...pack,weapons:[w,w]}),/重複/);
assert.throws(()=>C.resolveUnitWeapons({...unit,weaponIds:['rifle','rifle']},[w]),/重複/);
assert.throws(()=>C.weapon({...w,baseAtk:-1}),/基礎攻撃力/);assert.throws(()=>C.weapon({...w,useUnitAtk:'false'}),/true\/false/);
assert.equal(C.unitSchemaFor([{...unit,weapons:undefined}],[],[],[w]),7);
assert.equal(C.itemPack({format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:6,packId:'items',items:[{id:'kit',name:'武装',effect:{type:'add_weapon',weapon:w}}]}).schemaVersion,6);
// ATK reference / fixed damage / explicit zero and omission preserve old behavior.
assert.equal(C.weaponAttack(w,100),300);assert.equal(C.weaponAttack({...w,useUnitAtk:false},999),200);
assert.equal(C.weaponAttack({...w,baseAtk:0,useUnitAtk:false},999),0);
assert.equal(C.weaponAttack({powerPct:150},100),150);
const target={...unit,id:'target',weaponIds:undefined,weapons:[C.weapon(C.weaponDefaults)]};
for(const [ref,atk,expected] of [[true,100,300],[true,400,600],[false,100,200],[false,400,200]]){
 const ww=C.weapon({...w,useUnitAtk:ref}),a=B.combatant({...C.resolveUnitWeapons(unit,[w]),atk},'ally','a'),d=B.combatant(target,'enemy','d');
 const ctx=B.createContext({allies:[a],enemies:[d],rng:()=>.5});await B.resolveWeapon(ctx,a,ww,[d]);
 assert.equal(d.maxHp-d.currentHp,expected,'real combat damage');assert.equal(B.damagePreview(a,ww,d).perHitAvg,expected,'preview matches');
}
// Changing a master updates every linked unit, including persisted packs and updates.
const g=game(),r=g.run;g.c.files=[{name:'weapons.js',text:async()=>C.serialize('VAIS_BUNDLE_PACK',pack)}];await r('importBundleFiles(files)');
assert.equal(r("UNIT_MASTER.find(u=>u.id==='unit').weapons[0].baseAtk"),200);
const changed={...pack,weapons:[{...w,baseAtk:350}]};g.c.files=[{name:'weapons.js',text:async()=>C.serialize('VAIS_BUNDLE_PACK',changed)}];await r('importBundleFiles(files)');
for(const id of ['unit','unit2'])assert.equal(r(`UNIT_MASTER.find(u=>u.id==='${id}').weapons[0].baseAtk`),350);
r('importedBundlePacks=loadImportedBundlePacks();refreshBundleMasters();');assert.equal(r("UNIT_MASTER.find(u=>u.id==='unit').weapons[0].baseAtk"),350);
assert.equal(r("exportSaveData().packs.bundles.find(p=>p.packId==='shared').weapons[0].baseAtk"),350);
const before=r('JSON.stringify(importedBundlePacks)');g.c.files=[{name:'bad.js',text:async()=>C.serialize('VAIS_BUNDLE_PACK',{...pack,weapons:[]})}];await r('importBundleFiles(files)');assert.equal(r('JSON.stringify(importedBundlePacks)'),before,'bad references are atomic');
// Standalone Unit Maker resolves the shared master to self-contained weapon data.
const um=read('unit_maker.html'),functions=['normalizeSkill','legacySkills','normalizeWeapon','normalizeUnit','extractAssignedObject','duplicateIds','parsePackJs','convertLegacyPilots','newWeapon'];
const uc={window:c.window,setTimeout:()=>{},toast(){}};vm.createContext(uc);vm.runInContext("const C=window.PROCore,E=window.PROEditor,FORMAT='VAIS_OUTER_OPS_UNIT_PACK',SCHEMA=2,SUPPORTED_SCHEMAS=new Set([1,2,3,4,5,6,7]),DAMAGE_TYPE_KEYS=Object.keys(C.DAMAGE_TYPES),RESIST_TYPES=Object.keys(C.RESIST_TYPES),TRIGGER_LABELS=C.triggers,EFFECTS_BY_TRIGGER=C.allowed;const n=(v,f=0)=>Number.isFinite(Number(v))?Number(v):f,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));\n"+functions.map(name=>um.split('\n').find(x=>x.startsWith('function '+name+'('))).join('\n'),uc);
uc.text=read('samples/pro_sample_bundle.js');const only=vm.runInContext('parsePackJs(text)',uc);assert.equal(only.units[0].weapons[0].baseAtk,250);assert.equal(only.units[0].weaponIds,undefined);
// Pickers store boolean false and the exact chosen color (including black).
const obj={},box=dom.element('div');E.form(box,obj,E.weaponExtFields(),()=>{});
const toggle=byLabel(box,'ユニットのATKを参照する');toggle.value='false';toggle.onchange();assert.equal(obj.useUnitAtk,false);
const color=byLabel(box,'演出色');assert.equal(color.type,'color');color.value='#000000';color.oninput();assert.equal(obj.fxColor,'#000000');
const base=box.all().find(e=>e.tagName==='INPUT'&&e.type==='number'&&e.min===0&&e.max===1000000);base.value='0';base.oninput();assert.equal(obj.baseAtk,0);
const ids={weapons:[{...w,id:'bad id'}],units:[{...unit,weaponIds:['bad id']}]};E.fixIds(ids);assert.equal(ids.units[0].weaponIds[0],ids.weapons[0].id);
console.log('PASS: weapon masters, references/update/reload/atomic failure, real damage and preview, legacy math, zero/false, schemas, color and ID repair');
})().catch(e=>{console.error(e);process.exitCode=1});
