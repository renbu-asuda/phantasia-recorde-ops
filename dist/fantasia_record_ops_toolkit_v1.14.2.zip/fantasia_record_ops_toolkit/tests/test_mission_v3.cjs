(async()=>{'use strict';
// 1.12.0: objective + add-on conditions, wave objects (triggers, rows, labels), boss inside a wave, 300-turn draw, objectiveStatus.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const c={window:{},console};vm.createContext(c);for(const f of ['shared/pro_core','shared/pro_battle'])vm.runInContext(read(f+'.js'),c);
const C=c.window.PROCore,B=c.window.PROBattle;
// ---- contract ----
const base={id:'m',enemies:['a','b'],rules:[]};
assert.deepEqual(C.missionExt({...base,objective:{type:'escort',escortUnitId:'v'}}).objective,{type:'escort',escortUnitId:'v'},'legacy escort kept');
assert.equal(C.missionIsV3({...base,objective:{type:'escort',escortUnitId:'v'}}),false);assert.equal(C.missionSchemaFor([{...base,waves:[['a']]}]),2,'legacy waves stay schema 2');
const v3={...base,objective:{type:'boss',bossWave:1,bossIndex:1,escortUnitId:'v'},waves:[{enemies:['a','boss'],rows:['front','back'],when:'remaining',value:1,label:'本隊'}],rules:[{type:'turn_limit',value:250}]};
const ext=C.missionExt(v3);assert.equal(ext.objective.bossWave,1);assert.equal(ext.waves[0].when,'remaining');assert(C.missionIsV3({...v3,...ext}));assert.equal(C.missionSchemaFor([{...v3,...ext}]),3);assert.deepEqual(C.rule({type:'turn_limit',value:250},'m'),{type:'turn_limit',value:250});
assert.deepEqual(C.missionExt({...base,waves:[{enemies:['a'],when:'cleared'}]}).waves,[['a']],'plain cleared waves are written in the old form');
for(const bad of [{objective:{type:'boss',bossWave:2}},{objective:{type:'boss',bossIndex:3}},{waves:[{enemies:['a'],when:'soon'}]},{waves:[{enemies:['a'],when:'turn'}]},{waves:[{enemies:[],when:'cleared'}]},{waves:[{enemies:['a'],rows:['middle']}]},{rules:[{type:'turn_limit',value:301}]}])assert.throws(()=>{const m={...base,...bad};C.missionExt(m);(m.rules||[]).forEach(r=>C.rule(r,'m'));},JSON.stringify(bad));
// Bundle schema 4 with missions v3 or terrains.
const bundle={format:C.BUNDLE_FORMAT,schemaVersion:4,packId:'p',units:[],missions:[{...v3}],items:[]};assert.equal(C.bundlePack(bundle).schemaVersion,4);
// Conditions text and wave text.
const names={a:'敵歩兵',boss:'指揮官',v:'輸送車'},cond=C.missionConditions({...v3,...ext},names);
assert.equal(cond.win,'勝利: ボス「指揮官」を倒す（第2波で出現）');assert.equal(cond.lose,'敗北: 味方が全滅する・護衛対象「輸送車」が倒される・250TURNを過ぎる');assert.match(cond.draw,/なし/);
assert.equal(C.missionConditions({...base},names).draw,'引き分け: 300TURNで決着がつかない');assert.equal(C.missionConditions({...base,waves:[['a'],['b']]}).win,'勝利: 全3波の敵をすべて倒す');
assert.equal(C.waveText(ext.waves[0],0,names),'第2波「本隊」（敵が残り1体以下になったら）：前衛 敵歩兵／後衛 指揮官');
assert.equal(C.formationText(['a','a','boss'],['front','front','back'],names),'前衛 敵歩兵×2／後衛 指揮官');
// ---- engine ----
const unit=(o)=>({id:o.id,name:o.name||o.id,hp:o.hp||1000,atk:o.atk||300,def:0,mob:o.mob||500,acc:o.acc||500,tags:[],skills:[],weapons:[C.weapon({name:'w',powerPct:100,accuracyPt:100,minDamage:o.min||1,hitsMin:1,hitsMax:1,hitPowerPct:100})],deploy:{player:true,enemy:true}});
const defs={hero:unit({id:'hero',hp:100000,atk:2000,mob:900}),weak:unit({id:'weak',hp:300,atk:1}),tank:unit({id:'tank',hp:3000,atk:1}),boss:unit({id:'boss',hp:6000,atk:1}),pebble:unit({id:'pebble',hp:1e6,atk:1,mob:0}),v:unit({id:'v',hp:500,atk:1}),killer:unit({id:'killer',hp:1e6,atk:5000,mob:950,min:5000})};
async function fight(mission,allies=['hero'],o={}){const logs=[];const ctx=B.createContext({allies:allies.map((id,i)=>B.combatant(defs[id],'ally','a'+i)),enemies:mission.enemies.map((k,i)=>B.combatant(defs[k],'enemy',`e_${k}_${i}`,{id:`${k}_${i}`,key:k,row:mission.enemyRows?.[i]||'front'})),mission,rng:o.rng||(()=>.5),enemyDefs:defs,unitDefs:defs,hooks:{log:h=>logs.push(h.replace(/<[^>]+>/g,''))}});
  if(mission.objective?.escortUnitId)ctx.allies.push(B.combatant(defs[mission.objective.escortUnitId],'ally','escort',{escort:true,row:'back'}));
  const statuses=[];ctx.hooks.render=()=>statuses.push(B.objectiveStatus(ctx));const r=await B.runBattle(ctx,o.run||{});return {r,ctx,logs,statuses};}
// turn-triggered wave with rows.
{const m={id:'t',enemies:['tank','tank'],waves:[{enemies:['weak','weak'],rows:['back','front'],when:'turn',value:2}]};const {r,ctx,logs}=await fight(m);
 assert.equal(r.outcome,'win');const spawned=ctx.enemies.filter(u=>u.key==='weak');assert.equal(spawned.length,2);assert.equal(spawned[0].row,'back');assert.equal(spawned[1].row,'front');assert(logs.some(l=>/第2波/.test(l)&&/〔後衛〕/.test(l)));}
// remaining-triggered wave appears when 1 enemy is left (before the field is empty).
{const m={id:'r',enemies:['weak','weak','tank'],waves:[{enemies:['weak'],when:'remaining',value:1}]};const {r,logs}=await fight(m);assert.equal(r.outcome,'win');const at=logs.findIndex(l=>/第2波/.test(l));assert(at>0);}
// boss in the last wave: cannot win before it appears; defeating it wins even with others alive.
{const m={id:'b',enemies:['weak'],objective:{type:'boss',bossWave:1,bossIndex:0},waves:[{enemies:['boss','pebble'],rows:['front','back'],when:'cleared'}]};const {r,ctx,statuses}=await fight(m);
 assert.equal(r.outcome,'win');assert(ctx.enemies.some(u=>u.key==='pebble'&&u.alive),'pebble survives — boss kill decides');assert(statuses.some(s=>s.boss&&s.boss.pending));assert(statuses.some(s=>s.boss&&s.boss.name==='boss'&&s.boss.hpPct<100));}
// bossHp-triggered wave.
{const m={id:'bh',enemies:['boss'],objective:{type:'boss',bossIndex:0},waves:[{enemies:['weak'],when:'bossHp',value:90}]};const {logs}=await fight(m,['hero'],{});assert(logs.some(l=>/第2波/.test(l)));}
// escort add-on with defense: escort dies → lose; survives → win at the turn count.
{const m={id:'d',enemies:['pebble'],objective:{type:'defense',turns:3,escortUnitId:'v'}};const {r,statuses}=await fight(m);assert.equal(r.outcome,'win');assert.equal(r.turns,3);assert(statuses.some(s=>s.defenseLeft===1&&s.escort.name==='v'));}
{const m={id:'d2',enemies:['killer'],objective:{type:'defense',turns:5,escortUnitId:'v'}};const {r,logs}=await fight(m,['weak']);assert.equal(r.outcome,'lose');assert(logs.some(l=>/v/.test(l)));}
// draw after 300 turns; turn limit up to 300 loses instead.
{const m={id:'s',enemies:['pebble']};const {r}=await fight(m,['tank']);assert.equal(r.outcome,'draw');assert.equal(r.turns,300);}
{const m={id:'s2',enemies:['pebble'],rules:[{type:'turn_limit',value:120}]};const {r,statuses}=await fight(m,['tank']);assert.equal(r.outcome,'lose');assert.equal(r.turns,120);assert(statuses.some(s=>s.turnsLeft===1));}
// objectiveStatus: wave counter and next-wave text.
{const m={id:'w',enemies:['tank'],waves:[['weak'],{enemies:['weak'],when:'turn',value:5}]};const {statuses}=await fight(m);assert.equal(statuses[0].totalWaves,3);assert.equal(statuses[0].nextWave,'前の敵がいなくなったら');assert(statuses.some(s=>s.wave===3));}
// ---- game: mission card text and battle header ----
{const {game}=require('./game_harness.cjs');const g=game();const m=g.run("MISSIONS.find(m=>m.id==='core-m-06')");assert.equal(m.objective.bossWave,1);
 const conds=g.run("missionConds(MISSIONS.find(m=>m.id==='core-m-06'))");assert.match(conds.win,/^勝利: ボス「.+」を倒す（第2波で出現）$/);assert.equal(conds.draw,'引き分け: 300TURNで決着がつかない');
 assert.match(g.run("waveLines(MISSIONS.find(m=>m.id==='core-m-06')).join('\\n')"),/第2波「指揮官部隊」（敵が残り2体以下になったら）：前衛 .+／後衛 .+\n第3波「親衛隊」（ボスのHPが50%以下になったら）/);
 assert.match(g.run("formationOf(MISSIONS.find(m=>m.id==='core-m-06'))"),/^前衛 .+／後衛 .+$/);
 assert.equal(g.run("objectiveHudText({wave:2,totalWaves:3,boss:{name:'指揮官機',hpPct:45,alive:true},defenseLeft:null,escort:{name:'輸送車',hpPct:80,alive:true},nextWave:'ボスのHPが50%以下になったら',turnsLeft:6,enemiesLeft:3})"),'第2波／全3波 ・ ボス「指揮官機」残り45% ・ 護衛「輸送車」80% ・ 次の波: ボスのHPが50%以下になったら ・ 制限まで あと6TURN ・ 敵 残り3体');
 assert.equal(g.run("objectiveHudText({wave:1,totalWaves:1,boss:{pending:true},defenseLeft:2,escort:null,nextWave:null,turnsLeft:null,enemiesLeft:1})"),'ボス: まだ出ていない ・ 防衛 あと2TURN ・ 敵 残り1体');
 // escort works with any win condition in the game too
 assert.equal(g.run("missionAvailable({...MISSIONS[0],objective:{type:'boss',bossIndex:0,escortUnitId:'core-u-truck'}})"),true);assert.equal(g.run("missionAvailable({...MISSIONS[0],objective:{type:'defense',turns:3,escortUnitId:'nobody'}})"),false);}
console.log('PASS: mission v3 contract (objective add-ons, wave objects, schema 3/4, limits), conditions/wave text, engine (turn/remaining/bossHp/cleared triggers, rows, boss in wave, escort+defense, 300-turn draw, limit 300), objectiveStatus');
})().catch(e=>{console.error(e);process.exitCode=1});
