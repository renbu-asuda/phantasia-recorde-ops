(async()=>{'use strict';
// 1.12.0: formation (front/back), wave, win/lose condition editors round-trip; minus-friendly number input; one test battle.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');const {setup,byText,byLabel}=require('./dom_lite.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const {document}=setup();const c={window:{},console,document,localStorage:{getItem:()=>null,setItem(){},removeItem(){}}};vm.createContext(c);
for(const f of ['pro_core','pro_battle','pro_templates','pro_editor'])vm.runInContext(read('shared/'+f+'.js'),c);
const C=c.window.PROCore,E=c.window.PROEditor;assert(E.version.split('.')[1]>=5,'editor 1.5+');
const list=[['a','敵兵（a）'],['b','狙撃兵（b）'],['boss','指揮官（boss）'],['v','輸送車（v）']];const opts={refs:()=>list};
const mount=(obj,fields)=>{const box=document.createElement('div');let n=0;E.form(box,obj,fields,()=>n++,opts);return {box,changes:()=>n};};
// ---- formation ----
{const obj={enemies:['a']};const {box}=mount(obj,[{key:'enemies',rowsKey:'enemyRows',type:'formation',label:'最初の敵',ref:'enemies'}]);
 const pick=byLabel(box,'追加する敵');pick.value='b';byText(box,'button','＋ 後衛に追加').click();assert.deepEqual(obj.enemies,['a','b']);assert.deepEqual(obj.enemyRows,['front','back']);
 assert(box.textContent.includes('後衛')&&box.textContent.includes('2. 狙撃兵'));
 byLabel(box,'狙撃兵を前衛へ移す').click();assert.equal(obj.enemyRows,undefined,'all front → no enemyRows');
 byLabel(box,'狙撃兵を後衛へ移す').click();byLabel(box,'敵兵を外す').click();assert.deepEqual(obj.enemies,['b']);assert.deepEqual(obj.enemyRows,['back']);
 for(let i=0;i<7;i++){byLabel(box,'追加する敵').value='a';byText(box,'button','＋ 前衛に追加').click();}assert.equal(obj.enemies.length,8);assert(byText(box,'button','＋ 前衛に追加').disabled,'max 8');}
// ---- waves ----
{const obj={enemies:['a'],waves:[['a']]};const {box}=mount(obj,[{key:'waves',type:'waves',label:'追加ウェーブ',ref:'enemies'}]);
 assert(box.textContent.includes('第2波（前の敵がいなくなったら）：前衛 敵兵'));
 const when=byLabel(box,'出現のタイミング');when.value='remaining';when.onchange();assert.deepEqual(C.clone(obj.waves[0]),{enemies:['a'],when:'remaining',value:2});
 assert(box.textContent.includes('第2波（敵が残り2体以下になったら）'));
 const val=box.querySelectorAll('input').find(i=>i.min===0&&i.max===8);val.value='1';val.oninput();assert.equal(obj.waves[0].value,1);
 byLabel(box,'追加する敵').value='boss';byText(box,'button','＋ 後衛に追加').click();assert.deepEqual(C.clone(obj.waves[0]),{enemies:['a','boss'],when:'remaining',rows:['front','back'],value:1});
 const label=box.querySelectorAll('input').find(i=>i.placeholder==='例: 増援部隊');label.value='本隊';label.oninput();assert.equal(obj.waves[0].label,'本隊');
 assert.doesNotThrow(()=>C.missionExt(obj));assert(C.missionIsV3({...obj,...C.missionExt(obj)}));
 byText(box,'button','＋ 波を追加').click();assert.equal(obj.waves.length,2);assert.deepEqual(C.clone(obj.waves[1]),[]);assert.throws(()=>C.missionExt(obj),/第3波が空です/);
 byText(box,'button','この波を削除').click();assert.equal(obj.waves.length,1,'first wave removed');
 // back to the old form: cleared, all front, no label
 const w2=byLabel(box,'出現のタイミング');w2.value='cleared';w2.onchange();assert.equal(obj.waves[0].value,undefined);}
{const obj={enemies:['a'],waves:[{enemies:['a','b'],rows:['front','back'],when:'turn',value:5}]};const {box}=mount(obj,[{key:'waves',type:'waves',ref:'enemies'}]);
 assert(box.textContent.includes('第2波（5TURN目に）：前衛 敵兵／後衛 狙撃兵'));byLabel(box,'狙撃兵を前衛へ移す').click();const w=byLabel(box,'出現のタイミング');w.value='cleared';w.onchange();assert.deepEqual(C.clone(obj.waves),[['a','b']],'compacted to the old array form');}
// ---- win / lose conditions ----
{const obj={enemies:['a','b'],waves:[{enemies:['boss'],when:'remaining',value:1}],rules:['夜間']};const {box}=mount(obj,E.missionExtFields().filter(f=>['objective','waves','rules'].includes(f.key)));
 const cond=()=>box.querySelector('.pro-conditions').textContent;assert(cond().includes('勝利: 全2波の敵をすべて倒す')&&cond().includes('引き分け: 300TURNで決着がつかない'));
 const type=byLabel(box,'勝ち方');type.value='boss';type.onchange();assert.deepEqual(C.clone(obj.objective),{type:'boss',bossIndex:0});
 const boss=byLabel(box,'倒すボス');assert(boss.children.some(o=>o.value==='1:0'&&o.textContent.includes('第2波 1番目: 指揮官')));boss.value='1:0';boss.onchange();assert.deepEqual(C.clone(obj.objective),{type:'boss',bossIndex:0,bossWave:1});
 const esc=byLabel(box,'護衛するユニット');esc.value='v';esc.onchange();assert.equal(obj.objective.escortUnitId,'v');
 const limit=box.querySelectorAll('input').find(i=>i.placeholder==='なし');limit.value='２５';limit.oninput();assert.deepEqual(C.clone(obj.rules),['夜間',{type:'turn_limit',value:25}],'full-width digits accepted, text rules kept');
 assert.equal(cond(),'勝利: ボス「指揮官」を倒す（第2波で出現）敗北: 味方が全滅する・護衛対象「輸送車」が倒される・25TURNを過ぎる引き分け: なし（TURN制限で敗北）');
 const t2=byLabel(box,'勝ち方');t2.value='annihilate';t2.onchange();assert.deepEqual(C.clone(obj.objective),{type:'escort',escortUnitId:'v'},'annihilate + escort keeps the old escort form');
 const e2=byLabel(box,'護衛するユニット');e2.value='';e2.onchange();assert.equal(obj.objective,undefined);
 const t3=byLabel(box,'勝ち方');t3.value='defense';t3.onchange();assert.deepEqual(C.clone(obj.objective),{type:'defense',turns:10});
 const turns=box.querySelectorAll('input').find(i=>i.max===300&&i.placeholder!=='なし');turns.value='150';turns.oninput();assert.equal(obj.objective.turns,150);assert(C.missionIsV3({...obj,...C.missionExt(obj)}),'defense over 99 turns is v3');
 const lim2=box.querySelectorAll('input').find(i=>i.placeholder==='なし');lim2.value='';lim2.oninput();assert.deepEqual(C.clone(obj.rules),['夜間']);}
// legacy chain stays chain while unchanged
{const obj={enemies:['a'],objective:{type:'chain'},waves:[['b']]};const {box}=mount(obj,[{key:'objective',type:'objective'}]);const esc=byLabel(box,'護衛するユニット');esc.value='';esc.onchange();assert.deepEqual(C.clone(obj.objective),{type:'chain'});}
// ---- number input ----
{const obj={};const {box}=mount(obj,[{key:'hit',label:'命中',type:'number',min:-100,max:100},{key:'reward',label:'報酬',type:'number',min:0}]);
 const [hit,reward]=box.querySelectorAll('input');assert.equal(hit.type,'text');assert.equal(hit.getAttribute('inputmode'),'decimal');assert.equal(reward.type,'number','non-negative fields keep the number keyboard');
 hit.value='－１５';hit.oninput();assert.equal(obj.hit,-15);assert.equal(hit.value,'-15');
 const sign=box.querySelectorAll('button').filter(b=>b.textContent==='±');assert.equal(sign.length,1,'± only on fields that accept negatives');sign[0].click();assert.equal(obj.hit,15);sign[0].click();assert.equal(obj.hit,-15);
 hit.value='-';hit.oninput();assert.equal(obj.hit,-15,'a lone minus sign keeps the previous value');assert.equal(E.normNum('ー３．５'),'-3.5');}
// statmap / terrainMods in the mission form accept negatives too
{const f=E.missionExtFields().find(x=>x.key==='terrainMods');assert(f.fields.filter(x=>x.type==='number').every(x=>x.min<0));}
// ---- test battle ----
{const unit=(id,o={})=>({id,name:o.name||id,hp:o.hp||1000,atk:o.atk||300,def:0,mob:500,acc:500,tags:[],skills:[],weapons:[C.weapon({name:'w',powerPct:100,accuracyPt:100,minDamage:1,hitsMin:1,hitsMax:1,hitPowerPct:100})],deploy:{player:true,enemy:true}});
 const defs={hero:unit('hero',{name:'勇者',hp:100000,atk:3000}),a:unit('a',{name:'敵兵',hp:500,atk:1}),boss:unit('boss',{name:'指揮官',hp:4000,atk:1})};
 const m={id:'tb',name:'テスト',enemies:['a','a'],maxDeploy:1,objective:{type:'boss',bossWave:1,bossIndex:0},waves:[{enemies:['boss'],when:'remaining',value:1,label:'本隊'}],rules:[]};
 const r=await E.testBattle(m,defs,[defs.hero],{seed:3});assert(r.ok,r.message);assert.equal(r.outcome,'win');assert.equal(r.reason,'ボス「指揮官」を倒した');assert.match(r.text,/第2波/);assert.match(r.text,/── 1TURN ──/);assert.match(r.text,/^結果: 勝利/);
 const lose=await E.testBattle({...m,enemies:['a'],objective:undefined,waves:undefined,rules:[{type:'turn_limit',value:2}]},{...defs,a:unit('a',{hp:1e7,atk:1})},[defs.hero],{seed:1});assert.equal(lose.outcome,'lose');assert.equal(lose.reason,'2TURNを過ぎた（TURN制限）');
 const miss=await E.testBattle({...m,waves:[['ghost']]},defs,[defs.hero]);assert(!miss.ok&&/ghost/.test(miss.message));}
// fixIds keeps wave objects
{const pack={units:[{id:'a',name:'A'}],missions:[{id:'m',name:'M',enemies:['a'],waves:[{enemies:['a'],when:'turn',value:2}]}],items:[]};E.fixIds(pack);assert.deepEqual(C.clone(pack.missions[0].waves[0]),{enemies:['a'],when:'turn',value:2});}
console.log('PASS: mission editors (front/back formation, waves with 4 triggers and old-form compaction, win/lose conditions with escort / limit / boss in a wave), minus-friendly number input, test battle log and reasons');
})().catch(e=>{console.error(e);process.exitCode=1});
