'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(process.env.PRO_NAV_HTML||__dirname+'/../index.html','utf8');
const elements=Object.fromEntries(['baseScreen','battleScreen','resultScreen','reviewBattleBtn','returnResultBtn','returnResultBottomBtn','returnBaseBtn','turnNumber'].map(id=>[id,{id,style:{},textContent:'',active:false,classList:{toggle(name,on){elements[id].active=on;}}}]));
assert(/\.battle-back-result\{display:none\}/.test(html));
const context={document:{getElementById:id=>elements[id]},window:{scrollTo(){}},battleRunning:false,render(){},setAction(){}};
vm.createContext(context);
const start=html.indexOf('function showScreen(name){'),end=html.indexOf('function renderResultScreen(',start);
vm.runInContext(html.slice(start,end),context);
for(const id of ['reviewBattleBtn','returnResultBtn','returnResultBottomBtn','returnBaseBtn']){
 const line=html.split('\n').find(s=>s.startsWith(`document.getElementById('${id}').onclick=`));assert(line,id+' handler missing');vm.runInContext(line,context);
}
const show=name=>vm.runInContext(`showScreen('${name}')`,context);
function visibleReturn(id='returnResultBtn'){return elements.battleScreen.active&&elements[id].style.display!=='none'&&!!elements[id].style.display;}
function active(name){for(const id of ['baseScreen','battleScreen','resultScreen'])assert.equal(elements[id].active,id===name+'Screen');}
show('base');active('base');assert(!visibleReturn());
// A battle starts with navigation hidden; completing it shows the result.
context.battleRunning=true;elements.returnResultBtn.style.display='none';show('battle');active('battle');assert(!visibleReturn());assert(!visibleReturn('returnResultBottomBtn'));
context.battleRunning=false;show('result');active('result');
for(let i=0;i<3;i++){
 elements.reviewBattleBtn.onclick();active('battle');assert(visibleReturn(),'completed-battle log must offer a visible return button');assert(visibleReturn('returnResultBottomBtn'));
 elements[i%2?'returnResultBottomBtn':'returnResultBtn'].onclick();active('result');assert(!visibleReturn());assert(!visibleReturn('returnResultBottomBtn'));
}
elements.returnBaseBtn.onclick();active('base');assert(!visibleReturn());assert.equal(elements.turnNumber.textContent,'--');
// A second battle must not inherit the log-view back button.
context.battleRunning=true;show('battle');active('battle');assert(!visibleReturn());assert(!visibleReturn('returnResultBottomBtn'));
context.battleRunning=false;show('result');elements.reviewBattleBtn.onclick();assert(visibleReturn());elements.returnResultBtn.onclick();elements.returnBaseBtn.onclick();active('base');
assert(!html.slice(html.indexOf('<div class="battle-controls">'),html.indexOf('<div class="arena"')).includes('class="secondary battle-back-result"'));
assert(html.includes('min-height:48px'));assert(html.indexOf('id="returnResultBottomBtn"')>html.indexOf('id="battleLog"'));
console.log('PASS: running battle hides back button; result → log → result → base; repeated review and second battle');
