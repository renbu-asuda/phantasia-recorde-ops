(async()=>{'use strict';
// 1.13.0: owned units are instances. The first copy's uid is the base id (older saves keep working);
// more copies get base__2, base__3… with their own HP, level, equipment, pilot, fatigue and battle id.
const assert=require('assert'),{game}=require('./game_harness.cjs');
const SAVE='vais_outer_ops_save_v1';

// ---- a new game: every unlocked player unit joins once, uid = base id ----
{
  const g=game(),run=g.run;
  const roster=run('state.roster');assert(roster.length>=7);assert(roster.every(e=>e.uid===e.base));
  assert(!roster.some(e=>e.base==='core-u-rin'||e.base==='core-u-guardian'),'locked units are not in the roster');
  assert.deepEqual(run('UNIT_MASTER.map(u=>u.id)'),roster.map(e=>e.uid));assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-tiger').baseId"),'core-u-tiger');
  // Joining later (mission recruit) adds one copy, once.
  run("state.recruited.push('core-u-rin');ensureUnitState();ensureUnitState();");assert.equal(run("copiesOf('core-u-rin')"),1);
  assert.equal(run("state.roster.filter(e=>e.uid==='core-u-rin').length"),1);
}

// ---- an older save (no roster) migrates without losing per-unit data ----
{
  const memory=new Map();
  memory.set(SAVE,JSON.stringify({credits:5000,units:{'core-u-tiger':{hp:100}},levels:{'core-u-tiger':{lv:5,exp:10,sp:2}},equip:{'core-u-tiger':['core-i-scope',null]},pilots:{'core-u-strider':'core-u-kai'},fatigue:{'core-u-tiger':30},recruited:['core-u-rin']}));
  const g=game({memory}),run=g.run;
  assert.equal(run('state.v'),2);assert(run("inRoster('core-u-tiger')&&inRoster('core-u-rin')"));
  assert.equal(run("levelOf('core-u-tiger')"),5);assert.equal(run("state.units['core-u-tiger'].hp"),100);assert.equal(run("fatigueOf('core-u-tiger')"),30);
  assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-tiger').acc-UNIT_MASTER.find(u=>u.id==='core-u-fox').acc!==0"),true);
  assert.deepEqual(run("equippedItems('core-u-tiger').map(i=>i.id)"),['core-i-scope']);
  assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-strider').pilotId"),'core-u-kai');
  run('save()');const saved=JSON.parse(memory.get(SAVE));assert(Array.isArray(saved.roster)&&saved.roster.length>=8);assert(saved.joined.includes('core-u-rin'));
}

// ---- several copies of one unit ----
const g=game(),run=g.run;
run("state.credits=100000;");
assert(run("hireUnit('core-h-tiger',false)"));assert(run("hireUnit('core-h-tiger',false)"));
assert.deepEqual(run("state.roster.filter(e=>e.base==='core-u-tiger').map(e=>e.uid)"),['core-u-tiger','core-u-tiger__2','core-u-tiger__3']);
assert.equal(run('state.credits'),100000-2400);
assert.deepEqual(run("['core-u-tiger','core-u-tiger__2','core-u-tiger__3'].map(unitName)"),['タイガー #1','タイガー #2','タイガー #3']);
assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-tiger__2').name"),'タイガー #2');
// Separate HP, level, fatigue.
run("addExp('core-u-tiger__2',500);state.units['core-u-tiger__3'].hp=1;state.fatigue['core-u-tiger__2']=40;ensureUnitState();");
assert(run("levelOf('core-u-tiger__2')>1&&levelOf('core-u-tiger')===1&&levelOf('core-u-tiger__3')===1"));
assert.equal(run("state.units['core-u-tiger__3'].hp"),1);assert(run("state.units['core-u-tiger'].hp>1"));assert.equal(run("fatigueOf('core-u-tiger')"),0);
assert(run("UNIT_MASTER.find(u=>u.id==='core-u-tiger__2').hp>UNIT_MASTER.find(u=>u.id==='core-u-tiger').hp"),'level growth is per copy');
// Separate equipment.
run("state.items['core-i-scope']=2;");assert(run("equipItem('core-u-tiger__2',0,'core-i-scope')"));
assert.deepEqual(run("equippedItems('core-u-tiger__2').map(i=>i.id)"),['core-i-scope']);assert.equal(run("equippedItems('core-u-tiger').length"),0);
// Battle ids never collide.
const ids=run("['core-u-tiger','core-u-tiger__2'].map(id=>makeAlly(id).combatId)");assert.notEqual(ids[0],ids[1]);
// Pilots are instances too: a second カイ can ride while the first rides another unit.
run("state.roster.push({uid:'core-u-kai__2',base:'core-u-kai'});state.roster.push({uid:'core-u-strider__2',base:'core-u-strider'});ensureUnitState();");
assert(run("assignPilot('core-u-strider','core-u-kai')"));assert(run("assignPilot('core-u-strider__2','core-u-kai__2')"));
assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-strider__2').pilot"),'カイ #2');assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-strider').pilotId"),'core-u-kai');
assert.match(run("deployProblem(MISSIONS[0],['core-u-kai__2'])"),/ストライダー #2に搭乗中/);
// A battle with two copies runs; the riding second pilot gains experience separately.
run("var seed=5;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};selected=['core-u-tiger','core-u-tiger__2','core-u-strider__2','core-u-jackal'];selectedMission='core-m-01';");
assert.equal(run("deployProblem(MISSIONS.find(m=>m.id==='core-m-01'),selected)"),'');
await run('deploy()');assert.equal(run('battleRunning'),false);
assert(run("levelInfo('core-u-kai__2').exp>0||levelOf('core-u-kai__2')>1"));assert.equal(run("levelInfo('core-u-kai').exp"),0);
assert(run("fatigueOf('core-u-tiger__2')>40||!state.settings.fatigue"));
// Rename.
assert(run("renameUnit('core-u-tiger__2','ベン')"));assert.equal(run("UNIT_MASTER.find(u=>u.id==='core-u-tiger__2').name"),'ベン');
assert(run("renameUnit('core-u-tiger__2','')"));assert.equal(run("unitName('core-u-tiger__2')"),'タイガー #2');
assert(run("renameUnit('core-u-tiger__2','あいうえおかきくけこさしすせそたちつてとなにぬ')"));assert.equal(run("unitName('core-u-tiger__2')").length,20);
// Fire: data removed, equipment back to the items, pilots and squads cleared.
run("savePreset(0);selected=['core-u-tiger__2'];");const scopes=run("state.items['core-i-scope']");
assert(run("fireUnit('core-u-tiger__2',false)"));
assert(!run("inRoster('core-u-tiger__2')"));assert.equal(run("state.items['core-i-scope']"),scopes+1);
for(const k of ['units','levels','equip','fatigue','rows'])assert(!run(`Object.hasOwn(state.${k},'core-u-tiger__2')`),k);
assert(!run("selected.includes('core-u-tiger__2')"));assert(!run("(state.presets[0]?.selected||[]).includes('core-u-tiger__2')"));
assert(run("fireUnit('core-u-kai__2',false)"));assert(!run("state.pilots['core-u-strider__2']"),'a dismissed pilot leaves the seat');
// The next hire reuses the free number; a fresh copy starts at Lv1.
assert(run("hireUnit('core-h-tiger',false)"));assert(run("inRoster('core-u-tiger__2')"));assert.equal(run("levelOf('core-u-tiger__2')"),1);
// Units that cannot be dismissed, and the last unit.
assert(!run("fireUnit('core-u-jackal',false)"));assert.match(run('lastNotice'),/解雇できません/);
assert.match(run("(()=>{const keep=state.roster.find(e=>e.uid==='core-u-fox');state.roster=[keep];return fireBlock('core-u-fox');})()"),/最後の1体/);
// Confirmation: cancelling keeps the unit.
{const g2=game({confirm:()=>false});assert(!g2.run("fireUnit('core-u-tiger')"));assert(g2.run("inRoster('core-u-tiger')"));assert(!g2.run("(state.credits=99999,hireUnit('core-h-tiger'))"));assert.equal(g2.run("copiesOf('core-u-tiger')"),1);}

// ---- save export / import keeps the roster and names ----
{
  const a=game(),r=a.run;r("state.credits=9999;hireUnit('core-h-mina',false);renameUnit('core-u-mina__2','サブ衛生兵');addExp('core-u-mina__2',300);");
  const data=r('JSON.stringify(exportSaveData())');assert.equal(JSON.parse(data).version,2);
  const b=game();b.run(`importSaveData(${data})`);assert.equal(b.run("unitName('core-u-mina__2')"),'サブ衛生兵');assert(b.run("levelOf('core-u-mina__2')>1"));
  // Bad roster entries are dropped.
  const c=game({memory:new Map([[SAVE,JSON.stringify({roster:[{uid:'__proto__',base:'x'},{uid:'a b',base:'core-u-fox'},{uid:'core-u-fox',base:'core-u-fox',name:'  '},{uid:'core-u-fox',base:'core-u-fox'}],joined:['core-u-fox']})]])});
  assert.deepEqual(c.run("state.roster.filter(e=>e.base==='core-u-fox').map(e=>e.uid)"),['core-u-fox']);assert.equal(c.run("rosterEntry('core-u-fox').name"),undefined);
}

console.log('PASS: unit instances — new game roster, old save migration, several copies (separate HP/level/equipment/fatigue/battle ids), instance pilots, battle with copies, rename, fire (data/equipment/pilot/squad cleanup, cannot-dismiss, last unit, cancel), reused numbers, save export v2 / import');
})().catch(e=>{console.error(e);process.exit(1);});
