/* PRO Item Pack Schema 2 / Game 1.7.0 */
window.VAIS_ITEM_PACK = {
  "format": "VAIS_OUTER_OPS_ITEM_PACK",
  "schemaVersion": 2,
  "packId": "core_items_v1",
  "packName": "基本補給アイテム",
  "items": [
    {
      "id": "repair_kit_s",
      "name": "応急修理キット",
      "desc": "基地で使用。味方1機のHPを回復。",
      "effect": {
        "type": "heal_hp_flat",
        "value": 1000
      }
    },
    {
      "id": "repair_kit_m",
      "name": "修理キット",
      "desc": "基地で使用。味方1機のHPを大きく回復。",
      "effect": {
        "type": "heal_hp_flat",
        "value": 2500
      }
    },
    {
      "id": "boost_hp",
      "name": "耐久強化キット",
      "desc": "基地で使用。指定した味方1機を恒久強化。",
      "effect": {
        "type": "stat_up_flat",
        "stat": "hp",
        "value": 250
      }
    },
    {
      "id": "boost_atk",
      "name": "攻撃強化キット",
      "desc": "基地で使用。指定した味方1機を恒久強化。",
      "effect": {
        "type": "stat_up_flat",
        "stat": "atk",
        "value": 10
      }
    },
    {
      "id": "boost_def",
      "name": "防御強化キット",
      "desc": "基地で使用。指定した味方1機を恒久強化。",
      "effect": {
        "type": "stat_up_flat",
        "stat": "def",
        "value": 10
      }
    },
    {
      "id": "boost_mob",
      "name": "機動強化キット",
      "desc": "基地で使用。指定した味方1機を恒久強化。",
      "effect": {
        "type": "stat_up_flat",
        "stat": "mob",
        "value": 10
      }
    },
    {
      "id": "boost_acc",
      "name": "命中強化キット",
      "desc": "基地で使用。指定した味方1機を恒久強化。",
      "effect": {
        "type": "stat_up_flat",
        "stat": "acc",
        "value": 10
      }
    },
    {
      "id": "repair_ratio",
      "name": "割合修理キット",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "heal_hp_pct",
        "value": 50
      }
    },
    {
      "id": "repair_full",
      "name": "完全修理キット",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "heal_hp_full"
      }
    },
    {
      "id": "revive_kit",
      "name": "再起動キット",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "revive_hp_pct",
        "value": 30
      }
    },
    {
      "id": "boost_ratio",
      "name": "攻撃増幅キット",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "stat_up_pct",
        "stat": "atk",
        "value": 5
      }
    },
    {
      "id": "boost_all",
      "name": "総合訓練キット",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "all_stats_up_flat",
        "value": 10
      }
    },
    {
      "id": "credit_case",
      "name": "資金ケース",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "credits_gain",
        "value": 500
      }
    },
    {
      "id": "skill_manual",
      "name": "火力訓練マニュアル",
      "desc": "基地で選択したユニットに使用。",
      "effect": {
        "type": "add_skill",
        "skill": {
          "id": "trained_firepower",
          "name": "火力訓練",
          "trigger": "before_attack",
          "effect": "damage_up_pct",
          "value": 10,
          "chance": 100,
          "maxUses": 0
        }
      }
    },
    {
      "id": "weapon_module",
      "name": "追加ライフルユニット",
      "desc": "歩兵タグの味方専用。増設ライフルを追加。",
      "effect": {
        "type": "add_weapon",
        "weapon": {
          "name": "増設ライフル",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 120,
          "accuracyPt": 5,
          "critPt": 0,
          "targetCount": 1,
          "weight": 1,
          "minDamage": 20,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100
        }
      },
      "requires": {
        "allTags": [
          "歩兵"
        ]
      }
    },
    {
      "id": "combined_training",
      "name": "複合訓練セット",
      "desc": "攻撃と照準を同時に強化。",
      "effects": [
        {
          "type": "stat_up_flat",
          "stat": "atk",
          "value": 10
        },
        {
          "type": "stat_up_flat",
          "stat": "acc",
          "value": 10
        }
      ]
    }
  ]
};
