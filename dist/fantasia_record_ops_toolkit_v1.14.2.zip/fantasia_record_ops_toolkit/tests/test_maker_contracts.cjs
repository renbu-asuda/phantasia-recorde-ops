const fs=require('fs'),vm=require('vm'),assert=require('assert');
for(const kind of ['unit','mission']){
 const html=fs.readFileSync(__dirname+'/../'+kind+'_maker.html','utf8'),line=name=>html.split('\n').find(l=>l.startsWith('function '+name+'('));let captured;
 const obj={packId:'test',units:[{id:'u',name:'unit'}],missions:[{id:'m',name:'mission',enemies:['u']}]};
 const ctx={window:{PROMaker:{download:(id,text)=>captured={id,text}}},validate:()=>true,outputObject:()=>obj,syncCurrent(){},alert:()=>{throw new Error('Unexpected alert')},toast(){},pack:obj,exported:[],$:id=>({id})};ctx.E={afterExport:(el,k)=>ctx.exported.push(k)};vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../shared/pro_core.js','utf8'),ctx);vm.runInContext(line('outputJs')+'\n'+line('download'),ctx);vm.runInContext('download()',ctx);assert.equal(captured.id,'test');assert.deepEqual(ctx.exported,[kind],'shows the next-step guidance after export');const marker=kind==='unit'?'VAIS_UNIT_PACK':'VAIS_MISSION_PACK';assert.equal(ctx.window.PROCore.parse(captured.text,marker).packId,'test');
}
console.log('PASS: both existing makers write through shared download/serialization contract');
