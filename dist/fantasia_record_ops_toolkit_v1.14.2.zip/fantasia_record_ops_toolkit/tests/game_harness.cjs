// Shared test harness for 1.11.0 tests: runs the game's main script in a vm with a tiny DOM.
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
const code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
function element(id){return {id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,hidden:false,checked:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0};}
function game({memory=new Map(),base=['outer_ops_units','outer_ops_missions','outer_ops_items'],confirm=()=>true}={}){
  const els={},alerts=[],shown=[];
  const head={appendChild(s){if(s.tag==='script'){const file=s.src.split('?')[0];try{vm.runInContext(read(file),c);setImmediate(()=>s.onload&&s.onload());}catch(e){setImmediate(()=>s.onerror&&s.onerror(e));}}}};
  const c={window:{scrollTo(){},PROFlow:{show:id=>shown.push(id)}},console:{...console,warn(){},error(){}},alerts,shown,setTimeout:f=>setImmediate(f),confirm,alert:x=>alerts.push(String(x)),
    document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>{const e=element(t);e.tag=t;return e;},querySelectorAll:()=>[],head,body:element('body')},
    localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)}};
  vm.createContext(c);for(const f of ['shared/pro_core','shared/pro_battle',...base])vm.runInContext(read(f+'.js'),c);
  vm.runInContext(code+'\nensureUnitState();',c);
  return {c,els,memory,alerts,shown,run:x=>vm.runInContext(x,c)};
}
module.exports={game,read,root};
