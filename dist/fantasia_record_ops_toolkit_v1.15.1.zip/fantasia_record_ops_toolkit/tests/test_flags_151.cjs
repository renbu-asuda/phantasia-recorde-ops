(async()=>{'use strict';
// 1.15.1: flag dictionary, where flags are set / needed, warnings, creator hints, plain-language summaries and templates.
const assert=require('assert'),vm=require('vm'),{read,game}=require('./game_harness.cjs'),{setup,byLabel,byText}=require('./dom_lite.cjs');
const {document}=setup();let confirmAnswer=true;const confirms=[];
const c={window:{},document,console,setTimeout:f=>f(),localStorage:{getItem:()=>null,setItem(){}},confirm:m=>{confirms.push(m);return confirmAnswer;},alert(){},prompt:()=>null};vm.createContext(c);
for(const f of ['pro_core','pro_battle','pro_features','pro_features_ui','pro_templates','pro_editor'])vm.runInContext(read('shared/'+f+'.js'),c);
const C=c.window.PROCore,F=c.window.PROFeatures,E=c.window.PROEditor,T=c.window.PROTemplates,UI=c.window.PROFeaturesUI;
const clone=x=>JSON.parse(JSON.stringify(x));

// ---- dictionary contract: display-only, never changes the schema number ----
const base={format:C.BUNDLE_FORMAT,schemaVersion:8,packId:'p',units:[],missions:[],items:[]};
const withNotes=C.bundlePack({...base,flagNotes:{boss_beaten:{name:' ボス撃破 ',desc:'ボスを倒した'},z:{}}});
assert.deepEqual(clone(withNotes.flagNotes),{boss_beaten:{name:'ボス撃破',desc:'ボスを倒した'},z:{}});assert.equal(withNotes.schemaVersion,C.bundlePack(base).schemaVersion,'the dictionary never raises the schema number');
assert.equal(C.bundlePack(base).flagNotes,undefined);assert.equal(C.bundlePack({...base,flagNotes:{}}).flagNotes,undefined,'an empty dictionary is not written');
assert.deepEqual(clone(C.bundlePack(clone(withNotes)).flagNotes),clone(withNotes.flagNotes),'round trip');
for(const bad of ['{"a b":{}}','{"__proto__":{}}','{"x":"text"}','{"x":[]}'])assert.throws(()=>C.flagNotes(JSON.parse(bad)),/フラグ/);
assert.throws(()=>C.flagNotes(Object.fromEntries(Array.from({length:201},(_,i)=>['f'+i,{}]))),/200件/);
assert.equal(C.flagNotes({a:{name:'x'.repeat(100),desc:'y'.repeat(500)}}).a.name.length,40);

// ---- usage and warnings ----
const pack={flagNotes:{boss_beaten:{name:'ボス撃破'},unused_note:{name:'どこにも使わない'}},missions:[
 {id:'m1',name:'第一章',enemies:['e'],events:[{id:'ev',when:'boss_hp',value:50,flags:{'boss-beaten':true}}],story:{choices:[{text:'右へ',flags:{route_a:true}},{text:'左へ',flags:{route_b:true}}]},resultFlags:{win:{boss_beaten:true,cleared_m1:true},lose:{retry:true}}},
 {id:'m2',name:'第二章',enemies:['e'],requires:{flags:{route_a:true,boss_beaten:true,never_set:true}}}]};
const sites=F.flagSites(pack);assert.equal(sites.filter(x=>x.mode==='set').length,6);assert.equal(sites.filter(x=>x.mode==='need').length,3);
assert(sites.some(x=>x.id==='route_a'&&x.mode==='set'&&x.where==='選択肢「右へ」'&&x.missionId==='m1'));assert(sites.some(x=>x.id==='retry'&&x.where==='敗北したとき'));
const rep=F.flagReport(pack),row=id=>rep.rows.find(r=>r.id===id);
assert(row('never_set').issues.some(i=>i.level==='warn'&&/成立させる場所がありません/.test(i.text)),'needed but never set');
assert(!row('route_a').issues.some(i=>/成立させる場所がありません/.test(i.text)));
assert(row('route_b').issues.some(i=>/出撃条件で使っている場所がありません/.test(i.text)),'set but never used');
assert(row('unused_note').issues.some(i=>/どこでも使われていません/.test(i.text)));
assert(row('cleared_m1').issues.some(i=>/未登録/.test(i.text))&&!row('boss_beaten').issues.some(i=>/未登録/.test(i.text)));
assert(row('boss-beaten').issues.some(i=>/boss_beaten.*似ています/.test(i.text)),'case/-/_ spelling twins are reported');
assert(!row('route_a').issues.some(i=>/似ています/.test(i.text)),'route_a / route_b are deliberate variants');
assert.deepEqual(clone(F.similarFlags(['route_a','route_b','stage1','stage2','boss_down','boss_dawn','Boss-Beaten','boss_beaten','abc','abd'])),[['Boss-Beaten','boss_beaten'],['boss_dawn','boss_down']]);
assert(rep.warnings.every(w=>typeof w.text==='string'&&w.id));
assert.equal(F.flagLabel(pack,'boss_beaten'),'ボス撃破（boss_beaten）');assert.equal(F.flagLabel(pack,'x'),'x');

// ---- rename everywhere ----
{const p=clone(pack);const n=F.renameFlag(p,'boss-beaten','boss_x');assert.equal(n,1);assert(p.missions[0].events[0].flags.boss_x===true&&!('boss-beaten' in p.missions[0].events[0].flags));
 const q=clone(pack);assert.equal(F.renameFlag(q,'boss_beaten','boss_done'),2,'result flag and sortie condition (the dictionary entry moves too)');assert(q.flagNotes.boss_done&&!q.flagNotes.boss_beaten);assert.equal(q.missions[1].requires.flags.boss_done,true);
 assert.deepEqual(Object.keys(q.missions[1].requires.flags),['route_a','boss_done','never_set'],'order is kept');
 assert.throws(()=>F.renameFlag(clone(pack),'route_a','route_b'),/既に使われています/);assert.throws(()=>F.renameFlag(clone(pack),'route_a','bad id'),/ID/);
 const merged=clone(pack);F.renameFlag(merged,'route_a','route_b',true);assert.equal(F.flagSites(merged).filter(x=>x.id==='route_a').length,0);
 assert.equal(F.renameFlag(clone(pack),'route_a','route_a'),0);
 const out=C.missionExt(clone(q.missions[0]));assert(out.resultFlags.win.boss_done);}
{const p={};F.setFlagNote(p,'a',{name:'名',desc:'説'});assert.deepEqual(clone(p.flagNotes),{a:{name:'名',desc:'説'}});F.deleteFlagNote(p,'a');assert.equal(p.flagNotes,undefined);assert.throws(()=>F.setFlagNote(p,'a b',{}));}

// ---- plain-language summaries ----
c.window.PROFeatures.setNameResolver(id=>({boss:'ボス',leader:'隊長'}[id]||id));
assert.equal(F.describeEvent({id:'e',when:'turn',value:3,lines:[{speaker:'',text:'x'}]},pack),'TURN3に達したとき: 会話1行');
assert.match(F.describeEvent({id:'e',when:'boss_hp',value:50,flags:{boss_beaten:true},lines:[{text:'a'},{text:'b'}]},pack),/ボスのHPが50%以下になったとき: 会話2行、ボス撃破（boss_beaten）を成立/);
assert.match(F.describeEvent({id:'e',when:'unit_down',unitId:'boss',requiredUnitId:'leader',terrain:'森林'},pack),/「隊長」が出撃しているとき限定で、「ボス」が撃破されたとき: 地形を「森林」に変更/);
assert.match(F.describeEvent({id:'e',when:'turn',value:2},pack),/何も起きません/);
assert.match(F.describeChoice({text:'右へ',flags:{route_a:true},lines:[{text:'x'}]},pack),/選択肢「右へ」: route_aを成立、選択後の会話1行/);
assert.match(F.describePhase({id:'p',name:'覚醒',cond:{all:[{type:'turn_ge',value:3},{type:'hp_below',value:50}]},stats:{atk:800,def:0},hpMode:'ratio',weaponIds:['w'],skillIds:[],lines:[{text:'a'}]}),/3TURN目以降 かつ 自分のHPが50%以下.*ATK 800・DEF 0 に.*割合を維持.*武装を1個に切り替え.*スキルを外す.*会話1行/);
assert.match(F.describePhase({id:'p',hpMode:'value',hpValue:900,cond:{type:'hp_below',value:30}}),/HPを 900 に/);
assert.match(F.describeResultFlags({win:{a:true},lose:{b:false}},{}),/勝利: aを成立 ／ 敗北: bを不成立/);

// ---- templates are valid data ----
const unit={id:'u',name:'兵',atk:400,def:50,mob:600,hp:3000};
for(const t of F.templates.phases){const ph=t.make(unit);assert.doesNotThrow(()=>C.phases([ph],'t'),t.label);assert(F.describePhase(ph).length>10);}
let registered=[];UI.constructor;F.setFlagSource({notes:()=>({}),known:()=>[],register:(id,name)=>registered.push([id,name])});
const mission={id:'m',name:'m',enemies:['boss']};
for(const t of F.templates.events){const ev=t.make(mission);assert.doesNotThrow(()=>C.missionEvents([ev],'t'),t.label);}
assert(registered.some(([id])=>id==='boss_weak')&&registered.some(([id])=>id==='enemy_down'),'sample flags are registered when a dictionary is open');
for(const t of F.templates.choices)assert.doesNotThrow(()=>C.missionExt({id:'m',name:'m',enemies:['a'],story:{choices:[t.make()]}}),t.label);
F.setFlagSource(null);assert.doesNotThrow(()=>F.templates.events[1].make(mission),'templates work without a dictionary');
for(const k of ['awakening','warcry','lastresort']){const sk=T.skillByKey(k,[]);assert(sk,k);const n=C.skill(sk);assert(n.effects.length>=2,k);assert(!/^[^:]*: [^:]*ターン開始: /.test(C.skillText(n)),'composite text does not repeat the trigger');}
assert(T.skills.some(s=>s.label.startsWith('複合')));

// ---- creator hints ----
{const hp={units:[{id:'u',name:'ユニット',phases:[{id:'p1',name:'空',cond:{type:'hp_below',value:50},hpMode:'ratio',stats:{}},{id:'p2',name:'変化',cond:{type:'hp_below',value:50},hpMode:'ratio',stats:{atk:900}}]}],
  missions:[{id:'m',name:'作戦',enemies:['e'],objective:{type:'clear'},events:[{id:'empty',when:'turn',value:1},{id:'down',when:'unit_down'},{id:'bossev',when:'boss_hp',value:50,lines:[{text:'a'}]},{id:'waveev',when:'wave',value:2,lines:[{text:'a'}]},{id:'okev',when:'turn',value:2,lines:[{text:'a'}]},{id:'ghost',when:'unit_down',unitId:'nobody',lines:[{text:'a'}]}],story:{choices:[{text:'無効'},{text:'ok',flags:{f:true}}]}},
   {id:'m2',name:'一択',enemies:['e'],story:{choices:[{text:'だけ',flags:{f:true}}]},objective:{type:'boss',bossIndex:0},events:[{id:'bossok',when:'boss_hp',value:50,lines:[{text:'a'}]}]}]};
 const hints=F.authoringHints(hp),txt=hints.map(h=>h.text).join('\n');
 assert(/イベント「empty」は、会話・地形変更・フラグのどれも設定されておらず/.test(txt));assert(/イベント「down」は「撃破を検知するユニット」が未設定/.test(txt));
 assert(/イベント「bossev」は「ボスのHP」で発生しますが/.test(txt)&&!/イベント「bossok」/.test(txt),'boss events are fine when the mission has a boss');
 assert(/イベント「waveev」は「第n波」/.test(txt));assert(!/イベント「okev」/.test(txt));assert(/撃破ユニット「nobody」がこのパックにありません/.test(txt));
 assert(/選択肢「無効」は、選んでも/.test(txt));assert(/選択肢が1つだけです/.test(txt));assert(/段階「空」は能力・武装/.test(txt)&&!/段階「変化」/.test(txt));
 assert(hints.every(h=>['units','missions','flags'].includes(h.kind)&&h.id));assert(hints.find(h=>h.kind==='units').step===3);assert(hints.find(h=>h.kind==='missions').step===3);
 assert.deepEqual(F.authoringHints({missions:[],units:[]}),[]);}

// ---- flag editor UI (dictionary picker) ----
const dict={a:{name:'一つ目',desc:'説明です'},b:{}};const store={notes:dict,sets:0};
F.setFlagSource({notes:()=>store.notes,known:()=>['a','b','c_used'],register:(id,name)=>{store.notes[id]=name?{name}:{};}});
{const obj={flags:{a:true}};let changes=0;const host=document.createElement('div');UI.flagsEditor(host,obj,'flags',()=>changes++);
 assert(host.textContent.includes('一つ目（a）')&&host.textContent.includes('説明です'),'registered flags show their name and note');
 const pick=byLabel(host,'追加するフラグ');assert(pick);const labels=pick.children.map(o=>o.textContent);assert(labels.includes('b')&&labels.includes('c_used')&&!labels.includes('一つ目（a）'),'already-set flags are not offered again');
 pick.value='b';pick.onchange();assert.equal(obj.flags.b,true);assert(changes>=1);
 // unregistered flag → one-tap register button
 const o2={flags:{c_used:true}},h2=document.createElement('div');UI.flagsEditor(h2,o2,'flags',()=>{});assert(byText(h2,'button','辞書に登録'));
 // delete keeps the object tidy
 const del=byText(host,'button','削除');del.click();assert(Object.keys(obj.flags||{}).length<2);
 // new flag: similar spelling asks first, a fresh ID is registered
 const o3={},h3=document.createElement('div');UI.flagsEditor(h3,o3,'flags',()=>{});const p3=byLabel(h3,'追加するフラグ');p3.value='__new';p3.onchange();
 const inputs=h3.querySelectorAll('input');inputs[0].value='A';inputs[0].onchange();const make=byText(h3,'button','作って追加');confirms.length=0;confirmAnswer=false;make.click();assert(confirms.length===1&&/似ています/.test(confirms[0]),'a near-duplicate is questioned');assert.equal(o3.flags,undefined,'cancel creates nothing');
 inputs[0].value='brand_new_flag';inputs[0].onchange();inputs[1].value='新しい旗';inputs[1].onchange();confirmAnswer=true;byText(h3,'button','作って追加').click();assert.equal(o3.flags.brand_new_flag,true);assert.equal(store.notes.brand_new_flag.name,'新しい旗');
 // an invalid ID is refused without registering
 const o4={},h4=document.createElement('div');UI.flagsEditor(h4,o4,'flags',()=>{});byLabel(h4,'追加するフラグ').value='__new';byLabel(h4,'追加するフラグ').onchange();let alerted='';c.alert=m=>alerted=m;vm.runInContext('0',c);
 const i4=h4.querySelectorAll('input');i4[0].value='bad id';i4[0].onchange();byText(h4,'button','作って追加').click();assert.equal(o4.flags,undefined);}
F.setFlagSource(null);
{const obj={},host=document.createElement('div');UI.flagsEditor(host,obj,'flags',()=>{});assert(byLabel(host,'追加するフラグ'),'works without a dictionary (standalone makers)');}

// ---- editor lists: summaries as titles, templates, help ----
F.setFlagSource({notes:()=>({boss_weak:{name:'ボス弱体'}}),known:()=>['boss_weak'],register:()=>{}});
{const m={id:'m',name:'m',enemies:['boss'],events:[{id:'x',when:'boss_hp',value:40,flags:{boss_weak:true}}],story:{choices:[{text:'進む',flags:{route_a:true}}]}};
 const host=document.createElement('div');E.form(host,m,E.missionExtFields(),()=>{},{refs:()=>[['boss','ボス']]});
 assert(host.textContent.includes('イベント1: ボスのHPが40%以下になったとき: ボス弱体（boss_weak）を成立'),'event title is a summary');
 assert(host.textContent.includes('選択肢1: 選択肢「進む」: route_aを成立'));assert(host.textContent.includes('「3TURN目に会話」')||host.textContent.includes('各イベントは一戦闘に一度だけ'),'help is shown');
 const tpl=byLabel(host,'戦闘中イベント（会話・地形変化・フラグ）のテンプレート');assert(tpl,'template select');tpl.value='0';tpl.onchange();assert.equal(m.events.length,2);assert.equal(m.events[1].when,'turn');
 const ctpl=byLabel(host,'作戦前の選択肢（選ぶとフラグが立つ。スキップ不可）のテンプレート');ctpl.value='1';ctpl.onchange();assert.equal(m.story.choices.length,2);assert.equal(m.story.choices[1].text,'迂回する');
 assert.doesNotThrow(()=>C.missionExt(clone(m)));
 const u={id:'u',name:'U',atk:400,def:0,mob:500,hp:3000};const uh=document.createElement('div');E.form(uh,u,[E.unitExtFields().find(f=>f.key==='phases')],()=>{},{});
 const ptpl=byLabel(uh,'段階変化・変形（戦闘中に条件を満たすと、能力・武装・スキルが切り替わる）のテンプレート');assert(ptpl);ptpl.value='0';ptpl.onchange();assert.equal(u.phases[0].stats.atk,600,'template uses the unit\'s own ATK');assert(uh.textContent.includes('段階1: 覚醒／自分のHPが50%以下'));}
F.setFlagSource(null);

// ---- game / makers wiring ----
const g=game();const pk={format:C.BUNDLE_FORMAT,schemaVersion:9,packId:'fl',packName:'フラグ',flagNotes:{boss_beaten:{name:'ボス撃破'}},units:[],missions:[],items:[]};
{const v=g.run(`validateBundlePack(${JSON.stringify({...pk,units:[{id:'u',name:'U',hp:1000,atk:100,def:0,mob:100,acc:100,weapons:[{name:'w',attackType:'ranged',damageType:'physical',powerPct:100,accuracyPt:0,critPt:0,targetCount:1,weight:1}],deploy:{player:true,enemy:true}}]})})`);assert.equal(v.flagNotes.boss_beaten.name,'ボス撃破','the game keeps the dictionary');}
const cm=read('combined_maker.html');assert(cm.includes('id="flagsScene"')&&cm.includes("['flags','フラグ']")&&cm.includes('function drawFlags()')&&cm.includes('function drawHints()')&&cm.includes('authoringHints(pack)'));
assert(cm.includes("F.setFlagSource({notes:()=>pack.flagNotes||{}")&&cm.includes('pack.flagNotes={...(pack.flagNotes||{}),...b.flagNotes}'));
for(const f of ['index.html','combined_maker.html','item_maker.html','mission_maker.html','unit_maker.html'])assert(read(f).includes("['PROFeatures','1.1.0'"),f+' guard');

console.log('PASS: flag dictionary (display-only, no schema change), usage and warnings, similar-spelling check, rename/merge, summaries, templates, creator hints, dictionary picker UI, editor titles/templates, game and maker wiring');
})().catch(e=>{console.error(e);process.exitCode=1;});
