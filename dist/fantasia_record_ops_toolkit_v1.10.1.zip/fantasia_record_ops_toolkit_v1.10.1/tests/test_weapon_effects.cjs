(async()=>{'use strict';
// 1.10.1: weapon effects that fire before / after the weapon is used.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',read=f=>fs.readFileSync(root+'/'+f,'utf8');
const ctx0={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx0);
for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor'])vm.runInContext(read(f+'.js'),ctx0);
const C=ctx0.window.PROCore,B=ctx0.window.PROBattle,E=ctx0.window.PROEditor,T=ctx0.window.PROTemplates;

// ---- data contract ----
const W=(effects,extra={})=>C.weapon({name:'試験砲',attackType:'ranged',damageType:'physical',powerPct:100,accuracyPt:100,critPt:0,targetCount:1,weight:1,minDamage:1,hitsMin:1,hitsMax:1,hitPowerPct:100,...extra,...(effects?{effects}:{})});
{
  const w=W([{timing:'before',effect:'atk_up_pct',value:20,duration:3},{timing:'after',effect:'def_down_pct',value:15,when:'hit',chance:50},{timing:'after',effect:'drain_pct',value:30},{timing:'before',effect:'tag_damage_up_pct',value:30,tag:'装甲'}]);
  assert.equal(w.effects.length,4);assert.equal(w.effects[1].when,'hit');assert.equal(w.effects[0].chance,undefined,'chance 100 is omitted');
  assert(C.weaponIsExtended(w));assert(!C.weaponIsExtended(W([])));assert.equal(W([]).effects,undefined,'empty list is not written');
  assert.equal(C.unitSchemaFor([{id:'u',weapons:[w]}],[]),3);
  assert.deepEqual(C.weaponEffectsText(w),['使用前: 自分のATK+20%（3TURN）','使用後: 1発以上命中したら、50%の確率で命中した相手のDEF-15%（2TURN）','使用後: 与ダメージの30%を吸収','使用前: 対「装甲」ダメージ+30%']);
  for(const t of Object.keys(C.weaponTimings))for(const eff of C.weaponEffectsAllowed[t]){const e={timing:t,effect:eff,value:10,...(eff==='tag_damage_up_pct'?{tag:'x'}:{})};C.weaponEffect(e);assert(!/undefined/.test(C.weaponEffectText(e)),eff);}
  const bad=[[{timing:'before',effect:'drain_pct',value:1}],[{timing:'after',effect:'damage_up_pct',value:1}],[{timing:'before',effect:'stun',when:'hit'}],[1,2,3,4,5].map(()=>({timing:'after',effect:'stun'})),[{timing:'x',effect:'stun'}],[{timing:'after',effect:'recoil_pct',value:200}],[{timing:'after',effect:'stun',target:'nobody'}],[{timing:'before',effect:'tag_damage_up_pct',value:5}],'x'];
  for(const b of bad){assert.throws(()=>W(b));let msg='';try{W(b)}catch(e){msg=e.message;}const f=E.friendlyError(msg);assert(f.message&&f.fix,msg);}
}

// ---- engine ----
const unit=(o={})=>({id:o.id||'u',name:o.name||'U',hp:1000,atk:300,def:100,mob:0,acc:500,tags:[],skills:[],weapons:[],...o});
const logs=[];
async function fire(weapon,{att={},defs=[{}],opts={},rng=()=>.3,pre}={}){
  logs.length=0;const a=B.combatant(unit(att),'ally','a1'),ds=defs.map((d,i)=>B.combatant(unit({name:'D'+i,...d}),'enemy','e'+i));
  const ctx=B.createContext({allies:[a],enemies:ds,rng,hooks:{logSkill:(u,sk,d)=>logs.push({u:u.name,sk,d})}});ctx.turn=1;if(pre)pre(a,ds,ctx);
  await B.resolveWeapon(ctx,a,weapon,ds.filter(d=>d.alive),opts);return {a,ds,ctx,dealt:ds.map(d=>d.maxHp-d.currentHp)};
}
const base=(await fire(W())).dealt[0];assert(base>0);
// Before: own ATK up raises this attack's damage; enemy DEF down applies to this attack too.
{const r=await fire(W([{timing:'before',effect:'atk_up_pct',value:50}]));assert(r.dealt[0]>base);assert(r.a.status.buffs.some(b=>b.stat==='atk'&&b.pct===50&&b.turns===2));assert(logs[0].sk.weaponEffect);assert.match(logs[0].d,/ATK \+50%/);}
{const r=await fire(W([{timing:'before',effect:'def_down_pct',value:50}]));assert(r.dealt[0]>base);assert(r.ds[0].status.buffs.some(b=>b.stat==='def'&&b.pct===-50));}
{const r=await fire(W([{timing:'before',effect:'damage_up_pct',value:100}]));assert(Math.abs(r.dealt[0]-base*2)<=1);}
{const r=await fire(W([{timing:'before',effect:'def_pierce_pct',value:100}]));assert(r.dealt[0]>base);}
{const r=await fire(W([{timing:'before',effect:'tag_damage_up_pct',value:100,tag:'装甲'}]),{defs:[{tags:['装甲']}]});assert(Math.abs(r.dealt[0]-base*2)<=1);const n=await fire(W([{timing:'before',effect:'tag_damage_up_pct',value:100,tag:'装甲'}]));assert.equal(n.dealt[0],base);assert.equal(logs.length,0);}
// After: the debuff lands after this attack, so this attack's damage is unchanged.
{const r=await fire(W([{timing:'after',effect:'def_down_pct',value:50,duration:3}]));assert.equal(r.dealt[0],base);assert(r.ds[0].status.buffs.some(b=>b.stat==='def'&&b.turns===3));}
// when: hit / kill / crit
{const miss=await fire(W([{timing:'after',effect:'stun',when:'hit'}],{accuracyPt:-100}),{rng:()=>.99});assert.equal(miss.ds[0].status.stun,0);const hit=await fire(W([{timing:'after',effect:'stun',when:'hit'}]));assert.equal(hit.ds[0].status.stun,1);}
{const r=await fire(W([{timing:'after',effect:'extra_action',when:'kill'}]));assert(!r.a.extraActions);const k=await fire(W([{timing:'after',effect:'extra_action',when:'kill'}]),{defs:[{hp:10}]});assert.equal(k.a.extraActions,1);}
{const r=await fire(W([{timing:'after',effect:'shield',value:40,when:'crit'}]));assert(!r.a.status.shield);const c=await fire(W([{timing:'after',effect:'shield',value:40,when:'crit'}],{critPt:100}));assert.equal(c.a.status.shield,40);}
// Drain and recoil.
{const r=await fire(W([{timing:'after',effect:'drain_pct',value:50}]),{pre:a=>{a.currentHp=100;}});assert.equal(r.a.currentHp,100+Math.round(base/2));}
{const r=await fire(W([{timing:'after',effect:'recoil_pct',value:10}]));assert.equal(r.a.currentHp,900);const f=await fire(W([{timing:'after',effect:'recoil_pct',value:100}]),{pre:a=>{a.currentHp=50;}});assert.equal(f.a.currentHp,1);assert(f.a.alive);}
// Counter attacks, 0% chance and unmet conditions do not fire.
{const r=await fire(W([{timing:'before',effect:'atk_up_pct',value:50},{timing:'after',effect:'stun'}]),{opts:{counter:true}});assert.equal(r.dealt[0],base);assert.equal(r.ds[0].status.stun,0);assert.equal(logs.length,0);}
{const r=await fire(W([{timing:'after',effect:'stun',chance:0}]));assert.equal(r.ds[0].status.stun,0);}
{const r=await fire(W([{timing:'before',effect:'damage_up_pct',value:100,cond:{type:'hp_below',value:50}}]));assert.equal(r.dealt[0],base);const low=await fire(W([{timing:'before',effect:'damage_up_pct',value:100,cond:{type:'hp_below',value:50}}]),{pre:a=>{a.currentHp=300;}});assert(low.dealt[0]>base);}
// "When hit" effects only reach targets that were hit.
{let n=0;const r=await fire(W([{timing:'after',effect:'stun',when:'hit'}],{targetCount:2,accuracyPt:0}),{defs:[{},{mob:100000}],rng:()=>.5});assert.equal(r.ds[0].status.stun,1);assert.equal(r.ds[1].status.stun,0);assert.equal(r.dealt[1],0);}
// Hostile effects hit every target of this attack; support effects can reach allies.
{const r=await fire(W([{timing:'after',effect:'stun'}],{targetCount:3}),{defs:[{},{},{}]});assert(r.ds.every(d=>d.status.stun===1));}
{const r=await fire(W([{timing:'after',effect:'burn',value:20,target:'random_enemy'}],{targetCount:1}),{defs:[{},{}]});assert.equal(r.ds.filter(d=>d.status.burn).length,1);}
// Weapons without effects behave exactly as before (same RNG stream).
{const seq=()=>{let s=1;return ()=>{s=(s*16807)%2147483647;return s/2147483647;};};const a=await fire(W(null,{hitsMin:1,hitsMax:6,critPt:20}),{rng:seq()}),b=await fire(W([],{hitsMin:1,hitsMax:6,critPt:20}),{rng:seq()});assert.deepEqual(a.dealt,b.dealt);}
// Damage preview counts sure before-effects.
{const att=unit(),def=unit(),p0=B.damagePreview(att,W(),def),p1=B.damagePreview(att,W([{timing:'before',effect:'damage_up_pct',value:100}]),def),p2=B.damagePreview(att,W([{timing:'before',effect:'damage_up_pct',value:100,chance:50}]),def);assert(Math.abs(p1.perHitAvg-p0.perHitAvg*2)<=1);assert.equal(p2.perHitAvg,p0.perHitAvg);}
// Full battle with effect weapons finishes.
{const w=W([{timing:'before',effect:'atk_up_pct',value:10},{timing:'after',effect:'def_down_pct',value:10,when:'hit'},{timing:'after',effect:'drain_pct',value:20},{timing:'after',effect:'recoil_pct',value:2}],{hitsMax:3});const sim=await B.simulate({allies:[unit({id:'a',weapons:[w]}),unit({id:'b',weapons:[w]})],enemies:['x','x','x'],enemyDefs:{x:unit({id:'x',weapons:[w]})},unitDefs:{},trials:10,seed:7});assert.equal(sim.trials,10);}

// ---- makers ----
{
  const keys=E.weaponExtFields().map(f=>f.key);assert(keys.includes('effects'));assert(E.WEAPON_EXT_KEYS.includes('effects'));
  const fx=E.weaponExtFields().find(f=>f.key==='effects');assert(fx.presets.length>=6);for(const p of fx.presets)C.weaponEffect(p.make());
  const w=W([{timing:'after',effect:'stun',when:'hit',chance:30}]);assert.match(E.describeWeapon(w),/使用後/);
  assert.deepEqual(C.weapon(JSON.parse(JSON.stringify(E.pick(w,E.WEAPON_EXT_KEYS)))&&JSON.parse(JSON.stringify(w))).effects,w.effects);
  const fxTemplates=T.weapons.filter(t=>t.weapon.effects?.length);assert(fxTemplates.length>=6);for(const t of fxTemplates){C.weapon(t.weapon);assert(E.describeWeapon(t.weapon).includes('使用'));}
  const eFields=E.weaponEffectFields();const after={timing:'after',effect:'stun'},before={timing:'before',effect:'atk_up_pct'};
  const effSel=eFields.find(f=>f.key==='effect');assert(Object.keys(effSel.choices(after)).includes('drain_pct'));assert(!Object.keys(effSel.choices(before)).includes('drain_pct'));
  const whenF=eFields.find(f=>f.key==='when');assert(whenF.show(after)&&!whenF.show(before));
}

// ---- game: the sample pack with effect weapons loads, shows effects and plays ----
{
  const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
  const element=id=>({id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,hidden:false,checked:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0});
  const els={},memory=new Map(),logged=[],created=[];
  const g={window:{scrollTo(){}},console:{...console,warn(){},error(){}},setTimeout:f=>setImmediate(f),confirm:()=>true,alert(){},document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>{const e=element(t);created.push(e);return e;},querySelectorAll:()=>[],body:element('body')},localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)}};
  vm.createContext(g);for(const f of ['shared/pro_core','shared/pro_battle','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),g);
  vm.runInContext(code+'\nensureUnitState();',g);const run=x=>vm.runInContext(x,g);
  const text=read('pro_1101_weapon_effects_sample.js');g.f=[{name:'fx.js',text:async()=>text}];await run('importBundleFiles(f)');
  assert.equal(run('importedBundlePacks.length'),1);assert(run("UNIT_MASTER.find(u=>u.id==='fx-u-breaker').weapons.some(w=>w.effects?.length===2)"),'effects survive the game normalizer');
  created.length=0;run('renderUnits()');assert(created.some(e=>/class="weapon-fx".*使用前: 対「装甲車」ダメージ\+30%/.test(e.innerHTML)),'unit card lists weapon effects');
  g.logged=logged;run("var seed=7;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;const _log=log;log=(h,c)=>{logged.push(h);_log(h,c);};");
  run("state.credits=10000;selected=['fx-u-breaker','fx-u-lancer','fx-u-charger','fx-u-signal'];selectedMission='fx-m-01';showStory=async()=>{};");
  await run('deploy()');assert.equal(run('battleRunning'),false);assert.equal(JSON.parse(run('JSON.stringify(state.records)')).battles,1);
  assert(logged.some(h=>h.includes('[武装効果 ')),'weapon effects appear in the battle log');
  // Reload keeps the pack (effects included).
  const g2={...g,window:{scrollTo(){}}};vm.createContext(g2);for(const f of ['shared/pro_core','shared/pro_battle','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),g2);vm.runInContext(code+'\nensureUnitState();',g2);
  assert(vm.runInContext("UNIT_MASTER.find(u=>u.id==='fx-u-signal').weapons.find(w=>w.name==='集中狙撃銃').effects.length===3",g2));
}
console.log('PASS: weapon effects contract, game sample load/log/reload, before/after timing, when conditions, drain/recoil, counters, multi-target, preview, makers');
})().catch(e=>{console.error(e);process.exitCode=1});
