(async()=>{'use strict';
// 1.12.2 expansion pack: Metal Gear Solid Peace Walker bundle (Bundle Schema 4, fan work) loads, validates and plays.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');const {game}=require('./game_harness.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const text=read('expansion_packs/mgspw_bundle_PRO.js');
assert.match(text.slice(0,700),/二次創作です（非公式・非営利）/);assert.match(text.slice(0,700),/コナミ様とは関係ありません/);
const ctx={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx);
for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor'])vm.runInContext(read(f+'.js'),ctx);
const C=ctx.window.PROCore,E=ctx.window.PROEditor,B=ctx.window.PROBattle,raw=C.parse(text,'VAIS_BUNDLE_PACK'),b=C.bundlePack(raw);
assert.equal(b.schemaVersion,4);assert.equal(b.packId,'mgspw');assert.equal(b.missions.length,16);assert.equal(b.terrains.length,5);assert.equal(b.research.length,4);
b.units.forEach(u=>{C.unitExt(u);u.weapons.forEach(C.weapon);u.skills.forEach(C.skill);});b.missions.forEach(m=>{C.missionExt(m);m.rules.forEach(r=>C.rule(r,m.id));});
const ids=new Set(b.units.map(u=>u.id)),byId=Object.fromEntries(b.units.map(u=>[u.id,u]));
for(const m of b.missions){for(const id of C.missionEnemyIds(m))assert(byId[id]?.deploy.enemy,m.id+' enemy '+id);if(m.objective?.escortUnitId)assert(ids.has(m.objective.escortUnitId));for(const it of m.requires?.items||[])assert(b.items.some(i=>i.id===it&&i.key));}
for(const r of b.research){for(const id of r.unlock.units)assert(ids.has(id)&&byId[id].recruit?.locked&&!byId[id].recruit.missionId,id);for(const q of r.requires)assert(b.research.some(x=>x.id===q));}
for(const u of b.units.filter(u=>u.recruit?.missionId))assert(b.missions.some(m=>m.id===u.recruit.missionId),u.id);
// Players: only Snake starts; MSF soldiers cover 8 branches x ranks C/B/A, B and A come from research.
const players=b.units.filter(u=>u.deploy.player);assert.equal(players.length,31);assert.deepEqual(players.filter(u=>!u.recruit?.locked).map(u=>u.name),['スネーク']);
const msf=players.filter(u=>u.id.startsWith('pw-u-msf-'));assert.equal(msf.length,24);for(const k of ['assault','heavy','sniper','medic','tech','scout','supply','cook']){const [c,bb,a]=['c','b','a'].map(r=>byId['pw-u-msf-'+k+r]);assert(c&&bb&&a&&bb.hp>c.hp&&a.hp>bb.hp&&c.recruit.missionId&&!bb.recruit.missionId&&!a.recruit.missionId,k);}
const unlocked=new Set(b.research.flatMap(r=>r.unlock.units));for(const u of msf.filter(u=>!/c$/.test(u.id)))assert(unlocked.has(u.id),u.id);
for(const n of ['カズヒラ・ミラー','アマンダ','チコ','ヒューイ・エメリッヒ','ストレンジラブ'])assert(players.some(u=>u.name===n),n);
// Enemies include the AI weapons (tagged 兵器) and the people behind them.
for(const k of ['lav','t72','pupa','mi24','chrysalis','cocoon','pw1','pw2','pw3','zeke'])assert(byId['pw-e-'+k]?.tags.includes('兵器')&&byId['pw-e-'+k].hp>=10000,k);
for(const k of ['coldman','zadornov','paz'])assert(byId['pw-e-'+k]&&!byId['pw-e-'+k].deploy.player,k);
assert(byId['pw-u-snake'].weapons.some(w=>w.effects?.some(e=>e.tag==='兵器')));assert(byId['pw-u-huey'].weapons.some(w=>w.effects?.some(e=>e.tag==='兵器')));
// 1.12 features: waves with each trigger, a boss in a later wave, escort + defense, pack terrains.
assert(b.missions.some(m=>m.objective?.bossWave>=2));assert(b.missions.some(m=>m.objective?.type==='defense'&&m.objective.escortUnitId));for(const w of ['turn','remaining','bossHp','cleared'])assert(b.missions.some(m=>(m.waves||[]).some(x=>C.normalizeWave(x).when===w)),w);
assert(b.missions.every(m=>m.terrain==='標準'||b.terrains.some(t=>t.name===m.terrain)));
// Game: catalog entry, import, locks, first mission and recruits, research recruits MSF soldiers.
const g=game();assert(g.run("PACK_CATALOG.some(p=>p.packId==='mgspw'&&p.file==='expansion_packs/mgspw_bundle_PRO.js')"));
g.c.f=[{name:'pw.js',text:async()=>text}];await g.run('importBundleFiles(f)');assert.equal(g.run('importedBundlePacks.length'),1,g.alerts.join('\n'));
assert(g.run("UNIT_MASTER.some(u=>u.id==='pw-u-snake')&&!UNIT_MASTER.some(u=>u.id==='pw-u-kaz')&&!UNIT_MASTER.some(u=>u.id==='pw-u-msf-assaultb')"));
assert(g.run("PW=MISSIONS.filter(m=>m.id.startsWith('pw-m-'));PW.length===16&&PW.every(missionAvailable)"));
assert.equal(g.run("missionLockReason(MISSIONS.find(m=>m.id==='pw-m-01'))"),'');assert(g.run("missionLockReason(MISSIONS.find(m=>m.id==='pw-m-13'))")!=='');
assert.match(g.run("terrainText(MISSIONS.find(m=>m.id==='pw-m-07'))"),/火口内（射撃命中-5 \/ MOB-10%）/);
g.run("var seed=4;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};selected=['pw-u-snake'];selectedMission='pw-m-01';");
await g.run('deploy()');assert.equal(g.run("state.missions['pw-m-01']?.clears"),1);assert(g.run("UNIT_MASTER.some(u=>u.id==='pw-u-kaz')&&UNIT_MASTER.some(u=>u.id==='pw-u-msf-assaultc')"),'Kaz and an MSF assault soldier join after the first mission');
g.run('state.credits=100000;');assert(g.run("doResearch('pw-r-rd')"));assert(g.run("UNIT_MASTER.some(u=>u.id==='pw-u-msf-assaultb')&&UNIT_MASTER.some(u=>u.id==='pw-u-msf-techb')"));assert(!g.run("doResearch('pw-r-fulton')"),'needs the other research first');
// Missions are winnable with the intended squad at the expected level (simulated).
C.registerTerrains(b.terrains);const defs=Object.fromEntries(b.units.map(u=>[u.id,E.battleUnit(u)]));const at=(id,n)=>{const u=byId['pw-u-'+id],d={...defs[u.id]};for(const [k,v] of Object.entries(u.growth||{}))d[k]+=v*(n-1);return d;};
const sq={'pw-m-01':[['snake'],1],'pw-m-03':[['snake','kaz','msf-assaultc','msf-medicc'],3],'pw-m-09':[['snake','msf-assaultb','msf-medicb','msf-sniperb','msf-heavyb','msf-techb','msf-scoutb'],6],'pw-m-12':[['snake','huey','msf-assaulta','msf-medicb','msf-snipera','msf-heavya','msf-techa','msf-scoutb'],8],'pw-m-15':[['snake','huey','msf-assaulta','msf-medica','msf-snipera','msf-heavya','msf-techa','msf-supplya'],10]};
for(const [id,[team,lv]] of Object.entries(sq)){const m=b.missions.find(x=>x.id===id),r=await B.simulate({allies:team.map(t=>at(t,lv)).slice(0,m.maxDeploy),enemies:m.enemies,mission:E.battleMission(m),enemyDefs:defs,unitDefs:defs,trials:30,seed:11});assert(r.winRate>=.25,`${m.name}: ${r.winRate}`);}
console.log(`PASS: MGSPW bundle — ${players.length} playable (${msf.length} MSF soldiers by branch/rank) + ${b.units.length-players.length} enemies / ${b.missions.length} missions / ${b.items.length} items / ${b.research.length} research / ${b.terrains.length} terrains valid, fan-work notice, catalog entry, imports, locks, first mission recruits, research unlocks, AI weapon bosses winnable`);
})().catch(e=>{console.error(e);process.exitCode=1});

