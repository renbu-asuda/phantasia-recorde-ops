(async()=>{'use strict';
// 1.12.1 expansion pack: Touhou Project bundle (Bundle Schema 4, fan work) loads, validates and plays.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');const {game}=require('./game_harness.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const text=read('expansion_packs/touhou_bundle_PRO.js');
assert.match(text.slice(0,600),/東方Projectの二次創作です（非公式・非営利）/);assert.match(text.slice(0,600),/上海アリス幻樂団様とは関係ありません/);
const ctx={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx);
for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor'])vm.runInContext(read(f+'.js'),ctx);
const C=ctx.window.PROCore,E=ctx.window.PROEditor,B=ctx.window.PROBattle,raw=C.parse(text,'VAIS_BUNDLE_PACK'),b=C.bundlePack(raw);
assert.equal(b.schemaVersion,5,'uses the fantasy attribute (Bundle Schema 5)');assert.equal(b.packId,'touhou');assert.equal(b.missions.length,12);assert.equal(b.terrains.length,6);
b.units.forEach(u=>{C.unitExt(u);u.weapons.forEach(C.weapon);u.skills.forEach(C.skill);});b.missions.forEach(m=>{C.missionExt(m);m.rules.forEach(r=>C.rule(r,m.id));});
const ids=new Set(b.units.map(u=>u.id)),byId=Object.fromEntries(b.units.map(u=>[u.id,u]));
for(const m of b.missions){for(const id of C.missionEnemyIds(m))assert(byId[id]?.deploy.enemy,m.id+' enemy '+id);if(m.objective?.escortUnitId)assert(ids.has(m.objective.escortUnitId));for(const it of m.requires?.items||[])assert(b.items.some(i=>i.id===it&&i.key));}
for(const r of b.research)for(const id of r.unlock.units)assert(ids.has(id)&&byId[id].recruit?.locked);
for(const u of b.units.filter(u=>u.recruit?.missionId))assert(b.missions.some(m=>m.id===u.recruit.missionId),u.id);
// Playable characters: only the two heroines start unlocked; every enemy version has a playable original.
const players=b.units.filter(u=>u.deploy.player);assert.equal(players.length,42);assert.deepEqual(players.filter(u=>!u.recruit?.locked).map(u=>u.name),['博麗霊夢','霧雨魔理沙']);
for(const e of b.units.filter(u=>u.id.startsWith('th-e-'))){const p=byId[e.id.replace('th-e-','th-u-')];assert(p&&p.name===e.name&&e.hp>=p.hp&&!e.deploy.player,e.id);}
for(const name of ['十六夜咲夜','レミリア・スカーレット','魂魄妖夢','西行寺幽々子','八意永琳','蓬莱山輝夜','藤原妹紅','東風谷早苗','射命丸文','古明地さとり','霊烏路空','聖白蓮','豊聡耳神子'])assert(players.some(u=>u.name===name),name);
// 1.12.3: spell cards use the 幻想 attribute and four characters resist it.
assert(byId['th-u-marisa'].weapons.some(w=>w.name==='恋符「マスタースパーク」'&&w.damageType==='beam'));assert(byId['th-u-reimu'].weapons.some(w=>w.name==='霊符「夢想封印」'&&w.damageType==='fantasy'));assert(b.units.filter(u=>u.weapons.some(w=>w.damageType==='fantasy')).length>=40);
for(const k of ['reimu','yukari','byakuren','miko'])assert(byId['th-u-'+k].skills.some(sk=>sk.effect==='weapon_resist_pct'&&sk.resistType==='fantasy'),k);
// Features showcased: spell cards with uses, anti-youkai charms, 1.12 waves / boss in a wave / escort with defense, pack terrains.
assert(byId['th-u-marisa'].weapons.some(w=>w.name==='恋符「マスタースパーク」'&&w.usesPerBattle));assert(byId['th-u-reimu'].weapons.some(w=>w.effects?.some(e=>e.tag==='妖怪')));
assert(b.missions.some(m=>m.objective?.bossWave>=2));assert(b.missions.some(m=>m.objective?.type==='defense'&&m.objective.escortUnitId));for(const w of ['turn','remaining','bossHp','cleared'])assert(b.missions.some(m=>(m.waves||[]).some(x=>C.normalizeWave(x).when===w)),w);
assert(b.missions.every(m=>m.terrain==='標準'||m.terrain==='夜間'||b.terrains.some(t=>t.name===m.terrain)));
// Game: catalog entry, import, locks, first mission clears and recruits.
const g=game();assert(g.run("PACK_CATALOG.some(p=>p.packId==='touhou'&&p.file==='expansion_packs/touhou_bundle_PRO.js')"));
g.c.f=[{name:'th.js',text:async()=>text}];await g.run('importBundleFiles(f)');assert.equal(g.run('importedBundlePacks.length'),1,g.alerts.join('\n'));
assert(g.run("UNIT_MASTER.some(u=>u.id==='th-u-reimu')&&UNIT_MASTER.some(u=>u.id==='th-u-marisa')&&!UNIT_MASTER.some(u=>u.id==='th-u-cirno')"));
assert(g.run("TH=MISSIONS.filter(m=>m.id.startsWith('th-m-'));TH.length===12&&TH.every(missionAvailable)"));
assert.equal(g.run("missionLockReason(MISSIONS.find(m=>m.id==='th-m-01'))"),'');assert(g.run("missionLockReason(MISSIONS.find(m=>m.id==='th-m-09'))")!=='');
assert.match(g.run("terrainText(MISSIONS.find(m=>m.id==='th-m-01'))"),/紅い霧（射撃命中-10）/);
g.run("var seed=4;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};selected=['th-u-reimu','th-u-marisa'];selectedMission='th-m-01';");
await g.run('deploy()');assert.equal(g.run("state.missions['th-m-01']?.clears"),1);assert(g.run("UNIT_MASTER.some(u=>u.id==='th-u-cirno')&&UNIT_MASTER.some(u=>u.id==='th-u-rumia')"),'Rumia and Cirno join after the first incident');
g.run('state.credits=100000;state.items["th-i-grimoire"]=1;');assert(g.run("doResearch('th-r-yakumo')"));assert(g.run("UNIT_MASTER.some(u=>u.id==='th-u-yukari')"));
// Story missions are winnable with the intended squad at the expected level (simulated).
C.registerTerrains(b.terrains);const defs=Object.fromEntries(b.units.map(u=>[u.id,E.battleUnit(u)]));const at=(id,n)=>{const u=byId['th-u-'+id],d={...defs[u.id]};for(const [k,v] of Object.entries(u.growth||{}))d[k]+=v*(n-1);return d;};
const sq={'th-m-01':[['reimu','marisa'],1],'th-m-04':[['reimu','marisa','sakuya','meiling','patchouli','remilia'],4],'th-m-09':[['reimu','marisa','sanae','aya','kanako','youmu','remilia','eirin'],6],'th-m-11':[['reimu','marisa','byakuren','shou','utsuho','yugi','sanae','eirin'],8]};
for(const [id,[team,lv]] of Object.entries(sq)){const m=b.missions.find(x=>x.id===id),r=await B.simulate({allies:team.map(t=>at(t,lv)).slice(0,m.maxDeploy),enemies:m.enemies,mission:E.battleMission(m),enemyDefs:defs,unitDefs:defs,trials:30,seed:11});assert(r.winRate>=.3,`${m.name}: ${r.winRate}`);}
console.log(`PASS: Touhou bundle — ${players.length} playable characters (${b.units.length} units incl. enemy versions) / ${b.missions.length} missions / ${b.items.length} items / ${b.research.length} research / ${b.terrains.length} terrains valid, fan-work notice, catalog entry, imports, locks, first incident clears and recruits, research recruit, bosses winnable`);
})().catch(e=>{console.error(e);process.exitCode=1});

