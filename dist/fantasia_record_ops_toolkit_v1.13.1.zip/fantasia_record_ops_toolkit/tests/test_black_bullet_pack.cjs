(async()=>{'use strict';
// Expansion pack: Black Bullet bundle (Bundle Schema 3) loads, validates and plays.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const text=read('expansion_packs/black_bullet_bundle_PRO.js');
const ctx={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx);
for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor'])vm.runInContext(read(f+'.js'),ctx);
const C=ctx.window.PROCore,E=ctx.window.PROEditor,B=ctx.window.PROBattle,raw=C.parse(text,'VAIS_BUNDLE_PACK'),b=C.bundlePack(raw);
assert.equal(b.schemaVersion,3);assert.equal(b.packId,'black_bullet');
b.units.forEach(u=>{C.unitExt(u);u.weapons.forEach(C.weapon);u.skills.forEach(C.skill);});b.missions.forEach(m=>C.missionExt(m));
const ids=new Set(b.units.map(u=>u.id));for(const m of b.missions)for(const id of C.missionEnemyIds(m))assert(b.units.find(u=>u.id===id)?.deploy.enemy,m.id+' enemy '+id);
for(const r of b.research)for(const id of r.unlock.units)assert(ids.has(id));
for(const u of b.units.filter(u=>u.recruit?.missionId))assert(b.missions.some(m=>m.id===u.recruit.missionId),u.id);
assert(b.units.some(u=>u.tags.includes('ゾディアック')));assert(b.units.filter(u=>u.weapons.some(w=>w.effects?.some(e=>e.tag==='ガストレア'))).length>=10,'Varanium weapons hit Gastrea harder');
// Game import, story progression and a real battle.
const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
const element=id=>({id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,hidden:false,checked:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0});
const memory=new Map(),warnings=[],els={};const g={window:{scrollTo(){}},console:{...console,warn:(...a)=>warnings.push(a.join(' ')),error:(...a)=>warnings.push(a.join(' '))},setTimeout:f=>setImmediate(f),confirm:()=>true,alert:x=>warnings.push('alert '+x),document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>element(t),querySelectorAll:()=>[],body:element('body')},localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)}};
vm.createContext(g);for(const f of ['shared/pro_core','shared/pro_battle','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),g);vm.runInContext(code+'\nensureUnitState();',g);const run=x=>vm.runInContext(x,g);
g.f=[{name:'bb.js',text:async()=>text}];await run('importBundleFiles(f)');assert.equal(run('importedBundlePacks.length'),1,warnings.join('\n'));
assert(run("UNIT_MASTER.some(u=>u.id==='bb-u-rentaro')")&&!run("UNIT_MASTER.some(u=>u.id==='bb-u-tina')"),'Tina joins later');
assert(run("BB=MISSIONS.filter(m=>m.id.startsWith('bb-m-'));BB.length===10&&BB.every(missionAvailable)"));
assert.equal(run("missionLockReason(MISSIONS.find(m=>m.id==='bb-m-01'))"),'');assert(run("missionLockReason(MISSIONS.find(m=>m.id==='bb-m-09'))")!=='');
run("var seed=4;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};selected=['bb-u-rentaro','bb-u-enju','bb-u-kisara'];selectedMission='bb-m-01';");
await run('deploy()');assert.equal(run("state.missions['bb-m-01']?.clears"),1);
run("state.credits=100000;");assert(run("doResearch('bb-r-adjuvant')"));assert(run("UNIT_MASTER.some(u=>u.id==='bb-u-gado')&&UNIT_MASTER.some(u=>u.id==='bb-u-asaka')"));
// Every story mission is winnable with the intended squad at the expected level (simulated).
const defs=Object.fromEntries(b.units.map(u=>[u.id,E.battleUnit(u)]));const at=(id,n)=>{const u=b.units.find(x=>x.id==='bb-u-'+id),d={...defs[u.id]};for(const [k,v] of Object.entries(u.growth||{}))d[k]+=v*(n-1);return d;};
const sq={'bb-m-03':[['rentaro','enju','kisara','kayo','shogen'],3],'bb-m-07':[['rentaro','enju','kisara','tina','shoma','sui','tamaki','yuzuki'],6],'bb-m-09':[['rentaro','enju','kisara','tina','shoma','sui','gado','asaka'],9]};
for(const [id,[team,lv]] of Object.entries(sq)){const m=b.missions.find(x=>x.id===id),r=await B.simulate({allies:team.map(t=>at(t,lv)),enemies:m.enemies,mission:E.battleMission(m),enemyDefs:defs,unitDefs:defs,trials:30,seed:11});assert(r.winRate>=.3,`${m.name}: ${r.winRate}`);}
console.log(`PASS: Black Bullet bundle — ${b.units.length} units / ${b.missions.length} missions / ${b.items.length} items / ${b.research.length} research valid, imports, story locks, recruits, research, first mission clears, bosses winnable`);
})().catch(e=>{console.error(e);process.exitCode=1});

