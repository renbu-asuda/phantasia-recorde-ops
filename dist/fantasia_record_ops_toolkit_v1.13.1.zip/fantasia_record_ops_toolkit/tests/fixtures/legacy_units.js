/* PRO Unit Pack Schema 2 / Game 1.7.0 */
window.VAIS_UNIT_PACK = {
  "format": "VAIS_OUTER_OPS_UNIT_PACK",
  "schemaVersion": 2,
  "packId": "d_units",
  "packName": "デフォルトユニットパック / MGSPW OUTER OPS調整",
  "units": [
    {
      "id": "army_0000",
      "name": "兵士",
      "mark": "兵1",
      "pilot": "",
      "role": "歩兵",
      "ability": "",
      "skills": [],
      "deploy": {
        "player": true,
        "enemy": true
      },
      "hp": 3000,
      "atk": 360,
      "def": 220,
      "mob": 760,
      "acc": 700,
      "weapons": [
        {
          "name": "M16A1相当アサルトライフル",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 95.0,
          "accuracyPt": 6,
          "critPt": 3.0,
          "targetCount": 1,
          "weight": 2.4,
          "minDamage": 25,
          "hitsMin": 2,
          "hitsMax": 5,
          "hitPowerPct": 35
        },
        {
          "name": "LAW相当ロケットランチャー",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 220.0,
          "accuracyPt": -13,
          "critPt": 8.0,
          "targetCount": 1,
          "weight": 0.75,
          "minDamage": 420,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        },
        {
          "name": "グレネード",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 160.0,
          "accuracyPt": -7,
          "critPt": 6.0,
          "targetCount": 1,
          "weight": 0.65,
          "minDamage": 260,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        }
      ],
      "tags": [
        "歩兵"
      ]
    },
    {
      "id": "army_0000_copy",
      "name": "兵士",
      "mark": "兵2",
      "pilot": "",
      "role": "歩兵",
      "ability": "",
      "skills": [],
      "deploy": {
        "player": true,
        "enemy": true
      },
      "hp": 3200,
      "atk": 380,
      "def": 230,
      "mob": 720,
      "acc": 720,
      "weapons": [
        {
          "name": "M16A1相当アサルトライフル",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 95.0,
          "accuracyPt": 6,
          "critPt": 3.0,
          "targetCount": 1,
          "weight": 2.4,
          "minDamage": 25,
          "hitsMin": 2,
          "hitsMax": 5,
          "hitPowerPct": 35
        },
        {
          "name": "LAW相当ロケットランチャー",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 220.0,
          "accuracyPt": -13,
          "critPt": 8.0,
          "targetCount": 1,
          "weight": 0.75,
          "minDamage": 420,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        },
        {
          "name": "グレネード",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 160.0,
          "accuracyPt": -7,
          "critPt": 6.0,
          "targetCount": 1,
          "weight": 0.65,
          "minDamage": 260,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        }
      ],
      "tags": [
        "歩兵"
      ]
    },
    {
      "id": "army_0000_copy_copy",
      "name": "兵士",
      "mark": "兵3",
      "pilot": "",
      "role": "歩兵",
      "ability": "",
      "skills": [],
      "deploy": {
        "player": true,
        "enemy": true
      },
      "hp": 2800,
      "atk": 340,
      "def": 210,
      "mob": 820,
      "acc": 680,
      "weapons": [
        {
          "name": "M16A1相当アサルトライフル",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 95.0,
          "accuracyPt": 6,
          "critPt": 3.0,
          "targetCount": 1,
          "weight": 2.4,
          "minDamage": 25,
          "hitsMin": 2,
          "hitsMax": 5,
          "hitPowerPct": 35
        },
        {
          "name": "LAW相当ロケットランチャー",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 220.0,
          "accuracyPt": -13,
          "critPt": 8.0,
          "targetCount": 1,
          "weight": 0.75,
          "minDamage": 420,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        },
        {
          "name": "グレネード",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 160.0,
          "accuracyPt": -7,
          "critPt": 6.0,
          "targetCount": 1,
          "weight": 0.65,
          "minDamage": 260,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        }
      ],
      "tags": [
        "歩兵"
      ]
    },
    {
      "id": "army_0000_copy_copy_copy",
      "name": "兵士",
      "mark": "兵4",
      "pilot": "",
      "role": "歩兵",
      "ability": "",
      "skills": [],
      "deploy": {
        "player": true,
        "enemy": true
      },
      "hp": 3400,
      "atk": 400,
      "def": 250,
      "mob": 700,
      "acc": 760,
      "weapons": [
        {
          "name": "M16A1相当アサルトライフル",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 95.0,
          "accuracyPt": 6,
          "critPt": 3.0,
          "targetCount": 1,
          "weight": 2.4,
          "minDamage": 25,
          "hitsMin": 2,
          "hitsMax": 5,
          "hitPowerPct": 35
        },
        {
          "name": "LAW相当ロケットランチャー",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 220.0,
          "accuracyPt": -13,
          "critPt": 8.0,
          "targetCount": 1,
          "weight": 0.75,
          "minDamage": 420,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        },
        {
          "name": "グレネード",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 160.0,
          "accuracyPt": -7,
          "critPt": 6.0,
          "targetCount": 1,
          "weight": 0.65,
          "minDamage": 260,
          "hitsMin": 1,
          "hitsMax": 1,
          "hitPowerPct": 100.0
        }
      ],
      "tags": [
        "歩兵"
      ]
    },
    {
      "id": "armored_vehicle_0000",
      "name": "装甲車",
      "mark": "装",
      "pilot": "",
      "role": "BTR-60 PA相当 / 装甲車",
      "ability": "",
      "skills": [],
      "deploy": {
        "player": true,
        "enemy": true
      },
      "hp": 8000,
      "atk": 360,
      "def": 700,
      "mob": 250,
      "acc": 720,
      "weapons": [
        {
          "name": "7.62mm車載マシンガン",
          "attackType": "ranged",
          "damageType": "physical",
          "powerPct": 115.0,
          "accuracyPt": 2,
          "critPt": 4.0,
          "targetCount": 1,
          "weight": 2.2,
          "minDamage": 35,
          "hitsMin": 3,
          "hitsMax": 6,
          "hitPowerPct": 35
        }
      ],
      "tags": [
        "装甲車"
      ]
    }
  ]
};

