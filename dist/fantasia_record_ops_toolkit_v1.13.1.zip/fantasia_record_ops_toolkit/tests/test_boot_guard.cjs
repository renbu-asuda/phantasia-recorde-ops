(()=>{'use strict';
// 1.10.4: every page versions its shared files (cache busting) and shows a visible notice when shared/ cannot be loaded or is stale.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const pages=['index.html','unit_maker.html','mission_maker.html','item_maker.html','combined_maker.html','maker_hub.html'];
const version=read('index.html').match(/const GAME_VERSION = '([^']+)'/)[1];
for(const page of pages){const html=read(page);
  for(const m of html.matchAll(/(?:src|href)="((?:shared\/|outer_ops_)[^"]+)"/g))assert(m[1].endsWith('?v='+version),`${page}: ${m[1]} にバージョンが付いていません`);
  if(page==='maker_hub.html')continue;
  const g=html.match(/<script data-pro-guard>([\s\S]*?)<\/script>/);assert(g,page+': 読み込みチェックがありません');
  // The guard runs after the shared scripts and before the page's main script.
  const lastShared=Math.max(...[...html.matchAll(/src="(?:shared|outer_ops)[^"]*"/g)].map(m=>m.index));assert(g.index>lastShared,page+': チェックが共通JSより前にあります');
  assert(html.indexOf('<script>',g.index)>g.index,page+': 本体スクリプトがチェックの後にありません');
  const run=win=>{const body={children:[],insertBefore(n){this.children.unshift(n);}};const el=t=>({tag:t,style:{},children:[],textContent:'',setAttribute(k,v){this[k]=v;},appendChild(c){this.children.push(c);}});
    const ctx={window:win,document:{body,createElement:el}};Object.assign(ctx,win);vm.createContext(ctx);vm.runInContext(g[1],ctx);return {flag:ctx.window.__PRO_BOOT_FAILED,body};};
  const need=[...g[1].matchAll(/\['(PRO[A-Za-z]+)','([\d.]+)','(shared\/[a-z_]+\.js)'\]/g)].map(m=>({name:m[1],ver:m[2],file:m[3]}));assert(need.length>=2,page);
  const ok=Object.fromEntries(need.map(n=>[n.name,{version:n.ver}]));
  let r=run({...ok});assert.equal(r.flag,undefined,page+': 正常時に案内が出ています');assert.equal(r.body.children.length,0);
  r=run({});assert.equal(r.flag.length,need.length);assert.equal(r.body.children[0].id,'proBootError');assert(r.body.children[0].children[1].children.every(li=>/を読み込めません/.test(li.textContent)));
  r=run({...ok,PROCore:{version:'2.0.0'}});assert.equal(r.flag.length,1);assert.match(r.flag[0],/pro_core\.js が古い版です（2\.0\.0/);
}
// The shared modules themselves satisfy the guards.
const ctx={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx);
for(const f of ['pro_core','pro_battle','pro_templates','pro_editor','maker_core'])vm.runInContext(read('shared/'+f+'.js'),ctx);
for(const page of pages.filter(p=>p!=='maker_hub.html')){const g=read(page).match(/<script data-pro-guard>([\s\S]*?)<\/script>/)[1];for(const m of g.matchAll(/\['(PRO[A-Za-z]+)','([\d.]+)'/g)){const v=ctx.window[m[1]].version.split('.').map(Number),need=m[2].split('.').map(Number);assert(v[0]>need[0]||(v[0]===need[0]&&(v[1]>need[1]||(v[1]===need[1]&&v[2]>=need[2]))),`${m[1]} ${ctx.window[m[1]].version} < ${m[2]}`);}}
// pro_editor survives an older cached pro_core (no weapon-effect constants).
{const c={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(c);vm.runInContext(read('shared/pro_core.js'),c);c.window.PROCore={...c.window.PROCore,WEAPON_BEFORE_ONLY:undefined,WEAPON_AFTER_ONLY:undefined};vm.runInContext(read('shared/pro_battle.js'),c);vm.runInContext(read('shared/pro_editor.js'),c);assert(c.window.PROEditor);}
console.log(`PASS: ${pages.length} pages version their shared files (?v=${version}), boot guards report missing/stale shared modules, editor tolerates an older core`);
})();

