(async()=>{'use strict';
// 1.11.0: estimated win rate, auto squad, and preparing units on the review screen.
const assert=require('assert'),{game}=require('./game_harness.cjs');
const g=game(),run=g.run;
// Strength stars come from the shared formula.
assert.equal(run("B.starCount(B.powerRatio(B.STANDARD_UNIT))"),3);assert(run("unitStrength(UNIT_MASTER.find(u=>u.id==='core-u-strider')).ratio>unitStrength(UNIT_MASTER.find(u=>u.id==='core-u-kai')).ratio"));
// Auto squad: only units that can deploy, strongest first, pilots boarded into pilot-required units.
run("selectedMission='core-m-01'");
let r=JSON.parse(run("JSON.stringify(autoSquad(MISSIONS.find(m=>m.id==='core-m-01')))"));
assert.equal(r.ids.length,4,'fills up to the mission limit');assert(r.ids.includes('core-u-strider'));assert.deepEqual(r.boards,[{unit:'core-u-strider',pilot:'core-u-kai'}]);assert(!r.ids.includes('core-u-kai'),'the boarding pilot is not deployed separately');
assert.equal(run('applyAutoSquad()'),true);assert.equal(run("state.pilots['core-u-strider']"),'core-u-kai');assert.equal(run("deployProblem(MISSIONS.find(m=>m.id==='core-m-01'),selected)"),'');
// Injured / exhausted units are skipped.
run("state.injury['core-u-turtle']=2");r=JSON.parse(run("JSON.stringify(autoSquad(MISSIONS.find(m=>m.id==='core-m-01')))"));assert(!r.ids.includes('core-u-turtle'));run("delete state.injury['core-u-turtle']");
// Tag-restricted missions only pick allowed units.
run("MISSIONS.push({...MISSIONS[0],id:'zz-tag',rules:[{type:'deploy_tags',allTags:['機械']}]})");r=JSON.parse(run("JSON.stringify(autoSquad(MISSIONS.find(m=>m.id==='zz-tag')))"));assert.deepEqual(r.ids,['core-u-strider']);run("MISSIONS.pop()");
// Estimated win rate is deterministic and cached.
const m="MISSIONS.find(m=>m.id==='core-m-01')";
const v1=JSON.parse(JSON.stringify(await run(`estimateWin(${m})`))),v2=JSON.parse(JSON.stringify(await run(`estimateWin(${m})`)));assert.deepEqual(v1,v2);assert(v1.winRate>=0&&v1.winRate<=1);assert(['かんたん','ふつう','むずかしい','とてもむずかしい'].includes(v1.label));
assert.equal(run(`estimateCache.has(estimateKey(${m},estimateSquad(${m})))`),true);
const g2=game();const fresh=JSON.parse(JSON.stringify(await g2.run(`estimateWin(${m},['core-u-jackal','core-u-tiger','core-u-fox','core-u-turtle'])`)));const again=JSON.parse(JSON.stringify(await g2.run(`estimateWin(${m},['core-u-jackal','core-u-tiger','core-u-fox','core-u-turtle'])`)));assert.deepEqual(fresh,again);
// A harder mission with a weak squad estimates lower.
const hard="MISSIONS.find(m=>m.id==='core-m-06')",weak=await g2.run(`estimateWin(${hard},['core-u-mina'])`);assert(weak.winRate<fresh.winRate);
// Empty squad → the estimate uses the auto squad.
const g3=game();const auto=await g3.run(`estimateWin(${m})`);assert(auto&&auto.auto===true);
// Review screen: per-unit repair, pilot choice, remove, and the problem shown inline.
const g4=game(),r4=g4.run;r4("selectedMission='core-m-01';selected=['core-u-strider','core-u-jackal'];state.units['core-u-jackal'].hp=1000;state.credits=100000;render();renderSquadPrep()");
let html=g4.els.squadPrep.innerHTML;assert.match(html,/パイロットが必要/);assert.match(html,/data-prep-pilot="core-u-strider"/);assert.match(html,/data-prep-repair="core-u-jackal"/);
r4("assignPilot('core-u-strider','core-u-kai');repairUnit('core-u-jackal');renderSquadPrep()");html=g4.els.squadPrep.innerHTML;assert(!/パイロットが必要/.test(html));assert(!/data-prep-repair="core-u-jackal"/.test(html));assert.equal(r4("deployProblem(MISSIONS.find(m=>m.id==='core-m-01'),selected)"),'');
// Mission cards show the estimate placeholder (filled from the cache when known).
r4('renderMissions()');
console.log('PASS: shared strength stars, auto squad (limit, pilots boarded, injured/tag rules), deterministic cached win estimates, review-screen repair/pilot/problems');
})().catch(e=>{console.error(e);process.exitCode=1});

