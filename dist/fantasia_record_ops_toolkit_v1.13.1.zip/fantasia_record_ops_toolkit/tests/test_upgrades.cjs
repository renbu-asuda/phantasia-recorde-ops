const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');const inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];const code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
const memory=new Map();const c={window:{},console,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)},confirm:()=>true,alert:()=>{}};vm.createContext(c);
for(const f of ['shared/pro_core','shared/pro_battle','tests/fixtures/legacy_units','tests/fixtures/base_181/outer_ops_missions','tests/fixtures/legacy_items'])vm.runInContext(fs.readFileSync(__dirname+'/../'+f+'.js','utf8'),c);
vm.runInContext(code+'\nrender=()=>{};ensureUnitState();',c);
const run=x=>vm.runInContext(x,c);
const id=run('UNIT_MASTER[0].id');c.targetId=id;
const original=JSON.parse(run('JSON.stringify(UNIT_MASTER[0])'));
run("state.items={repair_kit_s:2,boost_hp:2,boost_atk:2,boost_def:2,boost_mob:2,boost_acc:2};");
for(const stat of ['hp','atk','def','mob','acc']){assert(run(`useItem('boost_${stat}',targetId)`));assert.equal(run(`UNIT_MASTER[0].${stat}`),original[stat]+(stat==='hp'?250:10));assert.equal(run(`state.items.boost_${stat}`),1);}
assert.equal(run('state.units[targetId].hp'),original.hp+250);assert.equal(run('ENEMY_MASTER[targetId].hp'),original.hp);assert.equal(run('ENEMY_MASTER[targetId].atk'),original.atk);
run('ensureUnitState();ensureUnitState();');assert.equal(run('UNIT_MASTER[0].atk'),original.atk+10);
run('state=loadState();ensureUnitState();');assert.equal(run('UNIT_MASTER[0].def'),original.def+10);assert.equal(run('makeAlly(targetId).acc'),original.acc+10);
run('state.units[targetId].hp=100;state.credits=10000;repairUnit(targetId);');assert.equal(run('state.units[targetId].hp'),original.hp+250);assert.equal(run('UNIT_MASTER[0].def'),original.def+10);
run('rebuildUnitMasters();ensureUnitState();');assert.equal(run('UNIT_MASTER[0].mob'),original.mob+10);
assert(!run("useItem('repair_kit_s',targetId)"));assert.equal(run('state.items.repair_kit_s'),2);
run('battleRunning=true;');assert(!run("useItem('boost_atk',targetId)"));run('battleRunning=false;');
assert.throws(()=>run("normalizeItem({id:'bad',name:'bad',effect:{type:'stat_up_flat',stat:'credits',value:1}})"));
run('state=defaultState();ensureUnitState();');assert.equal(run('UNIT_MASTER[0].hp'),original.hp);assert.equal(run('UNIT_MASTER[0].atk'),original.atk);
const old=JSON.stringify({credits:123,units:{[id]:{hp:321}},items:{repair_kit_s:3}});memory.set('vais_outer_ops_save_v1',old);run('state=loadState();ensureUnitState();');assert.equal(run('state.units[targetId].hp'),321);assert.equal(run('state.items.repair_kit_s'),3);assert.equal(run('UNIT_MASTER[0].atk'),original.atk);
console.log('PASS: five stats, consumption, full HP, no double application, save reload, battle stats, enemy isolation, repair, pack rebuild, invalid stat, reset, old save');

