const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../index.html','utf8'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
const memory=new Map(),c={window:{},console,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)},confirm:()=>true,alert:()=>{}};vm.createContext(c);
for(const f of ['shared/pro_core','shared/pro_battle','tests/fixtures/legacy_units','tests/fixtures/base_181/outer_ops_missions','tests/fixtures/legacy_items'])vm.runInContext(fs.readFileSync(__dirname+'/../'+f+'.js','utf8'),c);
vm.runInContext(code+'\nrender=()=>{};ensureUnitState();',c);
const run=x=>vm.runInContext(x,c),C=c.window.PROCore;
const infantry=run("UNIT_MASTER.find(u=>u.tags.includes('歩兵')).id"),vehicle=run("UNIT_MASTER.find(u=>u.tags.includes('装甲車')).id");
c.infantry=infantry;c.vehicle=vehicle;run('state.items.weapon_module=2;');
assert.equal(run('ITEM_MASTER.weapon_module.requires.allTags[0]'),'歩兵');
let previous=run('JSON.stringify(state)');assert(!run("useItem('weapon_module',vehicle)"));assert.equal(run('JSON.stringify(state)'),previous);assert.match(run('planItem(ITEM_MASTER.weapon_module,UNIT_MASTER.find(u=>u.id===vehicle)).reason'),/歩兵/);
assert(run("useItem('weapon_module',infantry)"));assert.equal(run('state.items.weapon_module'),1);assert(run("UNIT_MASTER.find(u=>u.id===infantry).weapons.some(w=>w.name==='増設ライフル')"));
run('state=loadState();ensureUnitState();');assert(run("UNIT_MASTER.find(u=>u.id===infantry).weapons.some(w=>w.name==='増設ライフル')"));assert(!run("ENEMY_MASTER[infantry].weapons.some(w=>w.name==='増設ライフル')"));
const legacy={id:'legacy',name:'旧ユニット',role:'歩兵・地上'};assert.deepEqual(C.unitTags(legacy),['歩兵','地上']);assert.deepEqual(C.unitTags({...legacy,tags:[]}),[]);assert.deepEqual(C.unitTags({...legacy,tags:['装甲車']}),['装甲車']);
const mixed={id:'mix',name:'選択',role:'職種',tags:['歩兵','地上']};let condition=C.requirements({allTags:['歩兵'],anyTags:['地上','空中'],noneTags:['装甲車']});assert(C.checkRequirements(condition,mixed).ok);assert(!C.checkRequirements(condition,{...mixed,tags:['歩兵','装甲車']}).ok);assert(!C.checkRequirements(condition,{...mixed,tags:['歩兵']}).ok);
assert.deepEqual(C.parseTags('歩兵, 地上、支援兵\n訓練済み'),['歩兵','地上','支援兵','訓練済み']);
for(const bad of [{allTags:['歩兵'],noneTags:['歩兵']},{anyTags:['歩兵'],noneTags:['歩兵']},{allTags:['歩兵','歩兵']},{allTags:['']}])assert.throws(()=>C.requirements(bad));
assert.throws(()=>C.unitTags({...mixed,tags:['x','x']}));
const oldPack={format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:1,packId:'old',items:[{id:'oldkit',name:'旧キット',effect:{type:'heal_hp_flat',value:100}}]};assert.equal(C.itemPack(oldPack).items[0].requires,undefined);
const conditional=C.item({id:'cond',name:'歩兵訓練',requires:{allTags:['歩兵'],noneTags:['装甲車']},effects:[{type:'add_skill',skill:c.window.VAIS_ITEM_PACK.items.find(i=>i.id==='skill_manual').effect.skill},{type:'credits_gain',value:100}]});assert.deepEqual(C.item(C.parse(C.serialize('VAIS_ITEM_PACK',{...oldPack,schemaVersion:2,items:[conditional]}),'VAIS_ITEM_PACK').items[0]),conditional);
// The same condition is checked for bundles before any effect is applied.
run("ITEM_MASTER.bundle=normalizeItem({id:'bundle',name:'複合',requires:{allTags:['歩兵']},effects:[{type:'credits_gain',value:100},{type:'heal_hp_full'}]});state.items.bundle=1;");previous=run('JSON.stringify(state)');assert(!run("useItem('bundle',vehicle)"));assert.equal(run('JSON.stringify(state)'),previous);
console.log('PASS: default infantry restriction, legacy role fallback, all/any/none, exact match, pack roundtrip, atomic failure, old schema');

