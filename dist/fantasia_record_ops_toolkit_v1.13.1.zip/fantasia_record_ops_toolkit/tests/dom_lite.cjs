// Tiny DOM for editor tests (1.12.0): enough for PROEditor's element/property/on* usage, with tree queries.
function element(tag){const e={tagName:String(tag).toUpperCase(),children:[],parentNode:null,style:{},attrs:{},className:'',value:'',type:'',disabled:false,hidden:false,checked:false,
  _text:'',get textContent(){return this._text+this.children.map(c=>c.textContent).join('');},set textContent(v){this._text=String(v??'');for(const c of this.children)c.parentNode=null;this.children=[];},
  append(...xs){for(const x of xs){if(x==null)continue;if(typeof x==='string'){const t=element('#text');t._text=x;x=t;}if(x.parentNode)x.parentNode.children.splice(x.parentNode.children.indexOf(x),1);x.parentNode=this;this.children.push(x);}},
  appendChild(x){this.append(x);return x;},insertBefore(x,ref){if(x.parentNode)x.parentNode.children.splice(x.parentNode.children.indexOf(x),1);x.parentNode=this;const i=this.children.indexOf(ref);this.children.splice(i<0?this.children.length:i,0,x);return x;},
  replaceChildren(...xs){for(const c of this.children)c.parentNode=null;this.children=[];this._text='';this.append(...xs);},remove(){if(this.parentNode)this.parentNode.children.splice(this.parentNode.children.indexOf(this),1);this.parentNode=null;},
  setAttribute(k,v){this.attrs[k]=String(v);},getAttribute(k){return Object.hasOwn(this.attrs,k)?this.attrs[k]:null;},removeAttribute(k){delete this.attrs[k];},
  classList:{add(){},remove(){},toggle(){}},focus(){},click(){if(!this.disabled&&this.onclick)this.onclick({target:this});},
  all(){const out=[];const walk=n=>{for(const c of n.children){out.push(c);walk(c);}};walk(this);return out;},
  querySelectorAll(sel){return this.all().filter(n=>match(n,sel));},querySelector(sel){return this.querySelectorAll(sel)[0]||null;}};
  return e;}
function match(n,sel){if(sel.startsWith('.'))return String(n.className).split(/\s+/).includes(sel.slice(1));if(sel==='*')return n.tagName!=='#TEXT';return n.tagName===sel.toUpperCase();}
function setup(){const body=element('body');const document={createElement:element,body,getElementById:()=>null};return {document,body,element};}
// helpers
const byText=(root,tag,text)=>root.querySelectorAll(tag).find(n=>n.textContent===text);
const byLabel=(root,label)=>root.all().find(n=>n.attrs&&n.attrs['aria-label']===label);
module.exports={setup,element,byText,byLabel};

