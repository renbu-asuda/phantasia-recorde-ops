(async()=>{'use strict';
// 1.11.0: first-run guide and "次にやること" suggestions.
const assert=require('assert'),{game}=require('./game_harness.cjs');
const g=game(),run=g.run;
// New save: the guide is shown; closing it is remembered.
run('renderHomeCards()');assert.match(g.els.homeCards.innerHTML,/はじめての方へ/);assert.match(g.els.homeCards.innerHTML,/data-go="missions"/);
run('finishGuide()');assert.equal(run('state.settings.guideDone'),true);run('renderHomeCards()');assert(!/はじめての方へ/.test(g.els.homeCards.innerHTML));
const g2=game({memory:new Map(g.memory)});assert.equal(g2.run('state.settings.guideDone'),true,'guideDone survives reload');
run('reopenGuide()');assert.equal(run('state.settings.guideDone'),false);
// Next actions, in priority order.
let acts=JSON.parse(run('JSON.stringify(nextActions())'));
assert.match(acts[0].text,/ストライダーにパイロット/);assert.equal(acts[0].view,'growth');assert.equal(acts[0].growth,'core-u-strider');
assert(acts.some(a=>/作戦「演習：哨戒部隊撃破」/.test(a.text)&&a.mission==='core-m-01'));assert(acts.length<=3);
run("assignPilot('core-u-strider','core-u-kai')");acts=JSON.parse(run('JSON.stringify(nextActions())'));assert(!acts.some(a=>/パイロット/.test(a.text)),'pilot suggestion disappears');
run("state.levels['core-u-jackal']={lv:2,exp:0,sp:1};");acts=JSON.parse(run('JSON.stringify(nextActions())'));assert.match(acts[0].text,/ジャッカルにスキルポイントが1/);
run("state.units['core-u-tiger'].hp=100;");acts=JSON.parse(run('JSON.stringify(nextActions())'));assert(acts.some(a=>/HPが減っています/.test(a.text)));
// Actions navigate (and pick the growth target / mission).
run("goTo('growth',{growth:'core-u-fox'})");assert.equal(run('growthTargetId'),'core-u-fox');assert.equal(g.shown.at(-1),'growth');
run("goTo('missions',{mission:'core-m-01'})");assert.equal(run('selectedMission'),'core-m-01');
// Everything done → a friendly fallback.
run("state.levels['core-u-jackal'].sp=0;for(const u of UNIT_MASTER)state.units[u.id].hp=u.hp;for(const m of MISSIONS)state.missions[m.id]={clears:1,best:3,stars:[true,true,true]};state.credits=0;");
run('renderHomeCards()');assert.match(g.els.homeCards.innerHTML,/すべて順調/);
console.log('PASS: first-run guide (show, close, persist, reopen), next actions (pilot, SP, HP, missions, research, stars) in priority order with navigation');
})().catch(e=>{console.error(e);process.exitCode=1});

