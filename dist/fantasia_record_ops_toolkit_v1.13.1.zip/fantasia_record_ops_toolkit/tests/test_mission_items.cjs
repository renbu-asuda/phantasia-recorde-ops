const assert=require('assert'),fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(__dirname+'/../mission_maker.html','utf8');
const take=name=>src.split('\n').find(x=>x.startsWith('function '+name+'('));
const box={className:'',innerHTML:''},inputs={packId:{value:'trial'},validationBox:box};
const ctx={window:{},console,pack:{missions:[]},unitMap:new Map([['enemy',{id:'enemy',deploy:{enemy:true},def:200}]]),itemMap:new Map(),MAX_SLOTS:8,$:id=>inputs[id],syncCurrent(){},esc:x=>String(x),n:(x,d)=>Number.isFinite(Number(x))?Number(x):d,clone:x=>JSON.parse(JSON.stringify(x))};vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../shared/pro_core.js','utf8'),ctx);for(const f of ['pro_battle','pro_editor'])vm.runInContext(fs.readFileSync(__dirname+'/..'+'/shared/'+f+'.js','utf8'),ctx);vm.runInContext('var C=window.PROCore,E=window.PROEditor,clone=x=>JSON.parse(JSON.stringify(x));',ctx);
vm.runInContext(`const IFORMAT='VAIS_OUTER_OPS_ITEM_PACK',SCHEMA=1;`+['extractAssignedObject','duplicateIds','readItemPack','normalizeDrop','normalizeMission'].map(take).join('\n')+'\n'+src.slice(src.indexOf('function validate(){'),src.indexOf('function updatePreview()')),ctx);
ctx.source=fs.readFileSync(__dirname+'/fixtures/legacy_items.js','utf8');
const items=vm.runInContext('readItemPack(source).items',ctx);assert.equal(items.length,16);for(const item of items)ctx.itemMap.set(item.id,item);
ctx.pack.missions=[{id:'old',name:'旧作戦',enemies:['enemy'],rules:[],tags:[],maxDeploy:3,drops:[]}];assert(ctx.validate());
ctx.pack.missions[0].drops=[{itemId:'repair_kit_s',chance:55,min:1,max:2}];assert(ctx.validate());
assert.deepEqual(JSON.parse(JSON.stringify(vm.runInContext('normalizeMission(pack.missions[0]).drops[0]',ctx))),{itemId:'repair_kit_s',chance:55,min:1,max:2});
ctx.pack.missions[0].drops[0].chance=101;assert(!ctx.validate());assert(box.innerHTML.includes('確率'));
ctx.pack.missions[0].drops[0].chance=50;ctx.pack.missions[0].drops[0].itemId='another_item';assert(ctx.validate());assert(box.innerHTML.includes('アイテムJS未読込'));
console.log('Mission Maker item pack import, drop validation, old mission PASS');

