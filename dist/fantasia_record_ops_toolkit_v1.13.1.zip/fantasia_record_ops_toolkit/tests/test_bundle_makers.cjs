const fs=require('fs'),vm=require('vm'),assert=require('assert'),read=x=>fs.readFileSync(__dirname+'/../'+x,'utf8');
const c={window:{},console};vm.createContext(c);vm.runInContext(read('shared/pro_core.js'),c);
const sample={format:c.window.PROCore.BUNDLE_FORMAT,schemaVersion:1,packId:'one',packName:'統合',units:[{id:'soldier',name:'兵士',role:'歩兵',tags:['歩兵'],weapons:[{name:'銃'}]}],missions:[{id:'task',name:'作戦',enemies:['soldier']}],items:[{id:'aid',name:'支給品',effect:{type:'heal_hp_flat',value:20}}]};c.text=c.window.PROCore.serialize('VAIS_BUNDLE_PACK',sample);
const u=read('unit_maker.html'),m=read('mission_maker.html'),line=(s,name)=>s.split('\n').find(x=>x.startsWith('function '+name+'('));
vm.runInContext("const FORMAT='VAIS_OUTER_OPS_UNIT_PACK',UFORMAT=FORMAT,MFORMAT='VAIS_OUTER_OPS_MISSION_PACK',IFORMAT='VAIS_OUTER_OPS_ITEM_PACK',SCHEMA=2,SUPPORTED_SCHEMAS=new Set([1,2]),UNIT_SCHEMAS=SUPPORTED_SCHEMAS;function normalizeUnit(x){return x}function normalizeMission(x){return x}function duplicateIds(xs){return []}function extractAssignedObject(t,m){return window.PROCore.parse(t,m)}function parseObject(t,m){return window.PROCore.parse(t,m)}",c);
vm.runInContext('var C=window.PROCore,toast=()=>{};'+line(u,'convertLegacyPilots'),c);vm.runInContext('const parseUnits='+line(u,'parsePackJs').replace('function parsePackJs','function')+';',c);
vm.runInContext('const parseMissions='+line(m,'readMissionPack').replace('function readMissionPack','function')+';const parseItems='+line(m,'readItemPack').replace('function readItemPack','function')+';',c);
assert.equal(vm.runInContext('parseUnits(text).units[0].tags[0]',c),'歩兵');assert.equal(vm.runInContext('parseMissions(text).missions[0].enemies[0]',c),'soldier');assert.equal(vm.runInContext('parseItems(text).items[0].id',c),'aid');
console.log('PASS: standalone Unit/Mission Maker can project combined pack into their data sections');

