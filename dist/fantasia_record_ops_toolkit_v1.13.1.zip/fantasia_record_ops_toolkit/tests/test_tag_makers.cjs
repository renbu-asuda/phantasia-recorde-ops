const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=name=>fs.readFileSync(__dirname+'/../'+name+'_maker.html','utf8'),line=(s,name)=>s.split('\n').find(x=>x.startsWith('function '+name+'('));
const u=src('unit'),m=src('mission'),ctx={window:{},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../shared/pro_core.js','utf8'),ctx);for(const f of ['pro_battle','pro_editor'])vm.runInContext(fs.readFileSync(__dirname+'/..'+'/shared/'+f+'.js','utf8'),ctx);vm.runInContext('var C=window.PROCore,E=window.PROEditor,clone=x=>JSON.parse(JSON.stringify(x));',ctx);
vm.runInContext("const FORMAT='VAIS_OUTER_OPS_UNIT_PACK',SUPPORTED_SCHEMAS=new Set([1,2]),SCHEMA=2,UFORMAT=FORMAT,UNIT_SCHEMAS=SUPPORTED_SCHEMAS;const MAX_SLOTS=8;function n(x,d){const v=Number(x);return Number.isFinite(v)?v:d}function clamp(x,a,b){return Math.max(a,Math.min(b,x))}const TRIGGER_LABELS={before_attack:1,turn_end:1};const EFFECTS_BY_TRIGGER={before_attack:['damage_up_pct'],turn_end:['heal_maxhp_pct']};const RESIST_TYPES=Object.keys(window.PROCore.RESIST_TYPES),DAMAGE_TYPE_KEYS=Object.keys(window.PROCore.DAMAGE_TYPES);function duplicateIds(items){const seen=new Set();return items.filter(x=>{if(seen.has(x.id))return true;seen.add(x.id);return false;}).map(x=>x.id)}",ctx);
const definitions=['newWeapon','normalizeWeapon','legacySkills','normalizeSkill','normalizeUnit','newUnit','parsePackJs'];
vm.runInContext(definitions.map(x=>line(u,x)).join('\n')+"\nconst normalizeUnitFromUnitMaker=normalizeUnit;",ctx);
const gameUnit={id:'older',name:'旧式歩兵',role:'歩兵',weapons:[{name:'銃'}]};ctx.sample=gameUnit;
assert.deepEqual(JSON.parse(vm.runInContext('JSON.stringify(normalizeUnitFromUnitMaker(sample).tags)',ctx)),['歩兵']);
ctx.sample={...gameUnit,tags:['射撃','歩兵']};assert.deepEqual(JSON.parse(vm.runInContext('JSON.stringify(normalizeUnitFromUnitMaker(sample).tags)',ctx)),['射撃','歩兵']);
vm.runInContext('const normalizeUnitForMission='+line(m,'normalizeUnit').replace('function normalizeUnit','function')+';\nconst readItemPack='+line(m,'readItemPack').replace('function readItemPack','function')+';',ctx);
assert.deepEqual(JSON.parse(vm.runInContext('JSON.stringify(normalizeUnitForMission(sample).tags)',ctx)),['射撃','歩兵']);
ctx.text=fs.readFileSync(__dirname+'/../tests/fixtures/base_181/outer_ops_items.js','utf8');assert.equal(vm.runInContext("readItemPack(text).items.find(i=>i.id==='item-0001').requires.allTags[0]",ctx),'生身');
console.log('PASS: Unit Maker legacy/imported tag normalization and Mission Maker item condition parsing');

