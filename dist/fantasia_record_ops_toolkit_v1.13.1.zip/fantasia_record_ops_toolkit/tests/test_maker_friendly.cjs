(async()=>{'use strict';
// 1.10.0: templates, plain-language descriptions, strength/difficulty estimates, friendly errors and ID repair.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',read=f=>fs.readFileSync(root+'/'+f,'utf8');
const memory=new Map(),ctx={window:{},console,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)},document:{body:null}};
vm.createContext(ctx);for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor'])vm.runInContext(read(f+'.js'),ctx);
const C=ctx.window.PROCore,T=ctx.window.PROTemplates,E=ctx.window.PROEditor;

// Every template yields valid data.
for(const t of T.weapons)C.weapon(t.weapon);
for(const t of T.skills){const s=T.skillByKey(t.key);C.skill(s);assert(E.describeSkill(s).length>8,t.key);}
const unitIds=[];const units=[];
for(const u of T.units)for(const tier of T.tiers)for(const f of Object.keys(T.factions)){const made=T.makeUnit(u.key,tier.key,f,'',unitIds);unitIds.push(made.id);units.push(made);C.unitExt(made);made.skills.forEach(C.skill);made.weapons.forEach(C.weapon);assert(C.safeId(made.id));}
assert.equal(new Set(unitIds).size,unitIds.length,'auto IDs are unique');
const enemyIds=units.filter(u=>u.deploy.enemy).slice(0,4).map(u=>u.id),locked={...T.makeUnit('scout','normal','player','新人',unitIds),recruit:{locked:true}};units.push(locked);
const items=[];for(const t of T.items){const it=T.makeItem(t.key,'',{itemIds:items.map(i=>i.id),units},items.map(i=>i.id));C.item(it);items.push(it);}
const missions=[];for(const t of T.missions)for(const r of T.ranks){const m=T.makeMission(t.key,r.key,'',{enemyIds,unitIds:units.map(u=>u.id),escortIds:[units[0].id],itemIds:items.map(i=>i.id)},missions.map(m=>m.id));C.missionExt(m);m.rules.forEach(r=>C.rule(r));missions.push(m);}
const pilots=T.pilots.map(t=>T.makePilot(t.key,'',[]));pilots.forEach((p,i)=>{p.id='pilot-000'+(i+1);C.pilot(p);});
const research=T.research.map((t,i)=>({...T.makeResearch(t.key,'',{pricedItemIds:items.filter(i=>i.price).map(i=>i.id),lockedUnitIds:[locked.id]},[]),id:'research-000'+(i+1)}));C.researchList(research);
// A bundle made only from templates passes the game's bundle validation and can be played.
const bundle={format:C.BUNDLE_FORMAT,schemaVersion:2,packId:'template_bundle',packName:'テンプレだけのパック',units,missions,items,pilots,research};
const g={window:{},console:{...console,warn(){}},localStorage:{getItem:()=>null,setItem(){},removeItem(){}},confirm:()=>true,alert(){}};vm.createContext(g);
for(const f of ['shared/pro_core','shared/pro_battle','tests/fixtures/base_181/outer_ops_units','tests/fixtures/base_181/outer_ops_missions','tests/fixtures/base_181/outer_ops_items'])vm.runInContext(read(f+'.js'),g);
const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];vm.runInContext(inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"))+'\nrender=()=>{};ensureUnitState();',g);
g.bundle=JSON.parse(JSON.stringify(bundle));const v=vm.runInContext('validateBundlePack(bundle)',g);assert.equal(v.missions.length,missions.length);
const B=ctx.window.PROBattle,defs=Object.fromEntries(units.map(u=>[u.id,E.battleUnit(u)]));
const sim=await B.simulate({allies:units.filter(u=>u.deploy.player).slice(0,4).map(u=>defs[u.id]),enemies:missions[0].enemies,mission:E.battleMission(missions[0]),enemyDefs:defs,unitDefs:defs,trials:5,seed:3});assert.equal(sim.trials,5);

// Strength stars: standard infantry is ★3, weaker tiers lower, bosses higher.
assert.equal(E.starRating(E.STANDARD).stars,3);assert(Math.abs(E.starRating(E.STANDARD).ratio-1)<1e-9);
assert(E.starRating(T.makeUnit('infantry','weak')).ratio<1);assert(E.starRating(T.makeUnit('commander','boss')).stars===5);
assert(E.starRating(T.makeUnit('infantry','strong')).ratio>E.starRating(T.makeUnit('infantry','normal')).ratio);
// Difficulty estimate is deterministic and reacts to the squad.
const m0=missions.find(m=>m.objective?.type!=='escort');
const d1=await E.missionDifficulty(m0,defs,[]),d2=await E.missionDifficulty(m0,defs,[]);assert(d1.ok);assert.deepEqual(d1,d2);assert(T.ranks.some(r=>r.key===d1.rank));assert(d1.reward>=300);
const strong=await E.missionDifficulty(m0,defs,[T.makeUnit('tank','boss','player')].map(E.battleUnit));assert(strong.winRate>=d1.winRate);
assert.equal((await E.missionDifficulty({...m0,enemies:['missing']},defs,[])).ok,false);
// Descriptions.
assert.match(E.describeSkill(T.skillByKey('command')),/戦闘開始時、味方全体のATKを15%上げる（3TURN・1戦闘1回まで）。/);
assert.match(E.describeSkill(T.skillByKey('laststand')),/HPが30%以下なら/);
assert.match(E.describeWeapon(T.weaponByKey('grenade')),/最大3体/);
for(const eff of Object.keys(C.skillEffects)){const trig=Object.keys(C.allowed).find(t=>C.allowed[t].includes(eff));const s={id:'x',name:'x',trigger:trig,effect:eff,value:10,chance:100,maxUses:0,...(eff==='tag_damage_up_pct'?{tag:'装甲車'}:{}),...(eff==='weapon_resist_pct'?{resistType:'beam'}:{})};assert(!/undefined/.test(E.describeSkill(s)),eff);}
// Friendly errors.
for(const msg of ['unit IDは英数字・_・-で指定してください','スキルの発動条件と効果の組み合わせが未対応です','m1: 統合パック内の敵ユニットが不足: x','x: 効果は1～8個です（装備品・キーアイテムは0個でも可）']){const f=E.friendlyError(msg);assert(f.fix,msg);assert.notEqual(f.message,msg);}
// ID repair: duplicates and invalid IDs get new IDs, and references follow the rename.
const broken={units:[{id:'敵兵',name:'敵兵',deploy:{enemy:true}},{id:'dup',name:'A'},{id:'dup',name:'B'}],missions:[{id:'m 1',name:'作戦',enemies:['敵兵','敵兵'],drops:[{itemId:'薬'}],requires:{items:['薬']}}],items:[{id:'薬',name:'薬',effect:{type:'heal_hp_flat',value:1}},{id:'box',name:'箱',effect:{type:'loot_box',table:[{itemId:'薬',weight:1,min:1,max:1}]}}],research:[{id:'r',name:'r',requires:[],unlock:{items:['薬'],units:['敵兵']},cost:{items:{'薬':1}}}]};
const renamed=E.fixIds(broken);assert(renamed.length>=4);
const enemyNew=broken.units[0].id,itemNew=broken.items[0].id;assert(C.safeId(enemyNew)&&C.safeId(itemNew));assert.notEqual(broken.units[1].id,broken.units[2].id);
assert.deepEqual(broken.missions[0].enemies,[enemyNew,enemyNew]);assert.equal(broken.missions[0].drops[0].itemId,itemNew);assert.deepEqual(broken.missions[0].requires.items,[itemNew]);assert.equal(broken.items[1].effect.table[0].itemId,itemNew);
assert.deepEqual(broken.research[0].unlock.items,[itemNew]);assert.deepEqual(broken.research[0].unlock.units,[enemyNew]);assert.deepEqual(Object.keys(broken.research[0].cost.items),[itemNew]);assert(C.safeId(broken.missions[0].id));
// Mode switch persists.
assert.equal(E.mode(),'easy');E.setMode('expert');assert.equal(E.mode(),'expert');assert.equal(memory.get('pro_maker_mode'),'expert');E.setMode('easy');
// Reference lists for pickers.
const refs=E.refsFrom({units:()=>units,missions:()=>missions,items:()=>items,research:()=>research});
assert(refs('enemies').every(([id])=>units.find(u=>u.id===id).deploy.enemy));assert(refs('keyItems').every(([id])=>items.find(i=>i.id===id).key));assert.deepEqual(refs('lockedUnits').map(x=>x[0]),[locked.id]);
console.log(`PASS: ${T.units.length*T.tiers.length*3} unit / ${T.skills.length} skill / ${T.weapons.length} weapon / ${T.items.length} item / ${T.missions.length*T.ranks.length} mission templates valid and playable, stars, difficulty, descriptions, friendly errors, ID repair, mode, pickers`);
})().catch(e=>{console.error(e);process.exitCode=1});

