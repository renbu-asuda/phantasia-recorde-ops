(async()=>{'use strict';
// 1.12.3: the 幻想 (fantasy) attribute — shared definitions, resist matching, Schema 5 / Item 4 / Bundle 5, battle log + tallies, game, makers, templates.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');const {setup,byLabel}=require('./dom_lite.cjs');const {game}=require('./game_harness.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const {document}=setup();const c={window:{},console,document,localStorage:{getItem:()=>null,setItem(){},removeItem(){}}};vm.createContext(c);
for(const f of ['pro_core','pro_battle','pro_templates','pro_editor'])vm.runInContext(read('shared/'+f+'.js'),c);
const C=c.window.PROCore,B=c.window.PROBattle,E=c.window.PROEditor,T=c.window.PROTemplates;
// ---- definitions ----
assert.deepEqual(C.clone(C.DAMAGE_TYPES),{physical:'物理',beam:'ビーム',special:'特殊',fantasy:'幻想'});
assert.deepEqual(Object.keys(C.RESIST_TYPES),['physical','beam','special','fantasy','melee','ranged']);
const wf=C.weapon({name:'弾幕',damageType:'fantasy'});assert.equal(wf.damageType,'fantasy');assert.throws(()=>C.weapon({name:'x',damageType:'holy'}),/武装分類が不正です（属性は物理・ビーム・特殊・幻想から選んでください）/);
const resist=(t,v=30)=>C.skill({id:'r',name:'耐性',trigger:'when_targeted',effect:'weapon_resist_pct',value:v,resistType:t});
assert.equal(resist('fantasy').resistType,'fantasy');assert.throws(()=>resist('holy'),/耐性対象が不正です/);
assert(B.weaponMatchesResist(wf,'fantasy')&&!B.weaponMatchesResist(wf,'special')&&!B.weaponMatchesResist(C.weapon({name:'p'}),'fantasy'));assert(B.weaponMatchesResist(wf,'ranged')&&!B.weaponMatchesResist(wf,'melee'));
assert.equal(B.damageTypeLabel('fantasy'),'幻想');assert.equal(B.damageTypeLabel('holy'),'不明');assert.equal(B.resistTypeLabel('fantasy'),'幻想');assert.equal(B.weaponTypeLabel(wf),'射撃・幻想');assert.equal(B.weaponTypeLabel({attackType:'melee',damageType:'holy'}),'近接・不明');
// ---- Schema numbers: only data that uses 幻想 needs a game that knows it ----
const unit=(o={})=>({id:'u',name:'u',role:'',tags:['歩兵'],deploy:{player:true,enemy:true},hp:3000,atk:500,def:0,mob:500,acc:500,skills:[],weapons:[C.weapon({name:'銃'})],...o});
assert.equal(C.unitSchemaFor([unit()]),2);assert.equal(C.unitSchemaFor([unit({weapons:[wf]})]),5);assert.equal(C.unitSchemaFor([unit({skills:[resist('fantasy')]})]),5);assert.equal(C.unitSchemaFor([unit({skills:[resist('beam')]})]),2,'other resists keep their old numbers');
assert.equal(C.unitSchemaFor([unit({skillTree:[{id:'n',cost:1,minLevel:1,requires:[],skill:resist('fantasy')}]})]),5,'skill tree skills count');assert.equal(C.unitSchemaFor([unit({crew:'required'})]),4);
const item=(o)=>({id:'i',name:'i',...o});
const ip=items=>C.itemPack({format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:3,packId:'p',items}).schemaVersion;
assert.equal(ip([item({effect:{type:'heal_hp_flat',value:10}})]),2);assert.equal(ip([item({effect:{type:'add_weapon',weapon:wf}})]),4);assert.equal(ip([item({effect:{type:'add_skill',skill:resist('fantasy')}})]),4);assert.equal(ip([item({equip:{slot:'accessory',stats:{atk:5},skills:[resist('fantasy')],weapons:[]}})]),4);assert.equal(ip([item({effect:{type:'add_weapon',weapon:C.weapon({name:'w',damageType:'beam'})}})]),2,'a beam weapon keeps the old number');
const bp=(units,items=[])=>C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:5,packId:'b',units,missions:[],items}).schemaVersion;
assert.equal(C.BUNDLE_SCHEMA,5);assert(bp([unit()])<5);assert.equal(bp([unit({weapons:[wf]})]),5);assert.equal(bp([unit()],[item({effect:{type:'add_weapon',weapon:wf}})]),5);
assert.throws(()=>C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:6,packId:'b',units:[],missions:[],items:[]}),/Schema 1～5/);
// ---- battle: resist matches, the log shows the saving, and the totals are tallied ----
const mkUnit=(id,o)=>({id,name:o.name||id,hp:o.hp||100000,atk:o.atk||1000,def:0,mob:500,acc:900,tags:[],skills:o.skills||[],weapons:[C.weapon({name:o.wname||'w',damageType:o.dt||'fantasy',powerPct:100,accuracyPt:100,minDamage:1,hitsMin:1,hitsMax:1,hitPowerPct:100,...(o.eff?{effects:o.eff}:{})})],deploy:{player:true,enemy:true}});
async function fight(att,def,turns=1){const logs=[];const ctx=B.createContext({allies:[B.combatant(att,'ally','a0')],enemies:[B.combatant(def,'enemy','e0',{id:'e_0',key:'e'})],mission:{id:'m',enemies:['e']},rng:()=>.5,enemyDefs:{e:def},unitDefs:{a:att},hooks:{log:h=>logs.push(h.replace(/<[^>]+>/g,'')),logSkill:(u,sk,d)=>logs.push(sk.name+' '+d)}});await B.runBattle(ctx,{maxTurns:turns});return {ctx,logs};}
{const shooter=mkUnit('s',{atk:1000}),plain=mkUnit('p',{}),guard=mkUnit('g',{skills:[resist('fantasy',50)]}),other=mkUnit('o',{skills:[resist('beam',50)]});
 const a=await fight(shooter,plain),b=await fight(shooter,guard),d=await fight(shooter,other);
 const dmg=r=>r.ctx.enemies[0].maxHp-r.ctx.enemies[0].currentHp;assert(dmg(b)<dmg(a)*.6&&dmg(b)>dmg(a)*.4,'fantasy resist halves fantasy damage');assert.equal(dmg(d),dmg(a),'a beam resist does not help against fantasy');
 assert(b.logs.some(l=>/幻想耐性 50%/.test(l)),b.logs.join('\n'));assert(b.logs.some(l=>/耐性で -\d+/.test(l)),'action line shows the saving');assert(b.ctx.effects.resistCount>=1&&b.ctx.effects.resistSaved>0);assert.equal(a.ctx.effects.resistCount,0);assert(!a.logs.some(l=>/耐性で/.test(l)));
 const tag=mkUnit('t',{eff:[{timing:'before',effect:'tag_damage_up_pct',value:50,tag:'妖怪'}]}),yokai={...plain,tags:['妖怪']},t=await fight(tag,yokai);assert(t.ctx.effects.tagCount>=1&&t.ctx.effects.tagBonus>0);assert(t.logs.some(l=>/特効 \+\d+/.test(l)));}
// ---- editor, templates ----
{const box=document.createElement('div');E.form(box,{...wf},E.weaponFields(),()=>{});const sel=byLabel(box,'属性');assert(sel&&[...sel.children].some(o=>o.value==='fantasy'&&o.textContent==='幻想'),'weapon attribute select lists 幻想');
 const sk=document.createElement('div');E.form(sk,{...resist('fantasy')},E.skillFields(),()=>{});assert([...(byLabel(sk,'どの攻撃に強い？（耐性の対象）')?.children||[])].some(o=>o.value==='fantasy'));
 assert.match(E.describeSkill(resist('fantasy',20)),/幻想属性の攻撃から受けるダメージを20%減らす/);assert.match(E.describeSkill(resist('melee',20)),/近接の攻撃から/);assert.match(E.describeWeapon(wf),/^【射撃・幻想】/);assert.equal(C.skillEffects.weapon_resist_pct,'属性耐性 %');}
{const keys=T.skills.filter(s=>s.skill.effect==='weapon_resist_pct').map(s=>s.skill.resistType);assert.deepEqual(keys.sort(),['beam','fantasy','melee','physical','ranged','special']);for(const s of T.skills)C.skill({...s.skill,id:'x'});assert(T.weapons.some(w=>w.key==='fantasybarrage'&&w.weapon.damageType==='fantasy'));for(const w of T.weapons)C.weapon(w.weapon);}
// makers use the shared lists
for(const f of ['unit_maker.html','combined_maker.html']){const h=read(f);assert(!/damageType[^;]{0,40}\['physical','beam','special'\]/.test(h),f+' no hard-coded attribute list');}
// ---- game: loads fantasy data, shows the chip, rejects unknown attributes and Schema 6 ----
{const g=game();const fp={format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:5,packId:'fan',packName:'幻想パック',units:[unit({id:'fan-1',name:'幻想兵',weapons:[wf],skills:[resist('fantasy')]})]};
 const loaded=g.run(`validatePack(${JSON.stringify(fp)})`);assert.equal(loaded.units[0].weapons[0].damageType,'fantasy');assert.equal(loaded.units[0].skills[0].resistType,'fantasy');
 assert.equal(g.run("weaponClass({damageType:'fantasy',attackType:'ranged'})"),'fantasy ranged-weapon');assert.equal(g.run("weaponClass({damageType:'holy',attackType:'melee'})"),'unknown melee-weapon');assert.equal(g.run("weaponTypeLabel({damageType:'fantasy',attackType:'ranged'})"),'射撃・幻想');
 assert.throws(()=>g.run(`validatePack(${JSON.stringify({...fp,units:[unit({id:'x',weapons:[{...wf,damageType:'holy'}]})]})})`),/属性「holy」は未対応です/);
 assert.throws(()=>g.run(`validatePack(${JSON.stringify({...fp,units:[unit({id:'x',skills:[{...resist('fantasy'),resistType:'holy'}]})]})})`),/耐性対象「holy」は未対応です/);
 assert.throws(()=>g.run(`validatePack(${JSON.stringify({...fp,schemaVersion:6})})`),/未対応/);
 g.run(`validatePack(${JSON.stringify({...fp,schemaVersion:2,units:[unit({id:'old',weapons:[{name:'旧',type:'beam'}]})]})})`);
 assert(g.run("GLOSSARY.attr.includes('幻想')&&GLOSSARY.resist.includes('耐性')"));assert.match(read('index.html'),/id="resultEffects"/);}
console.log('PASS: 幻想 attribute — shared DAMAGE_TYPES / RESIST_TYPES, weapon + resist validation and matching, labels, Unit 5 / Item 4 / Bundle 5 numbering (skill tree, equipment included), resist and tag tallies in the log, editor/template lists, game loading and rejection of unknown attributes');
})().catch(e=>{console.error(e);process.exitCode=1});
