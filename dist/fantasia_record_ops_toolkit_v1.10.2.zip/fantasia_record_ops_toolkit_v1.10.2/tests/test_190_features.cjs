(async()=>{'use strict';
// 1.9.0: battle engine features, mission objectives, base systems, save files and schema compatibility.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',read=f=>fs.readFileSync(root+'/'+f,'utf8');
const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
function element(id){return {id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,hidden:false,checked:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0};}
function game({memory=new Map(),warnings=[]}={}){
  const els={},alerts=[];
  const c={window:{scrollTo(){}},console:{...console,warn:(...a)=>warnings.push(a.map(String).join(' ')),error(){}},alerts,setTimeout:f=>setImmediate(f),confirm:()=>true,alert:x=>alerts.push(String(x)),
    document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>element(t),querySelectorAll:()=>[],body:element('body')},
    localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)}};
  vm.createContext(c);
  for(const f of ['shared/pro_core','shared/pro_battle','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),c);
  vm.runInContext(code+'\nensureUnitState();',c);
  return {c,els,memory,warnings,run:x=>vm.runInContext(x,c)};
}
const sampleText=read('pro_190_feature_sample.js');
const base=game(),C=base.c.window.PROCore,B=base.c.window.PROBattle;
const sample=C.parse(sampleText,'VAIS_BUNDLE_PACK');

// ---- data contract and schema compatibility ----
{
  // 1.10.2: legacy pilots are converted into pilot units, so the normalized bundle uses Bundle Schema 3.
  const b=C.bundlePack(sample);assert.equal(b.schemaVersion,3);assert.equal(b.pilots,undefined);assert.equal(b.units.filter(u=>u.pilotProfile).length,2);assert.equal(b.research.length,2);
  base.c.t=sampleText;const g=base.run('extractBundlePackFromJs(t)');assert.equal(g.units.length,12);assert.equal(g.missions.length,6);
  // Packs without 1.9 fields keep their older schema numbers so earlier games still read them.
  base.c.t=read('pro_sample_bundle.js');assert.equal(C.bundlePack(C.parse(base.c.t,'VAIS_BUNDLE_PACK')).schemaVersion,1);
  assert.equal(C.itemPack(base.c.window.VAIS_ITEM_PACK).schemaVersion,2);
  assert.equal(C.unitSchemaFor(base.c.window.VAIS_UNIT_PACK.units,[]),2);assert.equal(C.missionSchemaFor(base.c.window.VAIS_MISSION_PACK.missions),1);
  assert.equal(C.unitSchemaFor(sample.units,[]),3);assert.equal(C.missionSchemaFor(sample.missions),2);
  // Strict validation of new fields.
  assert.throws(()=>C.skill({id:'x',name:'x',trigger:'before_attack',effect:'tag_damage_up_pct',value:10}),/特効タグ/);
  assert.throws(()=>C.skill({id:'x',name:'x',trigger:'before_attack',effect:'guts',value:1}),/組み合わせ/);
  assert.throws(()=>C.weapon({name:'x',fxColor:'red'}),/#RRGGBB/);
  assert.throws(()=>C.missionExt({id:'m',objective:{type:'chain'}}),/追加ウェーブ/);
  assert.throws(()=>C.unitExt({id:'u',skillTree:[{id:'a',requires:['b'],skill:{id:'s',name:'s',trigger:'before_attack',effect:'hit_up_pt',value:1}}]}),/前提ノード/);
  assert.throws(()=>C.item({id:'x',name:'x'}),/効果は1～8個/);assert.equal(C.item({id:'k',name:'鍵',key:true}).key,true);
  assert.throws(()=>C.researchList([{id:'r',name:'r',requires:['missing']}]),/前提研究/);
  assert.throws(()=>C.image('data:text/html;base64,AAAA','x'),/画像/);
}

// ---- engine ----
const W=(o={})=>C.weapon({name:'銃',attackType:'ranged',damageType:'physical',powerPct:100,accuracyPt:100,critPt:-100,targetCount:1,weight:1,minDamage:0,hitsMin:1,hitsMax:1,hitPowerPct:100,...o});
const U=(id,o={})=>({id,name:id,tags:[],hp:3000,atk:500,def:0,mob:500,acc:500,skills:[],weapons:[W()],...o});
const SK=(o)=>C.skill({id:'s_'+Math.random().toString(36).slice(2,7),name:'sk',chance:100,maxUses:0,...o});
function ctx(allies,enemies,o={}){const a=allies.map((d,i)=>B.combatant(d,'ally','a'+i,{row:d.row||'front'})),e=enemies.map((d,i)=>B.combatant(d,'enemy','e'+i,{key:d.id,row:d.row||'front'}));return B.createContext({allies:a,enemies:e,rng:o.rng||(()=>.5),mission:o.mission||null,enemyDefs:o.enemyDefs||{},unitDefs:o.unitDefs||{}});}
{
  // guts: lethal damage leaves HP at the skill value once.
  let x=ctx([U('a',{atk:10000})],[U('e',{skills:[SK({trigger:'on_death',effect:'guts',value:1,maxUses:1})]})]);
  await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[0]]);assert(x.enemies[0].alive);assert.equal(x.enemies[0].currentHp,1);
  await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[0]]);assert(!x.enemies[0].alive);assert.equal(x.killLog.length,1);
  // shield absorbs before HP.
  x=ctx([U('a')],[U('e',{skills:[SK({trigger:'battle_start',effect:'shield',value:400})]})]);B.triggerRoundSkills(x,x.enemies,'battle_start');
  await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[0]]);assert.equal(x.enemies[0].status.shield,0);assert.equal(x.enemies[0].currentHp,3000-(500-400));
  // stun skips the next action; burn ticks at turn start and can kill.
  x=ctx([U('a',{skills:[SK({trigger:'after_attack',effect:'stun',value:1,duration:1})]})],[U('e')]);await B.attack(x,x.allies[0]);assert.equal(x.enemies[0].status.stun,1);const hp=x.enemies[0].currentHp;await B.attack(x,x.enemies[0]);assert.equal(x.enemies[0].status.stun,0);assert.equal(x.allies[0].currentHp,3000);
  x=ctx([U('a',{skills:[SK({trigger:'battle_start',effect:'burn',value:3000,duration:2,target:'enemies'})]})],[U('e')]);x.mission={};const r=await B.runBattle(x);assert.equal(r.outcome,'win');assert.equal(r.turns,1);
  // buffs change effective stats and expire.
  x=ctx([U('a',{skills:[SK({trigger:'battle_start',effect:'atk_up_pct',value:50,duration:1})]})],[U('e')]);B.triggerRoundSkills(x,x.allies,'battle_start');assert.equal(B.eff(x,x.allies[0],'atk'),750);
  x.enemies[0].status.buffs.push({stat:'def',pct:-50,turns:1,src:'t'});assert.equal(B.eff(x,x.enemies[0],'def'),0);
  // def pierce and tag bonus.
  x=ctx([U('a',{atk:1000,skills:[SK({trigger:'before_attack',effect:'def_pierce_pct',value:50})]})],[U('e',{def:400})]);await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[0]]);assert.equal(x.enemies[0].currentHp,3000-(1000-200));
  x=ctx([U('a',{skills:[SK({trigger:'before_attack',effect:'tag_damage_up_pct',value:100,tag:'装甲車'})]})],[U('e1',{tags:['装甲車']}),U('e2')]);await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[0]]);await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[1]]);assert.equal(x.enemies[0].currentHp,2000);assert.equal(x.enemies[1].currentHp,2500);
  // counter (queued, then resolved after the attack) and extra action.
  x=ctx([U('a')],[U('e',{skills:[SK({trigger:'after_damaged',effect:'counter',value:100})]})]);await B.attack(x,x.allies[0]);assert.equal(x.allies[0].currentHp,2500);
  x=ctx([U('a',{atk:5000,skills:[SK({trigger:'on_kill',effect:'extra_action',value:1})]})],[U('e1'),U('e2')]);await B.attack(x,x.allies[0]);assert(!x.enemies[0].alive&&!x.enemies[1].alive,'extra action finished the second enemy');
  // weapon uses and cooldown; fallback attack when nothing is ready.
  x=ctx([U('a',{weapons:[W({name:'砲',usesPerBattle:1})]})],[U('e',{hp:99999})]);x.turn=1;await B.attack(x,x.allies[0]);assert.equal(B.chooseWeapon(x,x.allies[0]).name,'通常攻撃');
  x=ctx([U('a',{weapons:[W({name:'砲',cooldown:1}),W({name:'銃'})]})],[U('e',{hp:99999})]);x.turn=1;await B.resolveWeapon(x,x.allies[0],x.allies[0].weapons[0],[x.enemies[0]]);x.turn=2;assert.equal(B.chooseWeapon(x,x.allies[0]).name,'銃');x.turn=3;assert(['砲','銃'].includes(B.chooseWeapon(x,x.allies[0]).name));
  // rows: melee cannot reach the back row while the front stands; AI picks the weakest.
  x=ctx([U('a',{weapons:[W({attackType:'melee'})]})],[U('front'),U('back',{row:'back'})]);for(let i=0;i<20;i++){const t=B.chooseTargets(x,x.allies[0],x.enemies,1,x.allies[0].weapons[0]);assert.equal(t[0].name,'front');}
  x=ctx([U('a',{ai:{target:'lowest_hp'}})],[U('e1'),U('e2')]);x.enemies[1].currentHp=10;assert.equal(B.chooseTargets(x,x.allies[0],x.enemies,1,W())[0].name,'e2');
  // conditions gate skills.
  x=ctx([U('a',{skills:[SK({trigger:'turn_start',effect:'heal_flat',value:500,cond:{type:'hp_below',value:50}})]})],[U('e')]);x.allies[0].currentHp=2000;B.triggerRoundSkills(x,x.allies,'turn_start');assert.equal(x.allies[0].currentHp,2000);x.allies[0].currentHp=1000;B.triggerRoundSkills(x,x.allies,'turn_start');assert.equal(x.allies[0].currentHp,1500);
  // terrain modifiers.
  const near=B.damagePreview(U('a'),W({attackType:'melee',accuracyPt:0}),U('e'),{terrain:'市街地'});assert.equal(near.terrainHit,10);assert.equal(Math.round(near.hitRate*100),80);
}
{
  // objectives: boss, defense, escort, chain, reinforcement, turn limit.
  const strong=U('hero',{atk:3000,hp:99999,acc:2000,mob:2000,weapons:[W({targetCount:8})]});const grunt=U('grunt',{atk:1});const defs={grunt,boss:U('boss',{hp:3000,atk:1}),wall:U('wall',{hp:999999,atk:1,def:0})};
  let x=ctx([strong],[defs.boss,defs.wall],{mission:{objective:{type:'boss',bossIndex:0}},enemyDefs:defs});let r=await B.runBattle(x);assert.equal(r.outcome,'win');assert(x.enemies[1].alive,'boss objective ignores the guards');
  x=ctx([U('a',{atk:1})],[defs.wall],{mission:{objective:{type:'defense',turns:3}},enemyDefs:defs});r=await B.runBattle(x);assert.equal(r.outcome,'win');assert.equal(r.turns,3);
  const vip=B.combatant(U('vip',{hp:1}),'ally','vip',{escort:true});x=ctx([U('a',{atk:1})],[U('killer',{atk:9999,ai:{target:'lowest_hp'}})],{enemyDefs:defs});x.allies.push(vip);r=await B.runBattle(x);assert.equal(r.outcome,'lose');
  x=ctx([strong],[grunt],{mission:{objective:{type:'chain'},waves:[['grunt','grunt'],['grunt']]},enemyDefs:defs});r=await B.runBattle(x);assert.equal(r.outcome,'win');assert.equal(x.enemies.length,4);
  x=ctx([U('a',{atk:1})],[defs.wall],{mission:{rules:[{type:'reinforce',turn:2,enemies:['grunt']},{type:'turn_limit',value:3}]},enemyDefs:defs});r=await B.runBattle(x);assert.equal(x.enemies.length,2);assert.equal(r.outcome,'lose');assert.equal(r.turns,3);
  // the simulator is deterministic for a given seed.
  const o={allies:[U('a'),U('b')],enemies:['grunt','grunt'],enemyDefs:{grunt:U('grunt')},trials:30,seed:7};const s1=await B.simulate(o),s2=await B.simulate(o);assert.deepEqual(s1,s2);assert.equal(s1.win+s1.lose+s1.draw,30);
}

// ---- game: base systems ----
const g=game();
g.c.f=[{name:'s.js',text:async()=>sampleText}];await g.run('importBundleFiles(f)');
assert.equal(g.run('importedBundlePacks.length'),1);
assert(g.run("UNIT_MASTER.some(u=>u.id==='f19-u-lead')"));assert(!g.run("UNIT_MASTER.some(u=>u.id==='f19-u-scout')"),'locked recruits stay hidden');assert(!g.run("UNIT_MASTER.some(u=>u.id==='f19-u-vip')"));
assert.equal(g.run("Object.keys(PILOT_MASTER).length"),2);assert.equal(g.run("Object.keys(RESEARCH_MASTER).length"),2);
// mission locks
assert.equal(g.run("missionLockReason(MISSIONS.find(m=>m.id==='f19-m-01'))"),'');
assert(g.run("missionLockReason(MISSIONS.find(m=>m.id==='f19-m-02'))").includes('前提作戦'));
g.run("today=()=>3");assert(g.run("missionLockReason(MISSIONS.find(m=>m.id==='f19-m-06'))").includes('曜日'));g.run("today=()=>6");assert.equal(g.run("missionLockReason(MISSIONS.find(m=>m.id==='f19-m-06'))"),'');
assert(g.run("deployProblem(MISSIONS.find(m=>m.id==='f19-m-06'),['f19-u-lead'])").includes('出撃制限'));assert.equal(g.run("deployProblem(MISSIONS.find(m=>m.id==='f19-m-06'),['f19-u-tank'])"),'');
// a real deployment of mission 1 with seeded randomness
g.run("var seed=19;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;");
g.run("state.credits=10000;selected=['f19-u-lead','f19-u-medic','f19-u-tank'];selectedMission='f19-m-01';showStory=async()=>{};");
await g.run('deploy()');
assert.equal(g.run('battleRunning'),false);
const rec=JSON.parse(g.run("JSON.stringify(state.records)"));assert.equal(rec.battles,1);assert.equal(g.run('state.day'),1);
assert(g.run("levelInfo('f19-u-lead').exp>0||levelOf('f19-u-lead')>1"),'deployed units gain experience');
assert.equal(g.run("fatigueOf('f19-u-lead')")>=20,true);
const won=g.run("state.missions['f19-m-01']?.clears||0");
// mission clear unlocks follow-up missions and recruits
g.run("afterBattle(MISSIONS.find(m=>m.id==='f19-m-01'),{killLog:[]},{outcome:'win',turns:3},[])");assert.equal(g.run("missionLockReason(MISSIONS.find(m=>m.id==='f19-m-02'))"),'');
g.run("afterBattle(MISSIONS.find(m=>m.id==='f19-m-02'),{killLog:[]},{outcome:'win',turns:6},[])");assert(g.run("UNIT_MASTER.some(u=>u.id==='f19-u-scout')"),'mission clear recruits the scout');
assert(g.run("state.achievements.includes('first_win')"));assert(g.run("state.achievements.includes('recruit_1')"));
// shop and research
g.run("state.credits=20000;");assert(!g.run("shopAvailable(ITEM_MASTER['f19-i-scope'])"));assert(g.run("buyItem('f19-i-medkit',2)"));assert.equal(g.run("state.items['f19-i-medkit']")>=2,true);assert.equal(g.run('state.records.purchases'),1);
assert(g.run("doResearch('f19-r-01')"));assert(g.run("shopAvailable(ITEM_MASTER['f19-i-scope'])"));assert(!g.run("doResearch('f19-r-02')"),'needs a manual');
g.run("state.items['f19-i-manual']=(state.items['f19-i-manual']||0)+1;");assert(g.run("doResearch('f19-r-02')"));assert(g.run("UNIT_MASTER.some(u=>u.id==='f19-u-ace')"));assert.equal(g.run("state.items['f19-i-armor']"),1);
assert(g.run("sellItem('f19-i-medkit',1)"));
// equipment
const tankDef=g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').def"),tankHp=g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').hp");
assert(g.run("equipItem('f19-u-tank',0,'f19-i-armor')"));assert.equal(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').def"),tankDef+80);assert.equal(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').hp"),tankHp+500);assert(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').skills.some(s=>s.id==='f19-s-armor-guard')"));assert.equal(g.run("state.items['f19-i-armor']"),0);
assert(g.run("equipItem('f19-u-tank',0,null)"));assert.equal(g.run("state.items['f19-i-armor']"),1);assert.equal(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').def"),tankDef);
// pilots with aptitude
const atk=g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').atk"),acc=g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').acc");
assert(g.run("assignPilot('f19-u-tank','f19-p-kai')"));assert.equal(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').atk"),Math.round(atk*1.15));assert.equal(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-tank').acc"),Math.round((acc+40)*1.15));
assert(g.run("assignPilot('f19-u-lead','f19-p-kai')"));assert.equal(g.run("state.pilots['f19-u-tank']"),undefined,'a pilot rides one unit at a time');
// skill tree
g.run("state.levels['f19-u-lead']={lv:1,exp:0,sp:0};");assert(!g.run("unlockTreeNode('f19-u-lead','f19-n-aim')"));g.run("state.levels['f19-u-lead']={lv:3,exp:0,sp:3};");
assert(!g.run("unlockTreeNode('f19-u-lead','f19-n-pierce')"),'requires the first node');assert(g.run("unlockTreeNode('f19-u-lead','f19-n-aim')"));assert(g.run("unlockTreeNode('f19-u-lead','f19-n-pierce')"));assert.equal(g.run("levelInfo('f19-u-lead').sp"),0);
assert(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-lead').skills.some(s=>s.id==='f19-s-pierce')"));assert(g.run("resetTree('f19-u-lead')"));assert.equal(g.run("levelInfo('f19-u-lead').sp"),3);
// level-ups grow stats and HP
const before=JSON.parse(g.run("JSON.stringify(UNIT_MASTER.find(u=>u.id==='f19-u-medic'))"));g.run("addExp('f19-u-medic',100);ensureUnitState();");assert.equal(g.run("levelOf('f19-u-medic')"),2);assert.equal(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-medic').hp"),before.hp+Math.round(3000*.04));
// new item effects
g.run("for(const id of Object.keys(ITEM_MASTER))state.items[id]=(state.items[id]||0)+3;for(const u of UNIT_MASTER)state.units[u.id].hp=u.hp;state.fatigue={};state.injury={};");
assert(g.run("useItem('f19-i-ration','f19-u-lead')"));assert(g.run("UNIT_MASTER.every(u=>state.sortieBuffs[u.id]?.[0]?.stat==='atk')"),'party scope applies to everyone');assert.equal(g.run("makeAlly('f19-u-medic').status.buffs.length"),1);
assert(!g.run("useItem('f19-i-keycard','f19-u-lead')"),'key items cannot be used');
assert(g.run("useItem('f19-i-cyber','f19-u-medic')"));assert(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-medic').tags.includes('機械')&&!UNIT_MASTER.find(u=>u.id==='f19-u-medic').tags.includes('生身')"));
const count=g.run("Object.values(state.items).reduce((a,b)=>a+b,0)");assert(g.run("useItem('f19-i-crate','f19-u-lead')"));assert.equal(g.run("Object.values(state.items).reduce((a,b)=>a+b,0)")>=count,true,'loot box gives at least one item');assert(g.run('lastNotice').includes('箱から'));
for(let i=0;i<3;i++)assert(g.run("useItem('f19-i-manual','f19-u-tank')"));assert(!g.run("useItem('f19-i-manual','f19-u-tank')"),'limit per unit');
assert(g.run("useItem('f19-i-exp','f19-u-tank')"));assert.equal(g.run("levelOf('f19-u-tank')")>=2,true);
// fatigue, injury and rest
g.run("state.injury['f19-u-lead']=2;");assert(!g.run("canSortie('f19-u-lead')"));g.run("restDay()");assert.equal(g.run("injuryOf('f19-u-lead')"),1);g.run("restDay()");assert(g.run("canSortie('f19-u-lead')"));
g.run("state.fatigue['f19-u-tank']=60;");assert.equal(g.run("makeAlly('f19-u-tank').tired"),true);g.run("state.settings.fatigue=false;");assert.equal(g.run("makeAlly('f19-u-tank').tired"),undefined);g.run("state.settings.fatigue=true;");
// facilities
g.run("state.credits=100000;");const rate=g.run('repairRate()');assert(g.run("upgradeFacility('hangar')"));assert(g.run('repairRate()')<rate);assert(g.run("upgradeFacility('med')"));g.run("state.units['f19-u-lead'].hp=1000;restDay();");assert.equal(g.run("state.units['f19-u-lead'].hp"),1000+Math.ceil(g.run("UNIT_MASTER.find(u=>u.id==='f19-u-lead').hp")*.1));
// presets
g.run("selected=['f19-u-tank','f19-u-lead'];state.rows['f19-u-tank']='back';savePreset(0);selected=[];state.rows['f19-u-tank']='front';loadPreset(0);");assert.deepEqual(JSON.parse(g.run('JSON.stringify(selected)')),['f19-u-tank','f19-u-lead']);assert.equal(g.run("state.rows['f19-u-tank']"),'back');
// save export / import roundtrip into a fresh game
const exported=g.run('JSON.stringify(exportSaveData())');const g2=game();g2.c.data=JSON.parse(exported);g2.run('importSaveData(data)');
assert.equal(g2.run('importedBundlePacks.length'),1);assert.equal(g2.run('state.credits'),g.run('state.credits'));assert.equal(g2.run("levelOf('f19-u-tank')"),g.run("levelOf('f19-u-tank')"));assert(g2.run("UNIT_MASTER.some(u=>u.id==='f19-u-ace')"));
assert.throws(()=>g2.run("importSaveData({format:'nope'})"),/セーブデータではありません/);

// ---- startup: every stored key is read without initialization-order errors ----
{
  const memory=new Map(g.memory),warnings=[];
  memory.set('vais_outer_ops_imported_unit_packs_v1',JSON.stringify([{format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:3,packId:'u3',units:sample.units.filter(u=>u.deploy.player),pilots:sample.pilots}]));
  memory.set('vais_outer_ops_imported_mission_packs_v1',JSON.stringify([{format:'VAIS_OUTER_OPS_MISSION_PACK',schemaVersion:2,packId:'m2',missions:[sample.missions[0]]}]));
  memory.set('vais_outer_ops_imported_item_packs_v1',JSON.stringify([{format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:3,packId:'i3',items:sample.items,research:sample.research}]));
  const r=game({memory,warnings});
  assert.deepEqual(warnings.filter(w=>/could not be read|Ignored invalid|before initialization/.test(w)),[],warnings.join('\n'));
  assert.equal(r.run('importedUnitPacks.length'),1);assert.equal(r.run('importedMissionPacks.length'),1);assert.equal(r.run('importedItemPacks.length'),1);assert.equal(r.run('importedBundlePacks.length'),1);
  assert.equal(r.run('state.credits'),g.run('state.credits'));assert.equal(r.run('state.day'),g.run('state.day'));assert.deepEqual(JSON.parse(r.run('JSON.stringify(state.achievements)')),JSON.parse(g.run('JSON.stringify(state.achievements)')));
}
console.log('PASS: 1.9 schema contract, engine (guts/shield/stun/burn/buffs/pierce/tag/counter/extra/weapon limits/rows/AI/conditions/terrain), objectives (boss/defense/escort/chain/reinforce/turn limit), simulator, recruits, mission locks, shop, research, equipment, pilots, skill tree, levels, new item effects, fatigue/injury/rest, facilities, presets, save export/import, startup order');
console.log('Mission 1 sample deployment clears:',won);
})().catch(e=>{console.error(e);process.exitCode=1});
