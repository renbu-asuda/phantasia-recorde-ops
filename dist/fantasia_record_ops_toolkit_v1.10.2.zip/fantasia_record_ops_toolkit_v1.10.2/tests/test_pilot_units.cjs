(async()=>{'use strict';
// 1.10.2: pilots are units. Units can require a pilot (crew:'required'), accept one (optional) or not (none);
// units with a pilotProfile fight alone or ride another unit, sharing its experience, fatigue and injury.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',read=f=>fs.readFileSync(root+'/'+f,'utf8');
const ctx0={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx0);
for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor'])vm.runInContext(read(f+'.js'),ctx0);
const C=ctx0.window.PROCore,E=ctx0.window.PROEditor,T=ctx0.window.PROTemplates;
const sampleText=read('pro_1102_pilot_sample.js'),sample=C.parse(sampleText,'VAIS_BUNDLE_PACK');

// ---- data contract ----
{
  const base={id:'u',name:'U',hp:1,atk:1,def:0,mob:0,acc:0,weapons:[]};
  assert.deepEqual(C.unitExt({...base,crew:'optional'}),{},'optional is the default and is not written');
  assert.equal(C.unitExt({...base,crew:'required'}).crew,'required');
  assert.throws(()=>C.unitExt({...base,crew:'sometimes'}),/crew/);
  assert.throws(()=>C.unitExt({...base,crew:'required',pilotProfile:{stats:{acc:10}}}),/パイロットにはなれません/);
  const pp=C.unitExt({...base,crew:'none',pilotProfile:{stats:{acc:40},aptitude:{tags:['機械'],pct:10},skills:[T.skillByKey('aim')]}}).pilotProfile;
  assert.equal(pp.growthPct,2);assert.equal(pp.skills.length,1);assert.deepEqual(pp.aptitude,{tags:['機械'],pct:10});
  assert.throws(()=>C.unitExt({...base,pilotProfile:{growthPct:50}}),/成長%/);
  assert.deepEqual(C.pilotBonus({stats:{acc:40,mob:20},growthPct:5},1),{acc:40,mob:20});assert.deepEqual(C.pilotBonus({stats:{acc:40,mob:20},growthPct:5},5),{acc:48,mob:24});
  // Schema numbers: new fields → Unit 4 / Bundle 3; without them the older numbers stay.
  assert.equal(C.unitSchemaFor([{...base,crew:'required'}],[]),4);assert.equal(C.unitSchemaFor([base],[]),2);
  assert.equal(C.bundlePack(sample).schemaVersion,3);assert.equal(C.bundlePack(C.parse(read('pro_sample_bundle.js'),'VAIS_BUNDLE_PACK')).schemaVersion,1);
  // Legacy pilots convert into units; IDs are kept unless they collide.
  const r=C.pilotsToUnits([{...base,id:'kai'}],[{id:'kai',name:'カイ',tags:['エース'],stats:{acc:40},aptitude:{tags:['機械'],pct:15},skills:[T.skillByKey('aim')]},{id:'rin',name:'リン',stats:{mob:40}}]);
  assert.deepEqual(r.units.map(u=>u.id),['kai','kai_pilot','rin']);assert.deepEqual(r.idMap,{kai:'kai_pilot',rin:'rin'});
  const kai=r.units[1];assert.equal(kai.crew,'none');assert.equal(kai.hp,3000);assert.deepEqual(kai.tags,['エース','生身','パイロット']);assert.deepEqual(kai.pilotProfile.stats,{acc:40});assert.equal(kai.pilotProfile.aptitude.pct,15);assert.equal(kai.pilotProfile.skills[0].name,T.skillByKey('aim').name);assert.equal(kai.deploy.enemy,false);
  C.unitExt(kai);kai.weapons.forEach(C.weapon);
  // Legacy bundles: pilots become units in the normalized bundle.
  const old=C.bundlePack(C.parse(read('pro_190_feature_sample.js'),'VAIS_BUNDLE_PACK'));assert.equal(old.pilots,undefined);assert(old.units.find(u=>u.id==='f19-p-kai').pilotProfile);
}

// ---- game ----
const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
const element=id=>({id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,hidden:false,checked:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0});
function game(memory=new Map()){
  const els={},created=[];const g={window:{scrollTo(){}},console:{...console,warn(){},error(){}},setTimeout:f=>setImmediate(f),confirm:()=>true,alert(){},document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>{const e=element(t);created.push(e);return e;},querySelectorAll:()=>[],body:element('body')},localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)}};
  vm.createContext(g);for(const f of ['shared/pro_core','shared/pro_battle','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),g);
  vm.runInContext(code+'\nensureUnitState();',g);return {g,memory,created,run:x=>vm.runInContext(x,g)};
}
const G=game(),run=G.run;G.g.f=[{name:'p.js',text:async()=>sampleText}];await run('importBundleFiles(f)');
assert.equal(run('importedBundlePacks.length'),1);
assert.deepEqual(JSON.parse(run('JSON.stringify(Object.keys(PILOT_MASTER).sort())')),['pl-p-kai','pl-p-rin']);
const M=x=>JSON.parse(run(`JSON.stringify(UNIT_MASTER.find(u=>u.id==='${x}'))`));
// A unit that needs a pilot cannot deploy alone; the pilot unit and the plain soldier can.
run("selectedMission='pl-m-01'");
assert.match(run("deployProblem(MISSIONS.find(m=>m.id==='pl-m-01'),['pl-m-strider'])"),/パイロットが必要/);
assert.equal(run("deployProblem(MISSIONS.find(m=>m.id==='pl-m-01'),['pl-p-kai','pl-u-sgt'])"),'');
// Assignment rules.
assert(!run("assignPilot('pl-u-sgt','pl-p-kai')"),'crew:none units take no pilot');
assert(!run("assignPilot('pl-p-kai','pl-p-kai')"),'no self-boarding');
assert(!run("assignPilot('pl-m-strider','pl-m-guardian')"),'only pilot units can ride');
const before=M('pl-m-strider');
assert(run("selected=['pl-p-kai'];assignPilot('pl-m-strider','pl-p-kai')"));assert.deepEqual(JSON.parse(run('JSON.stringify(selected)')),[],'a boarding pilot leaves the selection');
let s=M('pl-m-strider');assert.equal(s.pilotId,'pl-p-kai');assert.equal(s.mob,Math.round((before.mob+20)*1.15),'bonus and aptitude apply');assert.equal(s.acc,Math.round((before.acc+40)*1.15));assert(s.skills.some(k=>k.id==='pl-s-kai-aim'));
assert.match(run("deployProblem(MISSIONS.find(m=>m.id==='pl-m-01'),['pl-p-kai'])"),/ストライダーに搭乗中/);
assert.equal(run("deployProblem(MISSIONS.find(m=>m.id==='pl-m-01'),['pl-m-strider','pl-u-sgt'])"),'');
assert(run("assignPilot('pl-m-guardian','pl-p-kai')"),'moving a pilot to another unit is allowed');
assert.equal(run("state.pilots['pl-m-strider']"),undefined,'one unit at a time');assert(run("assignPilot('pl-m-strider','pl-p-kai')"));
// Pilot level raises the bonus.
run("state.levels['pl-p-kai']={lv:6,exp:0,sp:0};ensureUnitState();");s=M('pl-m-strider');assert.equal(s.acc,Math.round((before.acc+Math.round(40*1.15))*1.15),'growthPct 3 × 5 levels');
run("state.levels['pl-p-kai']={lv:1,exp:0,sp:0};ensureUnitState();");
// Unit cards show crew state.
G.created.length=0;run('renderUnits()');const cards=G.created.map(e=>e.innerHTML).join('\n');assert.match(cards,/要パイロット/);assert.match(cards,/搭乗: カイ（Lv1）/);assert.match(cards,/ストライダーに搭乗中/);
// After battle the pilot shares experience, fatigue and injury.
const roster=[{id:'pl-m-strider',name:'ストライダー',alive:false,combatId:'a1',pilotId:'pl-p-kai'},{id:'pl-u-sgt',name:'ガント軍曹',alive:true,combatId:'a2'}];G.g.roster=roster;
const rep=JSON.parse(run("JSON.stringify(afterBattle(MISSIONS.find(m=>m.id==='pl-m-01'),{killLog:[]},{outcome:'win',turns:3},roster))"));
assert(rep.exp.some(x=>x.name.startsWith('カイ（ストライダーに搭乗）')&&x.gain>0));assert(run("levelInfo('pl-p-kai').exp>0||levelOf('pl-p-kai')>1"));
assert.equal(run("fatigueOf('pl-p-kai')"),run("fatigueOf('pl-m-strider')"));assert(run("injuryOf('pl-p-kai')>0"),'the pilot is injured when the unit falls');assert(rep.injured.includes('カイ'));
assert.match(run("deployProblem(MISSIONS.find(m=>m.id==='pl-m-01'),['pl-m-guardian'])"),/パイロットが必要/);
run("state.injury['pl-m-strider']=0;delete state.injury['pl-m-strider'];");assert.match(run("deployProblem(MISSIONS.find(m=>m.id==='pl-m-01'),['pl-m-strider'])"),/パイロット カイ が負傷中/);
// A real deployment with a piloted unit.
run("state.injury={};state.fatigue={};state.units={};ensureUnitState();var seed=5;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};");
assert(run("assignPilot('pl-m-guardian','pl-p-rin')"));run("selected=['pl-m-strider','pl-m-guardian','pl-u-sgt'];selectedMission='pl-m-01';");
const expBefore=run("levelInfo('pl-p-rin').exp+levelOf('pl-p-rin')*1000");await run('deploy()');assert.equal(run('battleRunning'),false);assert.equal(JSON.parse(run('JSON.stringify(state.records)')).battles,2);
assert(run("levelInfo('pl-p-rin').exp+levelOf('pl-p-rin')*1000")>expBefore,'riding pilot gained experience in a real battle');
// Reload keeps the units and assignments; invalid assignments are dropped.
const G2=game(new Map(G.memory));assert.equal(G2.run("state.pilots['pl-m-strider']"),'pl-p-kai');assert.equal(G2.run("UNIT_MASTER.find(u=>u.id==='pl-m-strider').pilotId"),'pl-p-kai');
G2.run("state.pilots['pl-u-sgt']='pl-p-rin';state.pilots['missing']='pl-p-kai';ensureUnitState();");assert.equal(G2.run("state.pilots['pl-u-sgt']"),undefined);assert.equal(G2.run("state.pilots['missing']"),undefined);
// Old saves: a legacy pilot assignment survives the conversion (pilot ID becomes the unit ID).
{
  const mem=new Map(),sample19=C.parse(read('pro_190_feature_sample.js'),'VAIS_BUNDLE_PACK');
  mem.set('vais_outer_ops_imported_unit_packs_v1',JSON.stringify([{format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:3,packId:'u3',units:sample19.units.filter(u=>u.deploy.player),pilots:sample19.pilots}]));
  const g0=game(mem);g0.run("state.pilots={'f19-u-tank':'f19-p-kai'};save();");const g1=game(new Map(g0.memory));
  assert.equal(g1.run("state.pilots['f19-u-tank']"),'f19-p-kai');assert(g1.run("UNIT_MASTER.some(u=>u.id==='f19-p-kai'&&u.pilotProfile)"),'legacy pilot is now a deployable unit');
}

// ---- makers ----
{
  const keys=E.unitExtFields().map(f=>f.key);assert(keys.includes('crew')&&keys.includes('pilotProfile'));assert(E.UNIT_EXT_KEYS.includes('crew')&&E.UNIT_EXT_KEYS.includes('pilotProfile'));
  const ppField=E.unitExtFields().find(f=>f.key==='pilotProfile');assert(!ppField.show({crew:'required'})&&ppField.show({}));
  const mech=T.makeUnit('mech','normal','player'),pu=T.makeUnit('pilot','normal','player'),pk=T.makePilotUnit('gunner','射撃手',[mech.id,pu.id]);
  assert.equal(mech.crew,'required');assert(pu.pilotProfile);assert(pk.pilotProfile&&pk.crew==='none');for(const u of [mech,pu,pk]){C.unitExt(u);u.weapons.forEach(C.weapon);}
  assert.equal(C.unitSchemaFor([mech,pu],[]),4);
}
console.log('PASS: pilot units — crew contract, schema 4 / bundle 3, legacy conversion, assignment rules, bonus growth, deploy checks, shared exp/fatigue/injury, real battle, reload and old saves, maker fields and templates');
})().catch(e=>{console.error(e);process.exitCode=1});
