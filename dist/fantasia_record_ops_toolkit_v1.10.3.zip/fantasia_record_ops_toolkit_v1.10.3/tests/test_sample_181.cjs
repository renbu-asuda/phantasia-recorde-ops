(async()=>{
'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',read=f=>fs.readFileSync(root+'/'+f,'utf8');
const source={window:{}};vm.createContext(source);vm.runInContext(read('samples/pro_sample_bundle.js'),source);
const expected=JSON.parse(JSON.stringify(source.window.VAIS_BUNDLE_PACK));
const memory=new Map(),c={window:{},console,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)},confirm:()=>true,alert:()=>{}};
vm.createContext(c);for(const f of ['shared/pro_core.js','shared/pro_battle.js','tests/fixtures/base_181/outer_ops_units.js','tests/fixtures/base_181/outer_ops_missions.js','tests/fixtures/base_181/outer_ops_items.js'])vm.runInContext(read(f),c);
for(const [kind,marker] of [['units','UNIT'],['missions','MISSION'],['items','ITEM']])assert.deepStrictEqual(JSON.parse(JSON.stringify(c.window['VAIS_'+marker+'_PACK'][kind])),expected[kind]);
// The uploaded toolkit retains pro_sample_bundle.js as the canonical sample.
const inline=read('index.html').match(/<script>\s*([\s\S]*?)<\/script>/)[1];
vm.runInContext(inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"))+`\nrender=()=>{};renderCombatants=()=>{};setAction=()=>{};fireLane=()=>{};popDamage=()=>{};log=()=>{};wait=async()=>{};ensureUnitState();`,c);
const run=x=>vm.runInContext(x,c);
assert.equal(run('UNIT_MASTER.length'),4);assert.equal(run('Object.keys(ENEMY_MASTER).length'),1);assert.equal(run('MISSIONS.length'),1);assert(run('missionAvailable(MISSIONS[0])'));
assert.equal(run('MISSIONS[0].reward'),1000);assert.equal(run('MISSIONS[0].maxDeploy'),8);
assert.equal(run("state.items['item-0001']"),1);
run("state.units['unit-0001'].hp=100;");assert(run("useItem('item-0001','unit-0001')"));assert.equal(run("state.units['unit-0001'].hp"),1600);assert.equal(run("state.items['item-0001']"),0);
run("state=defaultState();ensureUnitState();");assert(!run("useItem('item-0001','unit-0001')"));assert.equal(run("state.items['item-0001']"),1);
assert(!run("window.PROCore.checkRequirements(ITEM_MASTER['item-0001'].requires,{tags:['装甲車']}).ok"));
run("Math.random=()=>0;rollMissionDrops(MISSIONS[0]);");assert.equal(run("state.items['item-0001']"),2);
run('Math.random=()=>.99;rollMissionDrops(MISSIONS[0]);');assert.equal(run("state.items['item-0001']"),2);
run("state=defaultState();ensureUnitState();Math.random=()=>.5;var a=makeAlly('unit-0001'),e=makeEnemy('unit-0000-e',0);battleStats={};initBattleStat(a);initBattleStat(e);");
await run('resolveWeapon(a,a.weapons[0],[e],[a],[e])');assert.equal(run('e.currentHp'),2625);
run('e.currentHp=e.maxHp');await run('resolveWeapon(a,a.weapons[1],[e],[a],[e])');assert.equal(run('e.currentHp'),2625);
// Verify maker defaults against the same baseline without running its UI.
const maker={window:{},pack:{units:[]}};vm.createContext(maker);vm.runInContext(read('shared/pro_core.js'),maker);
const line=(file,name)=>read(file).split('\n').find(x=>x.startsWith('function '+name+'('));
vm.runInContext(line('makers/unit_maker.html','newWeapon')+'\n'+line('makers/unit_maker.html','newUnit'),maker);
const fresh=JSON.parse(JSON.stringify(vm.runInContext('newUnit()',maker)));for(const stat of ['hp','atk','def','mob','acc'])assert.equal(fresh[stat],expected.units[0][stat]);assert.deepStrictEqual(fresh.weapons[0],expected.units[0].weapons[0]);
// Exercise the actual attack and skill code over seeded complete battles.
run('var seed=181;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};');
const outcomes={win:0,lose:0,draw:0},turns=[];
for(let trial=0;trial<100;trial++){
 run("state=defaultState();ensureUnitState();var allies=UNIT_MASTER.map(u=>makeAlly(u.id)),enemies=MISSIONS[0].enemies.map((id,i)=>makeEnemy(id,i));battleStats={};[...allies,...enemies].forEach(initBattleStat);");
 let turn=0;for(;turn<30&&run('allies.some(u=>u.alive)&&enemies.some(u=>u.alive)');turn++){
  run("triggerRoundSkills([...allies,...enemies],'turn_start');var order=[...allies,...enemies].filter(u=>u.alive).map(u=>({u,init:u.mob+rand(0,100)})).sort((a,b)=>b.init-a.init).map(x=>x.u);");
  const count=run('order.length');for(let i=0;i<count;i++){c.orderIndex=i;if(run('order[orderIndex].alive&&allies.some(u=>u.alive)&&enemies.some(u=>u.alive)'))await run('attack(order[orderIndex],allies,enemies)');}
  run("triggerRoundSkills([...allies,...enemies],'turn_end');");
 }
 const result=run("enemies.every(u=>!u.alive)&&allies.some(u=>u.alive)?'win':allies.some(u=>u.alive)&&enemies.some(u=>u.alive)?'draw':'lose'");outcomes[result]++;turns.push(turn);
}
assert.equal(outcomes.win+outcomes.lose+outcomes.draw,100);assert(outcomes.win>0);
console.log('PASS: exact sample contents, initial inventory, mission references, tag-restricted healing, drops, E90/knife damage, maker defaults');
console.log('Seeded 4 vs 2 sample battles:',JSON.stringify({...outcomes,minTurns:Math.min(...turns),maxTurns:Math.max(...turns),meanTurns:turns.reduce((a,b)=>a+b,0)/turns.length}));
})().catch(e=>{console.error(e);process.exitCode=1});
