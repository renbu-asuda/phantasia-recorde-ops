(async()=>{'use strict';
// 1.8.4 regressions: storage failures, battle crash recovery, base-pack detection, maker/game consistency.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',html=fs.readFileSync(root+'/index.html','utf8'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
function element(id){return {id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0};}
function game({breakBaseUnits=false,memory=new Map()}={}){
  const els={},alerts=[],storage={fail:false};
  const c={window:{scrollTo(){}},console:{...console,warn(){},error(){}},alerts,storage,setTimeout:f=>setImmediate(f),confirm:()=>true,alert:x=>alerts.push(String(x)),
    document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>element(t),querySelectorAll:()=>[],body:element('body')},
    localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>{if(storage.fail)throw new Error('QuotaExceededError');memory.set(k,v);},removeItem:k=>{if(storage.fail)throw new Error('SecurityError');memory.delete(k);}}};
  vm.createContext(c);
  for(const f of ['shared/pro_core','shared/pro_battle','tests/fixtures/base_181/outer_ops_units','tests/fixtures/base_181/outer_ops_missions','tests/fixtures/base_181/outer_ops_items'])vm.runInContext(fs.readFileSync(root+'/'+f+'.js','utf8'),c);
  if(breakBaseUnits)vm.runInContext("window.VAIS_UNIT_PACK={...window.VAIS_UNIT_PACK,format:'BROKEN'}",c);
  vm.runInContext(code+'\nensureUnitState();',c);
  return {c,els,memory,run:x=>vm.runInContext(x,c)};
}
const core=game().c.window.PROCore;
const unitPack={format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:2,packId:'extra_units',packName:'追加',units:[{id:'extra_soldier',name:'追加兵',deploy:{player:true,enemy:true},weapons:[{name:'銃'}]}]};
const missionPack={format:'VAIS_OUTER_OPS_MISSION_PACK',schemaVersion:1,packId:'extra_missions',packName:'追加作戦',missions:[{id:'extra_m',name:'追加作戦',enemies:['unit-0000-e']}]};
const itemPack={format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:2,packId:'extra_items',packName:'追加品',items:[{id:'extra_kit',name:'追加キット',effect:{type:'heal_hp_flat',value:10}}]};
const file=(marker,data)=>[{name:'x.js',text:async()=>core.serialize(marker,data)}];

// C1: stored packs whose units have skills must survive a reload.
// 1.8.3 loaded them before SKILL_TRIGGERS was initialized, so they were dropped as "invalid" on every start.
{
  const memory=new Map(),first=game({memory});
  first.c.f=[{name:'expansion_packs/PR-01.js',text:async()=>fs.readFileSync(root+'/expansion_packs/PR-01.js','utf8')}];await first.run('importBundleFiles(f)');
  // A skilled unit pack: the player units of the Black Bullet expansion as a stand-alone Unit Pack.
  const bbText=fs.readFileSync(root+'/expansion_packs/black_bullet_bundle_PRO.js','utf8'),bb=JSON.parse(bbText.slice(bbText.indexOf('{'),bbText.lastIndexOf('}')+1));
  first.c.f=[{name:'bb.js',text:async()=>'window.VAIS_UNIT_PACK = '+JSON.stringify({format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:4,packId:'bb_units',packName:'BB',units:bb.units.filter(u=>u.deploy.player)})+';'}];await first.run('importUnitFiles(f)');
  assert.equal(first.run('importedBundlePacks.length'),1);assert.equal(first.run('importedUnitPacks.length'),1);
  assert(first.run("UNIT_MASTER.find(u=>u.id==='PR-01-U-0001').skills.length")>0);
  const reloaded=game({memory});
  assert.equal(reloaded.run('importedBundlePacks.length'),1,'bundle with skilled units lost on reload');
  assert.equal(reloaded.run('importedUnitPacks.length'),1,'unit pack with skills lost on reload');
  assert(reloaded.run("UNIT_MASTER.some(u=>u.id==='PR-01-U-0001')"));assert(reloaded.run("MISSIONS.some(m=>m.id==='PR-01-M-11')"));
  assert.equal(reloaded.run("UNIT_MASTER.find(u=>u.id==='PR-01-U-0001').skills.length"),first.run("UNIT_MASTER.find(u=>u.id==='PR-01-U-0001').skills.length"));
}

// H1: a failed localStorage write must leave memory unchanged and tell the user.
{
  const g=game();g.c.storage.fail=true;
  g.c.f=file('VAIS_UNIT_PACK',unitPack);await g.run('importUnitFiles(f)');
  assert.equal(g.run('importedUnitPacks.length'),0);assert(!g.run("UNIT_MASTER.some(u=>u.id==='extra_soldier')"));
  g.c.f=file('VAIS_MISSION_PACK',missionPack);await g.run('importMissionFiles(f)');
  assert.equal(g.run('importedMissionPacks.length'),0);assert(!g.run("MISSIONS.some(m=>m.id==='extra_m')"));
  g.c.f=file('VAIS_ITEM_PACK',itemPack);await g.run('importItemFiles(f)');
  assert.equal(g.run('importedItemPacks.length'),0);assert(!g.run("ITEM_MASTER.extra_kit"));
  assert.equal(g.c.alerts.filter(x=>x.includes('保存できませんでした')).length,3);
  // Once storage works again the same imports apply and persist.
  g.c.storage.fail=false;
  g.c.f=file('VAIS_UNIT_PACK',unitPack);await g.run('importUnitFiles(f)');assert.equal(g.run('importedUnitPacks.length'),1);assert(g.memory.get('vais_outer_ops_imported_unit_packs_v1').includes('extra_soldier'));
  g.c.storage.fail=true;g.run('removeImportedUnitPack("extra_units")');assert.equal(g.run('importedUnitPacks.length'),1);
  g.run('clearImportedUnitPacks()');assert.equal(g.run('importedUnitPacks.length'),1);
  // save() warns once per failure streak and reports the result.
  const before=g.c.alerts.length;assert.equal(g.run('save()'),false);assert.equal(g.run('save()'),false);assert.equal(g.c.alerts.length,before+1);
  g.c.storage.fail=false;assert.equal(g.run('save()'),true);g.c.storage.fail=true;g.run('save()');assert.equal(g.c.alerts.length,before+2);
}

// H2: an exception during battle releases the lock and rolls back the uncommitted battle.
{
  const g=game();const ally=g.run("UNIT_MASTER[0].id"),mission=g.run('MISSIONS[0].id');
  g.run(`selected=[${JSON.stringify(ally)}];selectedMission=${JSON.stringify(mission)};state.credits=777;`);
  const saved=g.run('JSON.stringify(state)');
  g.run("renderCombatants=()=>{throw new Error('boom');}");
  await g.run('deploy()');
  assert.equal(g.run('battleRunning'),false);assert.equal(g.run('JSON.stringify(state)'),saved);
  assert(g.c.alerts.some(x=>x.includes('作戦を中断')&&x.includes('boom')));
  // The base is usable again: a normal battle afterwards completes.
  g.run("renderCombatants=()=>{};");
  await g.run('deploy()');assert.equal(g.run('battleRunning'),false);assert(g.run('state.credits')>777);
}

// M3: a broken base pack must not turn the first imported pack into an unremovable "base" row.
{
  const g=game({breakBaseUnits:true});g.c.f=file('VAIS_UNIT_PACK',unitPack);await g.run('importUnitFiles(f)');
  assert.equal(g.run('loadedUnitPacks.length'),1);assert(!g.run('loadedUnitPacks[0]._base'));
  g.run('renderUnitPackManager()');assert(g.els.unitPackManager.innerHTML.includes('data-remove-unit-pack="extra_units"'));
  const ok=game();assert(ok.run('loadedUnitPacks[0]._base'));ok.run('renderUnitPackManager()');assert(!ok.els.unitPackManager.innerHTML.includes('data-remove-unit-pack'));
}

// M2 (game side): reserved object keys are rejected as unit IDs; other legacy IDs still load.
{
  const g=game();
  assert.throws(()=>g.run("normalizeUnit({id:'__proto__',name:'x'})"),/使用できません/);
  assert.equal(g.run("normalizeUnit({id:'日本語ID',name:'x'}).id"),'日本語ID');
}

// M1: Mission Maker reads missing deploy/stats exactly like the game.
{
  const src=fs.readFileSync(root+'/makers/mission_maker.html','utf8'),line=src.split('\n').find(x=>x.startsWith('function normalizeUnit('));
  const c={window:{},console};vm.createContext(c);vm.runInContext(fs.readFileSync(root+'/shared/pro_core.js','utf8'),c);for(const f of ['pro_battle','pro_editor'])vm.runInContext(fs.readFileSync(root+'/shared/'+f+'.js','utf8'),c);vm.runInContext('var C=window.PROCore,E=window.PROEditor,clone=x=>JSON.parse(JSON.stringify(x));',c);
  vm.runInContext('const n=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;'+line,c);
  const legacy=vm.runInContext("normalizeUnit({id:'old',name:'旧'})",c);
  assert.deepEqual({...legacy.deploy},{player:true,enemy:false});assert.equal(legacy.hp,3000);assert.equal(legacy.atk,500);assert.equal(legacy.mob,500);assert.equal(legacy.acc,500);
  const enemyOnly=vm.runInContext("normalizeUnit({id:'e',name:'敵',deploy:{enemy:true}})",c);assert.deepEqual({...enemyOnly.deploy},{player:true,enemy:true});
  const g=game();for(const u of [{id:'old',name:'旧'},{id:'e',name:'敵',deploy:{enemy:true}},{id:'p',name:'味',deploy:{player:false,enemy:true}}]){c.u=u;g.c.u=u;assert.deepEqual({...vm.runInContext('normalizeUnit(u).deploy',c)},{...g.run('normalizeUnit(u).deploy')});}
}

// M2 (Unit Maker): export validation rejects IDs the bundle format cannot carry.
{
  const src=fs.readFileSync(root+'/makers/unit_maker.html','utf8'),line=src.split('\n').find(x=>x.startsWith('  pack.units.forEach((u,ui)=>{const label='));assert(line,'unit validation line missing');
  const c={window:{},console};vm.createContext(c);vm.runInContext(fs.readFileSync(root+'/shared/pro_core.js','utf8'),c);for(const f of ['pro_battle','pro_editor'])vm.runInContext(fs.readFileSync(root+'/shared/'+f+'.js','utf8'),c);vm.runInContext('var C=window.PROCore,E=window.PROEditor,clone=x=>JSON.parse(JSON.stringify(x));',c);
  vm.runInContext('function duplicateIds(items){const seen=new Set();return items.filter(x=>{if(seen.has(x.id))return true;seen.add(x.id);return false;}).map(x=>x.id)}',c);
  const check=id=>{c.pack={units:[{id,name:'兵',tags:[],deploy:{player:true},weapons:[{hitsMin:1,hitsMax:1,targetCount:1,weight:1}],skills:[]}]};return vm.runInContext('(()=>{const errors=[],warns=[];'+line+'return errors;})()',c);};
  assert.equal(check('unit-0001').length,0);
  for(const bad of ['日本語','has space','__proto__'])assert(check(bad).some(e=>e.includes('英数字')),bad);
}
console.log('PASS: 1.8.4 skilled pack persistence across reload, storage failure rollback, save warning, battle crash recovery, explicit base packs, reserved unit IDs, Mission/Unit Maker consistency');
})().catch(e=>{console.error(e);process.exitCode=1});
