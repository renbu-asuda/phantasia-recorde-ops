(async()=>{'use strict';
// 1.10.3: the rebuilt shipped base data (outer_ops_*.js) and the folder layout.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');

// ---- folder layout: every local script / stylesheet / link in the pages resolves to a real file ----
const pages=['index.html','makers/unit_maker.html','makers/mission_maker.html','makers/item_maker.html','makers/combined_maker.html','makers/maker_hub.html'];
for(const page of pages){const html=read(page),dir=path.dirname(path.join(root,page));
  for(const m of html.matchAll(/(?:src|href)="([^"#:]+?)"/g)){if(m[1].includes('${'))continue;const target=path.join(dir,m[1]);assert(fs.existsSync(target),`${page}: ${m[1]} が見つかりません`);}
  for(const m of html.matchAll(/\['((?:\.\.\/|makers\/)?[a-z_]+\.html)'/g)){assert(fs.existsSync(path.join(dir,m[1])),`${page}: リンク ${m[1]} が見つかりません`);}}
for(const href of vm.runInNewContext(read('shared/maker_core.js').match(/const routes=(\[[^;]*\]);/)[1]).map(r=>r[0]))assert(fs.existsSync(path.join(root,'makers',href)),'maker_core route '+href);
for(const [dir,files] of Object.entries({samples:['pro_sample_bundle.js','pro_190_feature_sample.js','pro_1101_weapon_effects_sample.js','pro_1102_pilot_sample.js'],expansion_packs:['PR-01.js','pack-0000.js','black_bullet_unit_pack_PRO_v1.js'],docs:['README.txt','CHANGELOG.txt','INTEGRATION.md','TEST_REPORT.txt'],makers:['maker_hub.html']}))for(const f of files)assert(fs.existsSync(path.join(root,dir,f)),dir+'/'+f);
for(const f of ['outer_ops_units.js','outer_ops_missions.js','outer_ops_items.js','index.html'])assert(fs.existsSync(path.join(root,f)),f);

// ---- data contract: latest schemas, everything valid ----
const ctx={window:{},console,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{body:null}};vm.createContext(ctx);
for(const f of ['shared/pro_core','shared/pro_battle','shared/pro_templates','shared/pro_editor','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),ctx);
const C=ctx.window.PROCore,E=ctx.window.PROEditor,B=ctx.window.PROBattle,U=ctx.window.VAIS_UNIT_PACK,M=ctx.window.VAIS_MISSION_PACK,I=ctx.window.VAIS_ITEM_PACK;
assert.equal(U.schemaVersion,4);assert.equal(M.schemaVersion,2);assert.equal(I.schemaVersion,3);
for(const p of [U,M,I])assert.equal(p.packId,'pro-core');
const bundle=C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:3,packId:'check',units:U.units,missions:M.missions,items:I.items,research:I.research});assert.equal(bundle.schemaVersion,3);
U.units.forEach(u=>{C.unitExt(u);u.weapons.forEach(C.weapon);u.skills.forEach(C.skill);});M.missions.forEach(m=>{C.missionExt(m);m.rules.forEach(r=>C.rule(r,m.id));});C.itemPack(I);
// It showcases the current features.
assert(U.units.some(u=>u.crew==='required'&&u.deploy.player),'a unit that needs a pilot');assert(U.units.some(u=>u.pilotProfile&&!u.recruit),'a starting pilot');
assert(U.units.some(u=>u.weapons.some(w=>w.effects?.length)),'weapon effects');assert(U.units.some(u=>u.skillTree?.length),'skill tree');assert(U.units.some(u=>u.recruit?.locked),'recruitable units');
for(const t of ['defense','escort','boss','chain'])assert(M.missions.some(m=>m.objective?.type===t),'objective '+t);
assert(I.items.some(i=>i.equip)&&I.items.some(i=>i.key)&&I.items.some(i=>i.effect?.type==='loot_box')&&I.items.some(i=>i.price)&&I.research.length>=2);
// Every mission is winnable with the starting squad (simulated at Lv1, one pilot aboard the required unit).
{
  const defs=Object.fromEntries(U.units.map(u=>[u.id,E.battleUnit(u)])),start=U.units.filter(u=>u.deploy.player&&!u.recruit?.locked);
  const pilot=start.find(u=>u.pilotProfile),mech=start.find(u=>u.crew==='required');const md={...defs[mech.id]};for(const [k,v] of Object.entries(C.pilotBonus(pilot.pilotProfile,1)))md[k]+=v;
  const squad=[...start.filter(u=>u!==pilot&&u!==mech&&u.crew!=='required').map(u=>defs[u.id]),md];
  for(const m of M.missions){const r=await B.simulate({allies:squad.slice(0,m.maxDeploy),enemies:m.enemies,mission:E.battleMission(m),enemyDefs:defs,unitDefs:defs,trials:20,seed:9});assert(r.winRate>=.3,`${m.name}: 勝率 ${r.winRate}`);}
}

// ---- game boots on the new base data ----
const html=read('index.html'),inline=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],code=inline.slice(inline.indexOf("'use strict';"),inline.indexOf("document.getElementById('deployBtn').onclick"));
const element=id=>({id,style:{},dataset:{},value:'',textContent:'',innerHTML:'',className:'',disabled:false,hidden:false,checked:false,classList:{add(){},remove(){},toggle(){}},appendChild(){},append(){},remove(){},replaceChildren(){},setAttribute(){},removeAttribute(){},focus(){},querySelector:()=>element('q'),querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,top:0,width:10}),addEventListener(){},scrollTop:0,scrollHeight:0});
const warnings=[],memory=new Map(),els={};const g={window:{scrollTo(){}},console:{...console,warn:(...a)=>warnings.push(a.join(' ')),error:(...a)=>warnings.push(a.join(' '))},setTimeout:f=>setImmediate(f),confirm:()=>true,alert(){},document:{getElementById:id=>els[id]||(els[id]=element(id)),createElement:t=>element(t),querySelectorAll:()=>[],body:element('body')},localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)}};
vm.createContext(g);for(const f of ['shared/pro_core','shared/pro_battle','outer_ops_units','outer_ops_missions','outer_ops_items'])vm.runInContext(read(f+'.js'),g);vm.runInContext(code+'\nensureUnitState();',g);const run=x=>vm.runInContext(x,g);
assert.deepEqual(warnings,[]);
assert.deepEqual(JSON.parse(run('JSON.stringify(state.items)')),{'core-i-medkit':1},'new games start with one healing item');
assert.deepEqual(JSON.parse(run('JSON.stringify(UNIT_MASTER.map(u=>u.id))')),U.units.filter(u=>u.deploy.player&&!u.recruit?.locked).map(u=>u.id));
assert.equal(run("missionLockReason(MISSIONS.find(m=>m.id==='core-m-01'))"),'');assert(run("missionLockReason(MISSIONS.find(m=>m.id==='core-m-02'))").includes('前提作戦'));
assert(run('MISSIONS.every(missionAvailable)'),'every mission has its enemies / escort');
assert.match(run("deployProblem(MISSIONS.find(m=>m.id==='core-m-01'),['core-u-strider'])"),/パイロットが必要/);
assert(run("assignPilot('core-u-strider','core-u-kai')"));
run("var seed=3;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};selected=['core-u-jackal','core-u-turtle','core-u-mina','core-u-strider'];selectedMission='core-m-01';");
await run('deploy()');assert.equal(run("state.missions['core-m-01']?.clears"),1,'the first mission clears');assert(run("levelInfo('core-u-kai').exp>0"),'the riding pilot gains experience');
// Research unlocks the shop items and the second pilot-required unit.
run("state.credits=100000;state.items['core-i-manual']=1;");assert(!run("shopAvailable(ITEM_MASTER['core-i-armor'])"));
assert(run("doResearch('core-r-shop')"));assert(run("shopAvailable(ITEM_MASTER['core-i-armor'])"));
assert(run("doResearch('core-r-guardian')"));assert(run("UNIT_MASTER.some(u=>u.id==='core-u-guardian')"),'research recruits the second pilot-required unit');
// Makers read the base packs.
for(const f of ['makers/mission_maker.html','makers/item_maker.html','makers/combined_maker.html'])assert(read(f).includes('src="../outer_ops_units.js"'),f+' loads the base units');
console.log(`PASS: folder layout (${pages.length} pages, links resolve), base data Unit 4 / Mission 2 / Item 3 with pilots, weapon effects, objectives, shop and research, every mission winnable, game boots and clears the first mission`);
})().catch(e=>{console.error(e);process.exitCode=1});
