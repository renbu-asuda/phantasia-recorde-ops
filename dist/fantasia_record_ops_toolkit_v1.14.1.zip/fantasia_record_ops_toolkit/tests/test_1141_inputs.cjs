(async()=>{'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const {setup,byLabel,byText}=require('./dom_lite.cjs'),{game}=require('./game_harness.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const memory=new Map();function environment(){const {document}=setup(),c={window:{},document,console,setTimeout:f=>f(),localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)}};vm.createContext(c);for(const f of ['pro_core','pro_battle','pro_templates','pro_editor','maker_core'])vm.runInContext(read('shared/'+f+'.js'),c);return c;}
const c=environment(),C=c.window.PROCore,B=c.window.PROBattle,E=c.window.PROEditor,T=c.window.PROTemplates,plain=x=>JSON.parse(JSON.stringify(x));
const skill=(effect,value,extra={})=>C.skill({id:'s',name:'試験',trigger:'turn_start',effect,value,chance:100,maxUses:0,...extra});

// Signed values are accepted only by supported effects; imports and exports use the same validator.
for(const effect of C.SIGNED_HP_EFFECTS){assert.equal(skill(effect,-25).value,-25);assert.equal(C.weaponEffect({timing:'after',effect,value:-25}).value,-25);assert(C.skillText(skill(effect,-25)).includes('ダメージ'));assert(E.describeSkill(skill(effect,-25)).includes('ダメージ'));assert(C.weaponEffectText(C.weaponEffect({timing:'after',effect,value:-25})).includes('ダメージ'));}
assert.throws(()=>skill('shield',-1));assert.throws(()=>C.weaponEffect({timing:'after',effect:'burn',value:-1}));assert.throws(()=>C.effect({type:'heal_hp_pct',value:-10}));
for(const field of E.weaponFields().filter(f=>f.type==='number'&&Object.hasOwn(C.weaponDefaults,f.key))){const r=C.weaponValueRange(field.key);assert.equal(field.min,r.min);assert.equal(field.max,r.max);}
{
 const obj=skill('heal_maxhp_pct',-20),box=c.document.createElement('div');E.form(box,obj,E.skillFields(),()=>{});
 let signs=()=>box.querySelectorAll('button').filter(x=>x.textContent==='±'&&!x.hidden);assert.equal(signs().length,1);signs()[0].click();assert.equal(obj.value,20);
 const choice=()=>byLabel(box,'何が起きる？');choice().value='shield';choice().onchange();assert.equal(signs().length,0);choice().value='heal_flat';choice().onchange();assert.equal(signs().length,1);
 const input=c.document.createElement('input'),parent=c.document.createElement('div');parent.append(input);input.type='number';input.min=-100;input.value='-5';E.numberInput(input);assert(!input._proSign.hidden);input.min=0;E.numberInput(input);assert(input._proSign.hidden);assert.equal(input.type,'number');input.min=-100;E.numberInput(input);assert(!input._proSign.hidden);assert.equal(parent.querySelectorAll('button').length,1);
 const noMin=c.document.createElement('input');noMin.type='number';E.numberInput(noMin);assert(!noMin._proSign);
}
function battle(sk,enemySkills=[]){const u=B.combatant({id:'u',name:'味方',hp:1000,atk:0,def:0,mob:0,acc:0,skills:[sk]},'ally','u'),t=B.combatant({id:'e',name:'敵',hp:1000,atk:0,def:99999,mob:0,acc:0,skills:enemySkills},'enemy','e'),logs=[];t.status.shield=99999;const ctx=B.createContext({allies:[u],enemies:[t],rng:()=>0,hooks:{logSkill:(u,s,d)=>logs.push(d)}});return {u,t,ctx,logs};}
{
 const {u,t,ctx,logs}=battle(skill('heal_maxhp_pct',-25,{target:'enemies'}));B.triggerRoundSkills(ctx,[u],'turn_start');assert.equal(t.currentHp,750,'full HP receives percentage damage based on max HP');assert.equal(t.status.shield,99999);assert.equal(B.statFor(ctx,u).damage,250);assert.equal(B.statFor(ctx,t).damageTaken,250);assert(logs.some(x=>x.includes('ダメージ')));
 t.currentHp=100;B.triggerRoundSkills(ctx,[u],'turn_start');assert(!t.alive);assert.equal(t.currentHp,0);assert.equal(ctx.killLog.length,1);assert.equal(B.statFor(ctx,u).kills,1);assert.equal(B.statFor(ctx,u).damage,350,'overkill is clamped to actual HP');
}
{
 const guts=skill('guts',5,{trigger:'on_death',maxUses:1}),{u,t,ctx}=battle(skill('heal_maxhp_pct',-100,{target:'enemies'}),[guts]);B.triggerRoundSkills(ctx,[u],'turn_start');assert(t.alive);assert.equal(t.currentHp,5);B.triggerRoundSkills(ctx,[u],'turn_start');assert(!t.alive);assert.equal(ctx.killLog.length,1);
}
{
 const {u,t,ctx}=battle(skill('heal_maxhp_pct',-100,{target:'self'}));B.triggerRoundSkills(ctx,[u],'turn_start');assert(!u.alive);assert.equal(ctx.killLog[0].killer,null);assert.equal(B.statFor(ctx,u).kills,0);
 const z=battle(skill('heal_flat',0));z.u.currentHp=500;B.triggerRoundSkills(z.ctx,[z.u],'turn_start');assert.equal(z.u.currentHp,500,'zero does not heal one HP');
 const h=battle(skill('heal_maxhp_pct',25));h.u.currentHp=900;B.triggerRoundSkills(h.ctx,[h.u],'turn_start');assert.equal(h.u.currentHp,1000);assert.equal(h.t.currentHp,1000);
 const n=battle(skill('heal_flat',-10));B.triggerRoundSkills(n.ctx,[n.u],'turn_start');assert.equal(n.u.currentHp,990,'omitted target preserves self');assert.equal(n.t.currentHp,1000);
}
{
 const {u,t,ctx}=battle(skill('heal_flat',0));B.weaponEffects(ctx,u,{name:'割合弾',effects:[{timing:'after',effect:'heal_maxhp_pct',value:-100,target:'targets'}]},'after',{targets:[t]});assert(!t.alive);assert.equal(B.statFor(ctx,u).kills,1);
 // A finite on-kill chain cannot recursively reuse an effect before consuming its maxUses.
 const chain=skill('heal_flat',-1000,{id:'chain',trigger:'on_kill',target:'enemies',maxUses:1});u.skills.push(chain);const e2=B.combatant({...t,id:'e2',name:'敵2',hp:1000},'enemy','e2'),e3=B.combatant({...t,id:'e3',name:'敵3',hp:1000},'enemy','e3');ctx.enemies.push(e2,e3);B.triggerSkills(ctx,u,'on_kill',{opponent:t});assert.equal(u.skillUses.chain,1);assert.equal(ctx.killLog.length,3);
}
{const dying=battle(skill('heal_flat',-10,{trigger:'on_death',target:'self'}));dying.u.currentHp=-20;assert(B.handleDeath(dying.ctx,dying.u,dying.t));assert.equal(dying.u.currentHp,0);assert.equal(dying.ctx.killLog.length,1);}
// More than three segments, ordering, collision avoidance, preset persistence and all creation paths.
const prefs={presets:[{id:'p',name:'自由パターン',separator:'-',start:1,width:3,parts:[{type:'text',value:'renbu'},{type:'text',value:'pro'},{type:'kind'},{type:'text',value:'test'},{type:'counter'}]}],active:{unit:'p',skill:'p',weapon:'p',item:'p',mission:'p'}};
assert(E.saveIdPreferences(prefs));assert.equal(T.autoId('unit',['renbu-pro-unit-test-001']),'renbu-pro-unit-test-002');assert.equal(T.makeUnit('infantry','normal','both','兵士',[]).id,'renbu-pro-unit-test-001');assert(E.newSkill().id.startsWith('renbu-pro-skill-test-'));assert(E.duplicateOf({id:'s',name:'S',trigger:'turn_end'}).id.startsWith('renbu-pro-skill-test-'));assert(E.duplicateOf({id:'old',name:'U'}).id.startsWith('old_'),'unconfigured kinds preserve existing duplicate naming');
const c2=environment();assert.equal(c2.window.PROTemplates.autoId('unit',['renbu-pro-unit-test-001','renbu-pro-unit-test-002']),'renbu-pro-unit-test-003');assert.equal(c2.window.PROEditor.idPreferences().presets[0].parts.length,5);const data={skills:[{id:'renbu-pro-skill-test-007'}]};c2.window.PROEditor.registerIdSource(()=>data);const skillIds=Array.from({length:7},()=>c2.window.PROEditor.patternId('skill',[]));assert(!skillIds.includes('renbu-pro-skill-test-007'),'existing nested IDs are avoided even if a factory supplies no list');
const fixed={presets:[{id:'fixed',name:'固定',separator:'_',start:1,width:2,parts:[{type:'text',value:'foo'}]}],active:{item:'fixed'}};E.saveIdPreferences(fixed);assert.equal(c2.window.PROEditor.idPreferences().active.item,'fixed','other open makers see updated preferences');assert.equal(T.autoId('item',[]),'foo');assert.equal(T.autoId('item',['foo']),'foo-02');assert.throws(()=>E.saveIdPreferences({...fixed,presets:[{...fixed.presets[0],parts:[{type:'text',value:'日本語'}]}]}));
{
 E.saveIdPreferences({presets:[],active:{}});const parent=c.document.createElement('div');E.idPresetEditor(parent);byText(parent,'button','＋ 区画を追加').click();byText(parent,'button','＋ 区画を追加').click();assert(byLabel(parent,'ID区画5の種類'));byLabel(parent,'ID区画5を前へ').click();byLabel(parent,'ID区画1を削除').click();assert(byLabel(parent,'ID区画4の種類'));byText(parent,'button','保存してこの種類に適用').click();assert.equal(E.idPreferences().presets[0].parts.length,4);assert(E.patternId('unit',[]));
 const target=byLabel(parent,'IDプリセットの対象');target.value='weapon';target.onchange();const sel=byLabel(parent,'編集するIDプリセット');sel.value=E.idPreferences().presets[0].id;sel.onchange();byText(parent,'button','保存してこの種類に適用').click();assert(E.patternId('weapon',[]));byText(parent,'button','この種類への適用を解除').click();assert.equal(E.patternId('weapon',[]),null);
}
// Compact labels retain their independent name mapping and distinguish namesakes.
const units=[{id:'a',name:'兵士',hp:1000,tags:['歩兵','タグ2']},{id:'b',name:'兵士',hp:2000},{id:'c',name:'別名（補足）',hp:3000}];const list=E.unitChoices(units);assert(list[0][1].includes('HP 1,000（a）'));assert(!list[0][1].includes('歩兵'));assert.equal(E.labelNames(list).a,'兵士');assert.equal(E.labelNames(list).c,'別名（補足）');
const g=game();g.run("state=defaultState();ensureUnitState();renderItems();");const options=g.run("document.getElementById('itemTarget').innerHTML");assert(options.includes(' / HP '));assert(!options.includes(' / Lv'));assert(!options.includes('歩兵・'));assert.equal(g.run('GAME_VERSION'),'1.14.1');
console.log('PASS 1.14.1: signed HP, death/guts/kill chains, numeric buttons, arbitrary ID patterns/persistence/collisions and compact unit labels');
})().catch(e=>{console.error(e);process.exitCode=1;});
