(async()=>{'use strict';
// 1.13.0: hire offers (cost, limit, unlock conditions, hidden), sortie cost paid on every sortie,
// equipment slots per unit and the equip_slot item effect.
const assert=require('assert'),vm=require('vm'),{game,read}=require('./game_harness.cjs');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(read('shared/pro_core.js'),ctx);const C=ctx.window.PROCore;

// ---- contract ----
assert.deepEqual(JSON.parse(JSON.stringify(C.hire({id:'h',unitId:'u',cost:'300',limit:0,requires:{missions:[],day:0},hidden:false}))),{id:'h',unitId:'u',cost:300});
assert.deepEqual(JSON.parse(JSON.stringify(C.hire({id:'h',unitId:'u',requires:{missions:['m'],research:['r'],items:['k'],day:3},hidden:true,limit:2,note:'メモ'}))),{id:'h',unitId:'u',cost:0,limit:2,requires:{missions:['m'],research:['r'],items:['k'],day:3},hidden:true,note:'メモ'});
assert.throws(()=>C.hire({id:'h',unitId:'u',cost:-1}),/雇用費/);assert.throws(()=>C.hire({id:'bad id',unitId:'u'}),/ID/);assert.throws(()=>C.hire({id:'h'}),/ユニットID/);
assert.throws(()=>C.hireList([{id:'a',unitId:'u'},{id:'a',unitId:'v'}]),/重複/);
assert.equal(C.hireRequirementText({requires:{missions:['m1'],day:5}},{m1:'演習'}),'作戦クリア: 演習 ／ 5日目以降');assert.equal(C.hireRequirementText({}),'いつでも雇える');
const unit={id:'u',name:'U',hp:1000,atk:100,def:0,mob:0,acc:0,weapons:[{name:'w'}]};
assert.equal(C.unitSchemaFor([unit],[]),2);assert.equal(C.unitSchemaFor([{...unit,sortieCost:50}],[]),6);assert.equal(C.unitSchemaFor([{...unit,equipSlots:3}],[]),6);assert.equal(C.unitSchemaFor([{...unit,equipSlots:2}],[]),2);assert.equal(C.unitSchemaFor([{...unit,noFire:true}],[]),6);assert.equal(C.unitSchemaFor([unit],[],[{id:'h',unitId:'u'}]),6);
assert.deepEqual(JSON.parse(JSON.stringify(C.unitExt({...unit,sortieCost:50,equipSlots:4,noFire:true}))),{sortieCost:50,equipSlots:4,noFire:true});
assert.deepEqual(JSON.parse(JSON.stringify(C.unitExt({...unit,sortieCost:0,equipSlots:2,noFire:false}))),{});
assert.throws(()=>C.unitExt({...unit,equipSlots:7}),/装備枠/);
assert.equal(C.effectText({type:'equip_slot',value:1}).includes('装備枠'),true);assert.throws(()=>C.effect({type:'equip_slot',value:0}));assert.throws(()=>C.effect({type:'equip_slot',value:4}));
const b=C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:6,packId:'p',missions:[],items:[],units:[{...unit,deploy:{player:true,enemy:false}}],hires:[{id:'h',unitId:'u',cost:10}]});assert.equal(b.schemaVersion,6);assert.equal(b.hires[0].cost,10);
assert.equal(C.bundlePack({format:C.BUNDLE_FORMAT,schemaVersion:6,packId:'p',missions:[],items:[],units:[{...unit,deploy:{player:true,enemy:false}}]}).schemaVersion<6,true,'without new fields the bundle keeps an older number');

// ---- game: offers and unlocks ----
const g=game(),run=g.run;
assert.deepEqual(run('Object.keys(HIRE_MASTER).sort()'),['core-h-fox','core-h-mina','core-h-strider','core-h-tiger']);
assert.deepEqual(run('Object.values(HIRE_MASTER).filter(hireVisible).map(h=>h.id).sort()'),['core-h-fox','core-h-mina','core-h-tiger'],'the hidden offer waits for its research');
assert.match(run("hireProblem(HIRE_MASTER['core-h-fox'])"),/🔒 作戦クリア: 防衛線維持/);
assert.equal(run("hireProblem(HIRE_MASTER['core-h-tiger'])"),'');
run("state.missions['core-m-02']={clears:1,best:5,stars:[true,false,false]};state.credits=100000;");assert.equal(run("hireProblem(HIRE_MASTER['core-h-fox'])"),'');
assert(run("doResearch('core-r-shop')"));assert(run("hireVisible(HIRE_MASTER['core-h-strider'])"));assert.equal(run("hireProblem(HIRE_MASTER['core-h-strider'])"),'');
// Item / day conditions.
run("HIRE_MASTER['x-h']=C.hire({id:'x-h',unitId:'core-u-turtle',cost:0,requires:{items:['core-i-keycard'],day:3}});");
assert.match(run("hireProblem(HIRE_MASTER['x-h'])"),/キーアイテム: 基地カードキー ／ 3日目以降/);
run("state.items['core-i-keycard']=1;");assert.match(run("hireProblem(HIRE_MASTER['x-h'])"),/3日目以降/);run('state.day=3;');assert.equal(run("hireProblem(HIRE_MASTER['x-h'])"),'');
assert(run("hireUnit('x-h',false)"),'a free offer');
// An offer for a unit that is not loaded.
run("HIRE_MASTER['y-h']=C.hire({id:'y-h',unitId:'nope'});");assert.match(run("hireProblem(HIRE_MASTER['y-h'])"),/読み込まれていません/);assert(!run("hireUnit('y-h',false)"));
// Limit counts owned copies (mina joined for free → 2 more).
assert(run("hireUnit('core-h-mina',false)"));assert(run("hireUnit('core-h-mina',false)"));assert.match(run("hireProblem(HIRE_MASTER['core-h-mina'])"),/上限（3体）/);assert(!run("hireUnit('core-h-mina',false)"));
// Cost.
run('state.credits=1000;');assert.match(run("hireProblem(HIRE_MASTER['core-h-tiger'])"),/資金が足りません/);assert(!run("hireUnit('core-h-tiger',false)"));assert.equal(run('state.credits'),1000);
run('state.credits=1200;');assert(run("hireUnit('core-h-tiger',false)"));assert.equal(run('state.credits'),0);
// Recommendations and next action.
{const h=game();h.run("state.credits=5000;");assert(h.run("nextActions().some(a=>a.view==='hire')")||h.run("nextActions().length===3"));
  h.run("state.roster=state.roster.filter(e=>e.base!=='core-u-mina');ensureUnitState();");assert.equal(h.run("UNIT_MASTER.some(u=>unitRoleKey(u)==='回復')"),false);assert.equal(h.run("unitRoleKey(BASE_UNIT_MASTER.find(u=>u.id==='core-u-mina'))"),'回復');}

// ---- sortie cost: paid on every sortie, blocks when credits would go negative ----
{
  const s=game(),r=s.run;
  assert.equal(r("UNIT_MASTER.find(u=>u.id==='core-u-strider').sortieCost"),120);assert.equal(r("sortieCostTotal(['core-u-strider','core-u-jackal'])"),120);
  r("assignPilot('core-u-strider','core-u-kai');state.credits=100;");
  assert.match(r("deployProblem(MISSIONS.find(m=>m.id==='core-m-01'),['core-u-strider','core-u-jackal'])"),/出撃費用 120 が資金 100 を超えています/);
  r('state.credits=120;');assert.equal(r("deployProblem(MISSIONS.find(m=>m.id==='core-m-01'),['core-u-strider','core-u-jackal'])"),'','exactly enough is fine');
  // A lost battle still costs the sortie fee.
  r("var seed=9;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};battleControl.skip=true;showStory=async()=>{};state.credits=1000;selected=['core-u-strider'];selectedMission='core-m-04';state.missions['core-m-02']={clears:1,best:1,stars:[false,false,false]};");
  r("missionLockReason=()=>'';");
  const reward=r("MISSIONS.find(m=>m.id==='core-m-04').reward");
  await r('deploy()');const lost=r("state.records.losses+state.records.draws");
  const after=r('state.credits');assert.equal(lost,1,'a lone unit loses');
  assert.equal(after,1000-120+Math.round(reward*(r('state.records.draws')?0.25:0.12)),'fee paid even on a loss');
  assert.match(g.c.document.getElementById('resultMeta').textContent+s.c.document.getElementById('resultMeta').textContent,/出撃費用 -120/);
}

// ---- equipment slots ----
{
  const e=game({memory:new Map()}),r=e.run;
  assert.equal(r("slotsOf('core-u-tiger')"),2);r("state.items['core-i-scope']=3;");
  assert(r("equipItem('core-u-tiger',1,'core-i-scope')"));assert(!r("equipItem('core-u-tiger',2,'core-i-scope')"),'no third slot');
  // A unit with a custom slot count.
  r("BASE_UNIT_MASTER.find(u=>u.id==='core-u-fox').equipSlots=0;ensureUnitState();");assert.equal(r("slotsOf('core-u-fox')"),0);assert(!r("equipItem('core-u-fox',0,'core-i-scope')"));
  // equip_slot item: +1 up to 8, −1 returns overflowing equipment to the items.
  r("state.items['core-i-rack']=7;");assert(r("useItem('core-i-rack','core-u-tiger')"));assert.equal(r("slotsOf('core-u-tiger')"),3);assert(r("equipItem('core-u-tiger',2,'core-i-scope')"));
  assert.equal(r("UNIT_MASTER.find(u=>u.id==='core-u-tiger').equipSlots"),3);
  for(let i=0;i<5;i++)assert(r("useItem('core-i-rack','core-u-tiger')"));assert.equal(r("slotsOf('core-u-tiger')"),8);
  assert.equal(r("planItem(ITEM_MASTER['core-i-rack'],UNIT_MASTER.find(u=>u.id==='core-u-tiger')).ok"),false,'max 8 slots');assert.equal(r("state.items['core-i-rack']"),1,'nothing consumed on failure');
  r("ITEM_MASTER['minus']=C.item({id:'minus',name:'枠を減らす',effect:{type:'equip_slot',value:-3}});state.items['minus']=3;");
  const before=r("state.items['core-i-scope']");
  r("rosterEntry('core-u-tiger').slotMod=0;ensureUnitState();");assert.equal(r("slotsOf('core-u-tiger')"),2);assert.equal(r("state.items['core-i-scope']"),before+1,'the third slot went back to the items');
  assert(r("useItem('minus','core-u-tiger')"));assert.equal(r("slotsOf('core-u-tiger')"),0);assert.equal(r("state.items['core-i-scope']"),before+2);assert.equal(r("equippedItems('core-u-tiger').length"),0);
  assert.equal(r("planItem(ITEM_MASTER['minus'],UNIT_MASTER.find(u=>u.id==='core-u-tiger')).ok"),false,'no fewer than 0');
  // The slot change survives a reload and is per copy.
  r("save()");const e2=game({memory:e.memory});assert.equal(e2.run("slotsOf('core-u-tiger')"),0);
  e2.run("state.credits=9999;hireUnit('core-h-tiger',false);");assert.equal(e2.run("slotsOf('core-u-tiger__2')"),2);
}

// ---- unit pack with hires is read by the game ----
{
  const h=game(),r=h.run;
  const pack={format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:6,packId:'hp',packName:'雇用パック',units:[{...unit,id:'hp-u',deploy:{player:true,enemy:false},recruit:{locked:true},sortieCost:30,equipSlots:3,noFire:true}],hires:[{id:'hp-h',unitId:'hp-u',cost:500,hidden:true,requires:{day:2}}]};
  const v=r(`validatePack(${JSON.stringify(pack)})`);assert.equal(v.hires.length,1);
  r(`importedUnitPacks=[validatePack(${JSON.stringify(pack)})];rebuildUnitMasters();ensureUnitState();`);
  assert(r("HIRE_MASTER['hp-h']"));assert(!r("inRoster('hp-u')"),'a hire-only unit does not join for free');assert(!r("hireVisible(HIRE_MASTER['hp-h'])"));
  r('state.day=2;state.credits=600;');assert(r("hireUnit('hp-h',false)"));const u=r("UNIT_MASTER.find(u=>u.id==='hp-u')");assert.equal(u.sortieCost,30);assert.equal(u.equipSlots,3);assert.equal(u.noFire,true);
  assert.throws(()=>r(`validatePack(${JSON.stringify({...pack,schemaVersion:7})})`),/未対応/);
}

console.log('PASS: hires (contract, schema 6, bundle, unlock by mission/research/item/day, hidden, limit, cost, free, missing unit, recommendations, next action), sortie cost (blocks, exact credits, paid on a loss, result text), equipment slots (per unit, 0 slots, equip_slot item up/down with overflow back to items, limits, reload, per copy), unit pack hires in the game');
})().catch(e=>{console.error(e);process.exit(1);});
