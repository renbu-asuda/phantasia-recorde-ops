(async()=>{'use strict';
// 1.13.0 maker inputs: tag chips, duplicate buttons (fresh skill IDs), fraction drop rates, hide-until-unlocked
// selectors, hire fields; the game's exact odds, hidden missions / research and today's weekday.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');const {setup,byText,byLabel}=require('./dom_lite.cjs');const {game}=require('./game_harness.cjs');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const {document}=setup();const c={window:{},console,document,setTimeout:f=>f(),localStorage:{getItem:()=>null,setItem(){},removeItem(){}}};vm.createContext(c);
for(const f of ['pro_core','pro_battle','pro_templates','pro_editor'])vm.runInContext(read('shared/'+f+'.js'),c);
const C=c.window.PROCore,E=c.window.PROEditor;assert.equal(E.version,'1.7.0');assert.equal(C.version,'2.5.0');
const opts={refs:kind=>kind==='players'?[['u1','兵士（u1）']]:kind==='missions'?[['m1','演習（m1）']]:kind==='research'?[['r1','開発（r1）']]:kind==='keyItems'?[['k1','鍵（k1）']]:[]};
const mount=(obj,fields)=>{const box=document.createElement('div');let n=0;E.form(box,obj,fields,()=>n++,opts);return {box,changes:()=>n};};
const chips=box=>box.querySelectorAll('span').filter(s=>s.className==='pro-tag-chip').map(s=>s.children[0].textContent);

// ---- tag chips ----
{
  const obj={tags:['歩兵']};const {box,changes}=mount(obj,[{key:'tags',label:'タグ',type:'tags'}]);
  assert.deepEqual(chips(box),['歩兵']);
  const input=byLabel(box,'タグを入力'),plus=byLabel(box,'タグを追加');
  input.value='地上';plus.click();assert.deepEqual(C.clone(obj.tags),['歩兵','地上']);assert.equal(input.value,'');assert(changes()>=1);
  input.value='量産型';let prevented=false;input.onkeydown({key:'Enter',preventDefault(){prevented=true;}});assert(prevented);assert.deepEqual(C.clone(obj.tags),['歩兵','地上','量産型']);
  input.value='地上';plus.click();assert.equal(obj.tags.length,3,'duplicates are ignored');
  input.value='  ';plus.click();assert.equal(obj.tags.length,3,'blank is ignored');
  input.value='A, B、C';input.onpaste();assert.deepEqual(C.clone(obj.tags).slice(3),['A','B','C'],'pasted text with commas is split');
  byLabel(box,'タグ「地上」を削除').click();assert.deepEqual(C.clone(obj.tags),['歩兵','量産型','A','B','C']);assert.deepEqual(chips(box),['歩兵','量産型','A','B','C']);
  for(const t of ['歩兵','量産型','A','B','C'])byLabel(box,`タグ「${t}」を削除`).click();assert.equal(obj.tags,undefined,'empty optional tags are removed');
  // keepEmptyArray and the 16-tag limit
  const o2={tags:[]};const m2=mount(o2,[{key:'tags',label:'分類',type:'tags',keepEmptyArray:true}]);const in2=byLabel(m2.box,'分類を入力');
  in2.value=Array.from({length:20},(_,i)=>'t'+i).join(',');byLabel(m2.box,'分類を追加').click();assert.equal(o2.tags.length,16);assert(byLabel(m2.box,'分類を追加').disabled);
  const w=E.tagInput(document.createElement('div'),['x'],()=>{});w.input.value='y';assert(w.commit());assert.deepEqual(w.values,['x','y']);w.set(['z']);assert.deepEqual(w.values,['z']);
  // Every maker uses the chip input (no comma-only tag boxes left).
  const um=read('unit_maker.html'),mm=read('mission_maker.html'),im=read('item_maker.html'),cm=read('combined_maker.html');
  assert(um.includes("E.tagInput($('u_tagsBox')")||um.includes('E.tagInput(box,u.tags'));assert(mm.includes("E.tagInput(box,m.tags"));assert(im.includes('tagBoxes[k]=E.tagInput'));assert(cm.includes('return E.tagInput(wrap'));
  assert(!/カンマ区切り/.test(um.match(/分類タグ[\s\S]{0,300}/)[0]));
}

// ---- duplicate buttons ----
{
  const sk=E.newSkill();const obj={skills:[sk]};const {box}=mount(obj,[{key:'skills',label:'スキル',type:'list',itemType:'skill',max:3,factory:E.newSkill}]);
  byLabel(box,'スキル 1を複製').click();assert.equal(obj.skills.length,2);assert.notEqual(obj.skills[1].id,obj.skills[0].id,'fresh skill ID');assert.equal(obj.skills[1].name,sk.name);assert.notStrictEqual(obj.skills[1],obj.skills[0]);
  byLabel(box,'スキル 1を複製').click();assert(byLabel(box,'スキル 1を複製').disabled,'max reached');
  // Weapons keep a unique name (the game dedupes weapons by name); nested skills inside effects get fresh IDs.
  const w=E.duplicateOf({name:'ライフル',attackType:'ranged',damageType:'physical'});assert.equal(w.name,'ライフル（複製）');
  const node={id:'node_abc123',cost:1,skill:{id:'skill_x',name:'s',trigger:'before_attack',effect:'damage_up_pct'}},n2=E.duplicateOf(node);assert.notEqual(n2.id,node.id);assert.notEqual(n2.skill.id,'skill_x');assert(/^node_[a-z0-9]{6}$/.test(n2.id));
  const eff=E.duplicateOf({type:'add_skill',skill:{id:'s1',name:'a',trigger:'turn_end',effect:'heal_flat'}});assert.notEqual(eff.skill.id,'s1');
  // Waves.
  const m={enemies:['a'],waves:[{enemies:['a'],when:'turn',value:3}]};const mw=mount(m,[{key:'waves',type:'waves',label:'追加ウェーブ',ref:'enemies'}]);
  byLabel(mw.box,'この波を複製').click();assert.equal(m.waves.length,2);assert.deepEqual(C.clone(m.waves[1]),C.clone(m.waves[0]));
  // Makers expose duplicate buttons for weapons, skills and effects.
  assert(read('unit_maker.html').includes('wdup')&&read('unit_maker.html').includes('sdup'));assert(read('item_maker.html').includes("btn('複製'"));assert(read('combined_maker.html').includes("dup=btn('複製'"));
}

// ---- drop rate input ----
{
  assert.deepEqual(C.clone(C.parseDropRate('1/8')),{odds:[1,8]});assert.deepEqual(C.clone(C.parseDropRate('50%')),{chance:50});assert.deepEqual(C.clone(C.parseDropRate('12.5')),{chance:12.5});assert.deepEqual(C.clone(C.parseDropRate('３／１０')),{odds:[3,10]});
  for(const bad of ['','abc','9/8','1/0','150'])assert.equal(C.parseDropRate(bad),null,bad);
  const d={itemId:'x',chance:50,min:1,max:1},box=document.createElement('div');let n=0;const i=E.dropRateInput(box,d,()=>n++);assert.equal(i.value,50);
  i.value='1/8';i.oninput();assert.deepEqual(C.clone(d),{itemId:'x',min:1,max:1,odds:[1,8]});assert(box.textContent.includes('1/8（12.5%）'));
  i.value='oops';i.oninput();assert.equal(i.className,'pro-invalid');assert.deepEqual(d.odds,[1,8],'invalid text keeps the last good value');
  i.value='25%';i.oninput();assert.deepEqual(C.clone(d),{itemId:'x',min:1,max:1,chance:25});assert.equal(n,2);
  const d2={itemId:'x',odds:[1,3]},b2=document.createElement('div');assert.equal(E.dropRateInput(b2,d2).value,'1/3');
  assert.equal(C.dropRateText({odds:[1,3]}),'1/3（33.333%）');assert.equal(C.dropChance({odds:[1,8]}),.125);
  // Mission schema 4 only when odds (or hidden) are used.
  const base={id:'m',name:'m',enemies:['e'],drops:[{itemId:'x',chance:50,min:1,max:1}]};assert(C.missionSchemaFor([base])<4);assert.equal(C.missionSchemaFor([{...base,drops:[{itemId:'x',odds:[1,8],min:1,max:1}]}]),4);assert.equal(C.missionSchemaFor([{...base,hidden:true}]),4);
  assert.deepEqual(C.clone(C.missionExt({...base,drops:[{itemId:'x',odds:[1,8],min:1,max:2}]}).drops),[{itemId:'x',odds:[1,8],min:1,max:2}]);
  assert.throws(()=>C.missionExt({...base,drops:[{itemId:'x',odds:[9,8],min:1,max:1}]}),/分子は分母以下/);
  assert(read('mission_maker.html').includes('E.dropRateInput(')&&read('combined_maker.html').includes('E.dropRateInput('));
}

// ---- hide-until-unlocked selectors and hire fields ----
{
  const m={id:'m1'};const mm=mount(m,E.missionExtFields());const sel=mm.box.querySelectorAll('select').find(s=>s.attrs['aria-label']==='未解放のときの表示');
  sel.value='true';sel.onchange();assert.strictEqual(m.hidden,true);assert.doesNotThrow(()=>C.missionExt(m));assert.equal(C.missionExt(m).hidden,true);
  sel.value='';sel.onchange();assert.equal(m.hidden,undefined);
  const r={...E.newResearch()};const rm=mount(r,E.researchFields());const rs=rm.box.querySelectorAll('select').find(s=>s.attrs['aria-label']==='未解放のときの表示');rs.value='true';rs.onchange();assert.strictEqual(r.hidden,true);assert.equal(C.research(r).hidden,true);
  assert.equal(C.itemPack({format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:5,packId:'p',items:[],research:[r]}).schemaVersion,5);
  assert(E.MISSION_EXT_KEYS.includes('hidden'));for(const k of ['sortieCost','equipSlots','noFire'])assert(E.UNIT_EXT_KEYS.includes(k)&&E.unitExtFields().some(f=>f.key===k),k);
  // Hire fields
  const h=E.newHire('u1');const hm=mount(h,E.hireFields());assert(hm.box.textContent.includes('雇えるユニット'));
  const cost=hm.box.querySelectorAll('input').find(i=>i.type==='number');cost.value='2500';cost.oninput();assert.equal(h.cost,2500);
  const mc=hm.box.querySelectorAll('input').find(i=>i.type==='checkbox');mc.checked=true;mc.onchange();assert.deepEqual(C.clone(h.requires),{missions:['m1']});
  assert.deepEqual(C.clone(C.hire(h)),{id:h.id,unitId:'u1',cost:2500,requires:{missions:['m1']}});
  const eq=E.effectFields('equip_slot');assert.equal(eq[0].min,-3);assert.deepEqual(C.clone(E.effectDefaults('equip_slot')),{type:'equip_slot',value:1});
}

// ---- pilot text field removed from the makers; existing strings stay in the data ----
{
  const um=read('unit_maker.html'),cm=read('combined_maker.html');assert(!um.includes('id="u_pilot"'));assert(!um.includes('搭乗者 / 操作者'));assert(!cm.includes("'操作者'"));
  assert(um.includes("pilot:String(u.pilot||'')"),'normalizeUnit keeps the pilot string');assert(cm.includes("pilot:String(u.pilot||'')"));
  assert(cm.includes("['hires','雇用']")&&cm.includes('E.hireFields()'),'combined maker hire tab');
}

// ---- game: exact odds, hidden missions / research, weekday ----
{
  const g=game(),run=g.run;
  // 1/8 odds: exactly 1 in 8 over evenly spread random numbers.
  run("MISSIONS[0]={...MISSIONS[0],drops:[C.drop({itemId:'core-i-medkit',odds:[1,8],min:1,max:1})]};state.items['core-i-medkit']=0;");
  run("var k=0;Math.random=()=>((k++%800)+.5)/800;for(let i=0;i<800;i++)rollMissionDrops(MISSIONS[0]);");
  assert.equal(run("state.items['core-i-medkit']"),100,'1/8 of 800 rolls');
  assert.equal(run("normalizeDrop({itemId:'core-i-medkit',odds:[1,8],min:1,max:2}).odds.join('/')"),'1/8');assert.throws(()=>run("normalizeDrop({itemId:'core-i-medkit',odds:[0,0],min:1,max:1})"));
  // Hidden mission stays out of the list until its prerequisites are met (weekday never hides).
  run("MISSIONS.push(normalizeMission({id:'hid-m',name:'隠し作戦',enemies:['core-e-trooper'],reward:1,hidden:true,requires:{missions:['core-m-01']}}),normalizeMission({id:'day-m',name:'曜日作戦',enemies:['core-e-trooper'],reward:1,hidden:true,days:[(today()+1)%7]}));");
  assert(run("missionHidden(MISSIONS.find(m=>m.id==='hid-m'))"));assert(!run("visibleMissions().some(m=>m.id==='hid-m')"));
  assert(run("visibleMissions().some(m=>m.id==='day-m')"),'a weekday lock alone never hides');assert.match(run("missionLockReason(MISSIONS.find(m=>m.id==='day-m'))"),/出撃できる曜日/);
  assert(!run("nextActions().some(a=>a.mission==='hid-m')"));
  run("state.missions['core-m-01']={clears:1,best:3,stars:[true,false,false]};");assert(run("visibleMissions().some(m=>m.id==='hid-m')"));
  // Hidden research.
  assert(run("RESEARCH_MASTER['core-r-guardian'].hidden"));assert.equal(run("researchStatus(RESEARCH_MASTER['core-r-guardian'])"),'locked');
  // Weekday in the header.
  run('render()');assert.match(g.els.todayText.textContent,/^[日月火水木金土]曜日$/);
  assert(read('index.html').includes('id="todayBox"'));
  // A pack mission with schema 4 loads; an unknown schema is refused.
  const mp={format:'VAIS_OUTER_OPS_MISSION_PACK',schemaVersion:4,packId:'mp',missions:[{id:'mp-1',name:'x',enemies:['core-e-trooper'],reward:1,hidden:true,drops:[{itemId:'core-i-medkit',odds:[1,3],min:1,max:1}]}]};
  const v=run(`validateMissionPack(${JSON.stringify(mp)})`);assert.equal(v.missions[0].hidden,true);assert.deepEqual(v.missions[0].drops[0].odds,[1,3]);
  assert.throws(()=>run(`validateMissionPack(${JSON.stringify({...mp,schemaVersion:5})})`),/未対応/);
}

console.log('PASS: maker inputs — tag chips (add/Enter/paste split/delete/limit, all makers), duplicate buttons (fresh skill IDs, weapon names, waves, makers), drop rate "50"/"50%"/"1/8" (odds stored, schema 4), hide-until-unlocked selectors, hire fields, pilot text field removed, game exact odds / hidden missions & research / weekday');
})().catch(e=>{console.error(e);process.exit(1);});
