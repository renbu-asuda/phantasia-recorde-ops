(async()=>{'use strict';
// 1.11.0: bundled expansion packs added with one tap (script tag, no fetch) and one button for every data file.
const fs=require('fs'),path=require('path'),assert=require('assert'),{game,read,root}=require('./game_harness.cjs');
const g=game(),run=g.run;
const catalog=JSON.parse(run('JSON.stringify(PACK_CATALOG)'));assert(catalog.length>=6);
// Catalog pack IDs are unique (adding one must never replace another).
assert.equal(new Set(catalog.map(p=>p.packId)).size,catalog.length);
for(const p of catalog){assert(fs.existsSync(path.join(root,p.file)),p.file);const b=run(`validateBundlePack(window.PROCore.parse(${JSON.stringify(read(p.file))},'VAIS_BUNDLE_PACK')).packId`);assert.equal(b,p.packId,p.file+' packId');}
// Loading a catalog file restores the page's own globals.
run("window.VAIS_BUNDLE_PACK={marker:1}");const unitsBefore=run('window.VAIS_UNIT_PACK.packId');
assert.equal(await run("addCatalogPack('black_bullet')"),true);
assert.equal(run('window.VAIS_BUNDLE_PACK.marker'),1,'previous VAIS_BUNDLE_PACK restored');assert.equal(run('window.VAIS_UNIT_PACK.packId'),unitsBefore,'base unit pack untouched');
assert(run("importedBundlePacks.some(p=>p.packId==='black_bullet')"));assert(run("UNIT_MASTER.some(u=>u.id==='bb-u-rentaro')"));assert(run("MISSIONS.some(m=>m.id==='bb-m-01')"));
run('renderPackCatalog()');assert.match(g.els.packCatalog.innerHTML,/追加済み：ユニット27/);assert.match(g.els.packCatalog.innerHTML,/data-pack-remove="black_bullet"/);
// Survives reload, can be removed and added again.
const g2=game({memory:new Map(g.memory)});assert(g2.run("UNIT_MASTER.some(u=>u.id==='bb-u-rentaro')"));
run("removeImportedBundlePack('black_bullet')");assert(!run("UNIT_MASTER.some(u=>u.id==='bb-u-rentaro')"));
assert.equal(await run("addCatalogPack('black_bullet')"),true);assert(run("UNIT_MASTER.some(u=>u.id==='bb-u-rentaro')"));
assert.equal(await run("addCatalogPack('pro_1102_pilot_sample')"),true);assert.equal(run('importedBundlePacks.length'),2);
// A missing file is reported, nothing changes.
run("PACK_CATALOG.push({packId:'nope',file:'expansion_packs/nope.js',name:'x',kind:'x',desc:'x'})");assert.equal(await run("addCatalogPack('nope')"),false);assert(g.alerts.some(a=>/読み込めません/.test(a)));assert.equal(run('importedBundlePacks.length'),2);
// Cancelled confirmation changes nothing.
const g3=game({confirm:()=>false});assert.equal(await g3.run("addCatalogPack('PR-01')"),false);assert.equal(g3.run('importedBundlePacks.length'),0);
// One button for every data file: kinds are detected from the content.
const f=(name,text)=>({name,text:async()=>text});
const kinds={bundle:read('samples/pro_sample_bundle.js'),unit:'window.VAIS_UNIT_PACK = '+JSON.stringify({format:'VAIS_OUTER_OPS_UNIT_PACK',schemaVersion:2,packId:'u1',packName:'U',units:[{id:'zz-u',name:'Z',hp:3000,atk:500,def:0,mob:500,acc:500,tags:['歩兵'],skills:[],weapons:[{name:'E90'}],deploy:{player:true,enemy:true}}]})+';',
  mission:'window.VAIS_MISSION_PACK = '+JSON.stringify({format:'VAIS_OUTER_OPS_MISSION_PACK',schemaVersion:1,packId:'m1',packName:'M',missions:[{id:'zz-m',name:'ZM',diff:'E',reward:100,desc:'',terrain:'標準',tags:[],rules:[],enemies:['zz-u'],maxDeploy:4,drops:[]}]})+';',
  item:'window.VAIS_ITEM_PACK = '+JSON.stringify({format:'VAIS_OUTER_OPS_ITEM_PACK',schemaVersion:2,packId:'i1',packName:'I',items:[{id:'zz-i',name:'ZI',effect:{type:'heal_hp_flat',value:10}}]})+';',
  save:JSON.stringify({format:'PRO_SAVE',version:1,state:{credits:777}})};
for(const [k,t] of Object.entries(kinds))assert.equal(g2.run(`detectDataKind(${JSON.stringify(t)})`),k,k);assert.equal(g2.run('detectDataKind("hello")'),'');
g2.c.files=[f('u.js',kinds.unit),f('m.js',kinds.mission),f('i.js',kinds.item),f('b.js',kinds.bundle),f('x.txt','nothing')];await g2.run('importAnyFiles(files)');
assert(g2.run("UNIT_MASTER.some(u=>u.id==='zz-u')"));assert(g2.run("MISSIONS.some(m=>m.id==='zz-m')"));assert(g2.run("!!ITEM_MASTER['zz-i']"));assert(g2.run("importedBundlePacks.some(p=>p.packId==='pack-0000')"));assert(g2.alerts.some(a=>/種類がわからない/.test(a)&&/x\.txt/.test(a)));
g2.c.files=[f('s.json',kinds.save)];await g2.run('importAnyFiles(files)');assert.equal(g2.run('state.credits'),777);
console.log(`PASS: ${catalog.length} catalog packs valid; one-tap add restores globals, persists, removes and re-adds; missing file and cancel are safe; one-button import detects bundle/unit/mission/item/save`);
})().catch(e=>{console.error(e);process.exitCode=1});
