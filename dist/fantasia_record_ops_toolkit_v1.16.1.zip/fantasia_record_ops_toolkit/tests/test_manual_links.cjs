'use strict';
// 1.15.2: the online manual is linked from the game and every maker, and is not shipped inside the toolkit.
const assert=require('assert'),fs=require('fs'),path=require('path'),{read}=require('./game_harness.cjs');
const URL='https://renbu-asuda.github.io/phantasia-recorde-ops/manual/';
const idx=read('index.html');assert(idx.includes(URL)&&idx.includes('id="manualLink"')&&/GAME_VERSION *= *'1.15.2'/.test(idx));
const core=read('shared/maker_core.js');assert(core.includes(URL)&&core.includes('6-maker.html'));
assert(read('maker_hub.html').includes('マニュアル'));
for(const f of ['combined_maker','item_maker','mission_maker','unit_maker'])assert(read(f+'.html').includes('1.15.2'),f);
assert(!fs.existsSync(path.join(__dirname,'..','manual')),'manual stays outside the ZIP');
console.log('PASS: manual links and manual not bundled');
