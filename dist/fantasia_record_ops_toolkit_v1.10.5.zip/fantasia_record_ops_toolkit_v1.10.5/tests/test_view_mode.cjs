(()=>{'use strict';
// 1.10.5: "PC表示" toggle (works in browsers without a desktop-site option) and the LINE in-app browser notice.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
const pages=['index.html','unit_maker.html','mission_maker.html','item_maker.html','combined_maker.html','maker_hub.html'];
function el(tag){return {tag,attrs:{},children:[],style:{},textContent:'',firstChild:null,setAttribute(k,v){this.attrs[k]=v;},getAttribute(k){return this.attrs[k];},appendChild(c){this.children.push(c);this.firstChild=this.children[0];return c;}};}
function run(code,{stored=null,ua='Mozilla/5.0 (Linux; Android 14) Chrome/120 Mobile',href='https://example.github.io/game/index.html'}={}){
  const meta=el('meta');meta.attrs.content='width=device-width,initial-scale=1';const slot=el('span');slot.id='viewModeSlot';const body=el('body');body.insertBefore=function(n){this.children.unshift(n);};
  const store=new Map(stored?[['pro_view_mode',stored]]:[]);let reloaded=0;
  const window={};const ctx={window,navigator:{userAgent:ua},location:{href,reload(){reloaded++;}},localStorage:{getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,v)},
    document:{readyState:'complete',body,createElement:el,querySelector:s=>s==='meta[name=viewport]'?meta:null,getElementById:id=>id==='viewModeSlot'?slot:body.children.find(c=>c.id===id)||null,addEventListener(){}}};
  vm.createContext(ctx);vm.runInContext(code,ctx);return {meta,slot,body,store,reloaded:()=>reloaded,window};
}
for(const page of pages){const html=read(page);
  const m=html.match(/<meta name="viewport"[^>]*>\s*<script data-pro-view>([\s\S]*?)<\/script>/);assert(m,page+': viewportの直後に表示切り替えスクリプトがありません');assert(html.includes('id="viewModeSlot"'),page+': ボタンの置き場所がありません');
  const code=m[1];
  let r=run(code);assert.equal(r.meta.attrs.content,'width=device-width,initial-scale=1');assert.equal(r.slot.children[0].textContent,'🖥 PC表示');assert.equal(r.body.children.length,0,'no LINE notice in Chrome');
  r.slot.children[0].onclick();assert.equal(r.store.get('pro_view_mode'),'pc');assert.equal(r.reloaded(),1);
  r=run(code,{stored:'pc'});assert.equal(r.meta.attrs.content,'width=1280');assert.equal(r.slot.children[0].textContent,'📱 スマホ表示');r.slot.children[0].onclick();assert.equal(r.store.get('pro_view_mode'),'mobile');
  r=run(code,{ua:'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36 Line/14.5.0',href:'https://example.github.io/game/index.html#x'});
  const notice=r.body.children[0];assert.equal(notice.id,'proLineNotice');assert.equal(notice.children[1].attrs===undefined?notice.children[1].href:notice.children[1].href,'https://example.github.io/game/index.html?openExternalBrowser=1');
  r=run(code,{ua:'… Line/14.5.0',href:'https://example.github.io/?a=1'});assert.equal(r.window.PROView.externalUrl(),'https://example.github.io/?a=1&openExternalBrowser=1');
}
console.log(`PASS: ${pages.length} pages have the PC表示 toggle (width=1280, remembered across pages) and the LINE in-app browser notice`);
})();
