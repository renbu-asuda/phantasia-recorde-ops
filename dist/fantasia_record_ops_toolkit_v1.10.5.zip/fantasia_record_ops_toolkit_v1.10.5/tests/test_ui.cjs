const fs=require('fs'),vm=require('vm'),cp=require('child_process'),assert=require('assert');
class E{
 constructor(tag='div',attrs={}){this.tagName=tag.toUpperCase();this.attrs=attrs;this.children=[];this.style={display:(attrs.style||'').includes('display:none')?'none':''};this.hidden='hidden'in attrs;this.textContent='';this.className=attrs.class||'';this.value='';this.classList={contains:c=>this.className.split(' ').includes(c),add:c=>this.className+=' '+c,toggle:(c,on)=>{this.className=this.className.split(' ').filter(x=>x!==c).join(' ')+(on?' '+c:'');}};}
 replaceChildren(...es){for(const e of [...this.children])e.remove();this.append(...es)}
 get id(){return this.attrs.id}get nextSibling(){const a=this.parentNode?.children||[];return a[a.indexOf(this)+1]||null}
 append(...es){for(const e of es){e.remove();this.children.push(e);e.parentNode=this;}}appendChild(e){this.append(e)}
 prepend(...es){for(const e of es.reverse()){e.remove();this.children.unshift(e);e.parentNode=this;}}
 before(e){this.parentNode.insertBefore(e,this)}insertBefore(e,ref){e.remove();let i=this.children.indexOf(ref);if(i<0)i=this.children.length;this.children.splice(i,0,e);e.parentNode=this;}
 remove(){if(this.parentNode){const a=this.parentNode.children;a.splice(a.indexOf(this),1);this.parentNode=null;}}
 setAttribute(k,v){this.attrs[k]=v}removeAttribute(k){delete this.attrs[k]}focus(){}click(){if(!this.disabled)this.onclick?.()}
 matches(s){if(s==='*')return true;return s.startsWith('.')?this.classList.contains(s.slice(1)):s.startsWith('#')?this.id===s.slice(1):this.tagName===s.toUpperCase()}
 querySelectorAll(s){if(s.includes(','))return [...new Set(s.split(',').flatMap(x=>this.querySelectorAll(x)))];let parts=s.trim().split(/\s+/);const last=parts.pop();const all=[];const walk=e=>{for(const c of e.children){if(c.matches(last)){let p=c.parentNode,ok=true;for(const token of [...parts].reverse()){if(token==='>')continue;while(p&&!p.matches(token))p=p.parentNode;if(!p){ok=false;break}p=p.parentNode;}if(ok)all.push(c)}walk(c)}};walk(this);return all;}
 querySelector(s){return this.querySelectorAll(s)[0]||null}
}
for(const file of ['index.html','unit_maker.html','mission_maker.html','item_maker.html','combined_maker.html']){
const src=fs.readFileSync(require('path').join(__dirname,'..')+'/'+file,'utf8');for(const m of src.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))new vm.Script(m[1]);
const parser=`import json,sys\nfrom html.parser import HTMLParser\nclass P(HTMLParser):\n def __init__(self):\n  super().__init__();self.root=['root',{},[]];self.stack=[self.root]\n def handle_starttag(self,t,a):\n  n=[t,dict(a),[]];self.stack[-1][2].append(n)\n  if t not in ['meta','link','input','br','hr','img','source','wbr']:self.stack.append(n)\n def handle_endtag(self,t):\n  for i in range(len(self.stack)-1,0,-1):\n   if self.stack[i][0]==t:self.stack=self.stack[:i];break\n def handle_data(self,s):\n  if self.stack[-1][0] not in ['script','style']:self.stack[-1][2].append(s)\np=P();p.feed(open(sys.argv[1]).read());print(json.dumps(p.root))`;
const tree=JSON.parse(process.env.PRO_TEST_TREE_DIR?fs.readFileSync(require('path').join(process.env.PRO_TEST_TREE_DIR,file+'.json'),'utf8'):cp.execFileSync('python3',['-c',parser,require('path').join(__dirname,'..',file)],{maxBuffer:2000000}));
function build(n){const e=new E(n[0],n[1]);for(const c of n[2])if(typeof c==='string')e.textContent+=c;else e.append(build(c));return e}
const doc=build(tree),events={};doc.createElement=t=>new E(t);doc.getElementById=id=>doc.querySelector('#'+id);doc.body=doc.querySelector('body');doc.addEventListener=(name,fn)=>events[name]=fn;
const ids=doc.querySelectorAll('*');let original={};const collect=e=>{if(e.id){assert(!original[e.id],file+' duplicate '+e.id);original[e.id]=e;}e.children.forEach(collect)};collect(doc);
const scripts=[...src.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)];const memory=new Map(),context={document:doc,window:{scrollTo(){}},console,confirm:()=>true,localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},navigator:{},setTimeout:fn=>fn()};vm.createContext(context);for(const f of ['shared/pro_core.js','shared/pro_battle.js','shared/pro_templates.js','shared/pro_editor.js','shared/maker_core.js','tests/fixtures/base_181/outer_ops_units.js','tests/fixtures/base_181/outer_ops_missions.js','tests/fixtures/base_181/outer_ops_items.js'])vm.runInContext(fs.readFileSync(require('path').join(__dirname,'..')+'/'+f,'utf8'),context);vm.runInContext(scripts.at(-1)[1],context);
for(const [id,e]of Object.entries(original))assert.strictEqual(doc.getElementById(id),e,'lost DOM '+id);
const buttons=doc.querySelector('.flow-nav').children;
if(file==='index.html'){
for(const b of buttons){b.click();assert.equal(Object.values(buttons).filter(x=>x.attrs['aria-current']==='page').length,1);}
assert(doc.getElementById('importUnitBtn').parentNode.parentNode.parentNode.textContent!==undefined);buttons[2].click();assert(!doc.getElementById('deployBtn').parentNode.parentNode.hidden);buttons[0].click();assert(doc.getElementById('deployBtn').parentNode.parentNode.hidden);
}else if(file==='combined_maker.html'){
const $=id=>doc.getElementById(id),C=context.window.PROCore,M=context.window.PROMaker;
assert($('download').disabled);$('loadSamples').click();assert.equal($('download').disabled,false,$('validation').textContent);const parsed=M.getAdapter('bundle').readPack($('code').value);assert.equal(parsed.units.length,5);assert.equal(parsed.items.length,1);assert.equal(parsed.missions.length,1);
const tabs=$('tabs').children;tabs[1].click();assert(!$('collection').hidden);$('records').children[0].children[0].click();assert(!$('editor').hidden);$('steps').children[1].click();assert(!$('form').hidden);$('steps').children[2].click();$('toList').click();tabs[2].click();$('records').children[0].children[0].click();assert(!$('editor').hidden);tabs[3].click();$('records').children[0].children[0].click();assert(!$('editor').hidden);tabs[0].click();assert.equal($('download').disabled,false);assert(memory.size>0);assert.equal(M.getAdapter('bundle').exportPack().missions.length,1);
// Author a new unit, mission and item entirely in the combined editor.
tabs[1].click();$('add').click();const enemyBox=$('form').querySelectorAll('input').filter(x=>x.type==='checkbox')[1];enemyBox.checked=true;enemyBox.onchange();
tabs[2].click();$('add').click();$('steps').children[1].click();$('form').querySelector('button').click();const enemySelect=$('form').querySelector('select');enemySelect.value='new_unit';enemySelect.onchange();$('steps').children[2].click();$('form').querySelector('button').click();
tabs[3].click();$('add').click();$('steps').children[1].click();const required=$('form').querySelector('input');required.value='歩兵';required.oninput();$('steps').children[2].click();const effect=$('form').querySelector('select');effect.value='add_weapon';effect.onchange();
tabs[0].click();assert.equal($('download').disabled,false,$('validation').textContent);const authored=M.getAdapter('bundle').exportPack();assert.equal(authored.units.length,6);assert.equal(authored.missions.length,2);assert.equal(authored.items.length,2);assert.equal(authored.items.at(-1).requires.allTags[0],'歩兵');assert.equal(authored.items.at(-1).effect.type,'add_weapon');
// 1.10 easy mode: build a unit, a mission and an item purely from templates, then export.
const create=()=>$('pickerBox').querySelectorAll('button').find(b=>b.textContent==='この内容で作る').click();
tabs[1].click();$('addTemplate').click();assert($('pickerBox').children.length>0,'template picker opens');const nameBox=$('pickerBox').querySelectorAll('input')[0];nameBox.value='テンプレ兵';create();assert(!$('editor').hidden);
tabs[2].click();$('addTemplate').click();create();tabs[3].click();$('addTemplate').click();create();
tabs[0].click();const easy=M.getAdapter('bundle').exportPack();assert(easy.units.some(u=>u.name==='テンプレ兵'&&/^unit-\d{4}$/.test(u.id)));assert.equal(easy.missions.length,3);assert(easy.missions.at(-1).enemies.length>0);assert.equal(easy.items.length,3);
// mode toggle persists and switches the body class
const modeButtons=$('modeBox').querySelectorAll('button');modeButtons.find(b=>b.textContent==='詳細').click();assert.equal(memory.get('pro_maker_mode'),'expert');assert(doc.body.className.includes('mode-expert'));modeButtons.find(b=>b.textContent==='かんたん')?.click();
console.log('PASS combined maker: initial validation, sample 3-pack import, all editor tabs, bundle output, draft, template creation, mode toggle');
}else if(file==='item_maker.html'){
const $=id=>doc.getElementById(id),C=context.window.PROCore,M=context.window.PROMaker;const input=(id,v)=>{$(id).value=v;$(id).oninput?.();};
$('add').click();assert(!$('editorPage').hidden);input('itemId','trial');input('itemName','試験アイテム');input('allTags','歩兵');input('noneTags','装甲車');$('next').click();assert(!$('effectsPage').hidden);
let sel=$('effects').querySelector('select');sel.value='add_skill';sel.onchange();$('addEffect').click();$('next').click();assert(!$('download').disabled);let out=M.getAdapter('item').exportPack();assert.equal(out.items[0].requires.allTags[0],'歩兵');assert.equal(out.items[0].requires.noneTags[0],'装甲車');assert.equal(out.items[0].effects[0].type,'add_skill');assert.equal(out.items[0].effects[1].type,'stat_up_flat');
$('duplicate').click();assert.equal(M.getAdapter('item').exportPack().items.length,2);assert.equal(M.getAdapter('item').exportPack().items[1].requires.allTags[0],'歩兵');$('delete').click();assert.equal(M.getAdapter('item').exportPack().items.length,1);
$('sample').click();assert.equal(M.getAdapter('item').exportPack().items.length,context.window.VAIS_ITEM_PACK.items.length);assert.equal(M.getAdapter('item').exportPack().items.find(x=>x.id==='item-0001').requires.allTags[0],'生身');
$('list').children[0].click();$('next').click();for(const type of Object.keys(C.effects)){sel=$('effects').querySelector('select');sel.value=type;sel.onchange();$('next').click();assert.equal($('download').disabled,false,type+' cannot export');C.itemPack(C.parse($('code').value,'VAIS_ITEM_PACK'));$('prev').click();}
// Inputs that cannot be represented as valid effects block export, without deleting the draft.
sel=$('effects').querySelector('select');sel.value='heal_hp_pct';sel.onchange();const number=$('effects').querySelector('input');number.value='101';number.onchange();$('next').click();assert($('download').disabled);assert(memory.size>0);
$('addTemplate').click();$('pickerBox').querySelectorAll('button').find(b=>b.textContent==='この内容で作る').click();assert(!$('editorPage').hidden);
console.log('PASS item maker: create, edit all 10 types, compound, duplicate, delete, sample load, export roundtrip, invalid export block, draft, template creation');
}else{
const body=doc.getElementById('editorBody');body.style.display='block';events['maker-selection']({detail:true});assert(!doc.querySelector('.editor').hidden);
const cards=body.children.filter(e=>e.classList.contains('card')),steps=doc.querySelector('.flow-stepbar').children;
const input=doc.getElementById(file==='unit_maker.html'?'u_name':'m_name');input.value='保持テスト';assert.equal(steps.length,file==='mission_maker.html'?7:6,'extension (1.9) and difficulty (1.10) steps');for(let i=0;i<steps.length;i++){steps[i].click();assert(cards[i].hidden===false);assert(cards.filter(e=>!e.hidden).length===(file==='mission_maker.html'&&i===steps.length-1?2:1));}
buttons[0].click();buttons[1].click();assert.equal(input.value,'保持テスト');events['maker-selection']({detail:false});assert(doc.querySelector('.editor').hidden);
}
console.log('PASS',file,'syntax / ID preservation / page switching / editor steps and retained inputs');
}
